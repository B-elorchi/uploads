import { HttpException, Injectable } from '@nestjs/common';
import * as firebase from 'firebase-admin'
@Injectable()
export class AppService {
  getHello(): any {
    return { name: 'Hello World!' };
  }
  async sendNotif(fcm_token, title, body){
    // This registration token comes from the client FCM SDKs.
    const registrationToken = fcm_token;

    const message = {
    notification:{
        title:title,
        body:body
      },
    token: registrationToken
    };

        // Send a message to the device corresponding to the provided
        // registration token.
       return await firebase.messaging().send(message)
        .then((response) => {
            // Response is a message ID string.
            console.log('Successfully sent message:', response);
            return {success: true, message: "Notif Successfully sent"}
        })
        .catch((error) => {
          throw new HttpException({success:false, message: error.message}, 400)
        });
  }


  
}
