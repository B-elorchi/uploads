import { Controller } from '@nestjs/common';

@Controller('profile')
export class ProfileController {}
