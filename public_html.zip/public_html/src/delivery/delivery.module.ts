import { Module } from '@nestjs/common';
import { DeliveryController } from './delivery.controller';
import { DeliveryService } from './delivery.service';
import { FarmasiDeliveryController } from './farmasi-delivery.controller';
import { MarjaneDeliveryController } from './marjane-delivery.controller';

@Module({
  controllers: [],
  providers: [DeliveryService],
})
export class DeliveryModule {}
