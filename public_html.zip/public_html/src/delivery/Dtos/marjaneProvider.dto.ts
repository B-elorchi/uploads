/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import {IsDefined,  IsNotEmpty, IsLatitude, IsLongitude, IsString, IsOptional } from 'class-validator';


export class MarjaneProviderDto {

@ApiProperty()
@IsNotEmpty({ message: "L'id du livreur est requis",})
@IsString({ message: "L'id du livreur ne doit pas être vide",})
provider_id: string;

@ApiProperty()
@IsNotEmpty({ message: "Le nom du livreur est requis",})
@IsString({ message: "Le nom du livreur ne doit pas être vide",})
provider_name: string;


@ApiProperty()
@IsOptional()
@IsNotEmpty({ message: "Le num de tél du livreur ne doit pas être vide",})
@IsString({ message: "Le num de tél du livreur doit être de type String",})
provider_phone: string;
 
@ApiProperty()
@IsOptional()
@IsNotEmpty({ message: "La Latitude est requise",})
@IsLatitude({ message: "Format de Latitude invalide",})
provider_location_latitude: number;

@ApiProperty()
@IsOptional()
@IsNotEmpty({ message: "La Longitude est requise",})
@IsLongitude({ message: "Format de Longitude invalide",})
provider_location_longitude: number;

}
