/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {IsDefined, IsNumberString,  IsNotEmpty } from 'class-validator';


export class PaymentDto {

 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner une méthode de Paiement', }) 
 @IsNotEmpty({ message: "La méthode de paiement est requise",})
 method: string;


 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner un prix', }) 
 @IsNotEmpty({ message: "Le prix est requis",})
 @Type(() => Number)
 price: number;
}
