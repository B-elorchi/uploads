/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsDefined, IsNotEmpty, IsNotEmptyObject, IsObject, ValidateNested} from 'class-validator';
import { MarjaneProviderDto } from './marjaneProvider.dto';

export class CompleteOrderDto {

 @ApiProperty()
/*  @IsNotEmpty({ message: "Le Co est requis",})
 @IsString({ message: "Le Prénom ne doit pas être vide",})*/
 @IsDefined({message: 'Vous devez renseigner un  code de commande', }) 
 @IsNotEmpty({ message: "Le code de commande est requis",})
 code: string;
}
