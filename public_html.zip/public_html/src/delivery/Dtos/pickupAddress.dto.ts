/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import {IsDefined,  IsNotEmpty, IsLatitude, IsLongitude, IsString } from 'class-validator';


export class PickupAddressDto {

@ApiProperty()
@IsDefined({message: 'Vous devez renseigner une Latitude', }) 
@IsNotEmpty({ message: "La Latitude est requise",})
@IsLatitude({ message: "Format de Latitude invalide",})
latitude: number;

@ApiProperty()
@IsDefined({message: 'Vous devez renseigner une Longitude', }) 
@IsNotEmpty({ message: "La Longitude est requise",})
@IsLongitude({ message: "Format de Longitude invalide",})
longitude: number;

 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner un Id de Magasin', }) 
 @IsNotEmpty({ message: "L'Id de Magasin est requise",})
 @IsString({ message: "L'Id de Magasin doit être de type String",})
 idMagasin: string;

 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner un Libelé du Magasin', }) 
 @IsNotEmpty({ message: "Le Libelé du Magasin est requis",})
 @IsString({ message: "Le Libelé du Magasin doit être de type String",})
 libeleMagasin: string;

}
