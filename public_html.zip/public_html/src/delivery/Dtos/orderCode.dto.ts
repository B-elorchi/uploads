/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsNotEmpty } from 'class-validator';


export class OrderCodeDto {

 @ApiProperty()
/*  @IsNotEmpty({ message: "Le Co est requis",})
 @IsString({ message: "Le Prénom ne doit pas être vide",})*/
 @IsDefined({message: 'Vous devez renseigner un  code de commande', }) 
 @IsNotEmpty({ message: "Le code de commande est requis",})
 code: string;
}
