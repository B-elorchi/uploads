/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsNotEmpty, IsNotEmptyObject, IsObject, ValidateNested} from 'class-validator';

export class CompleteOrderByIdDto {

 @ApiProperty()
/*  @IsNotEmpty({ message: "Le Co est requis",})
 @IsString({ message: "Le Prénom ne doit pas être vide",})*/
 @IsDefined({message: 'Vous devez renseigner l\'id de commande', }) 
 @IsNotEmpty({ message: "L\'id de commande est requis",})
 id: string;
}
