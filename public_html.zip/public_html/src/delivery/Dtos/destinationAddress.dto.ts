/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import {IsDefined,  IsNotEmpty, IsLatitude, IsLongitude, IsString, IsOptional } from 'class-validator';


export class DestinationAddressDto {

 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner une Latitude', }) 
 @IsNotEmpty({ message: "La Latitude est requise",})
 @IsLatitude({ message: "Format de Latitude invalide",})
 latitude: number;

 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner une Longitude', }) 
 @IsNotEmpty({ message: "La Longitude est requise",})
 @IsLongitude({ message: "Format de Longitude invalide",})
 longitude: number;

 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner une Adresse', }) 
 @IsNotEmpty({ message: "L'adresse est requise",})
 @IsString({ message: "L'adresse doit être de type String",})
 address: string;

 @ApiProperty()
 @IsOptional()
 @IsNotEmpty({ message: "Les détails sont requis",})
 @IsString({ message: "Les détails doivent être de type String",})
 details: string;

 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner une Personne à contacter ', }) 
 @IsNotEmpty({ message: "La Personne à contacter est requise",})
 @IsString({ message: "La Personne à contacter doit être de type String",})
 contactPerson: string;
 
 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner un Num de tél de la personne à contacter', }) 
 @IsNotEmpty({ message: "Le Num de tél de la personne à contacter est requise",})
 @IsString({ message: "Le Num de tél de la personne à contacter doit être de type String",})
 contactPhone: string;



}
