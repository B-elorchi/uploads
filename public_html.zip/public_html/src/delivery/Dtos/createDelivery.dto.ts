/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsDate, IsDefined, IsEmail, IsEnum, IsNotEmpty, IsNotEmptyObject, IsNumber, IsObject, IsOptional, IsString, ValidateNested } from 'class-validator';
import { DeliveryStatus } from 'src/models/delivery_status.enum';
import { Payment } from 'src/models/payment.model';
import { DestinationAddressDto } from './destinationAddress.dto';
import { PaymentDto } from './payment.dto';
import { PickupAddressDto } from './pickupAddress.dto';

export class CreateDeliveryDto {

@ApiProperty()

/*  @IsNotEmpty({ message: "Le Co est requis",})
@IsString({ message: "Le Prénom ne doit pas être vide",})*/
@IsDefined({message: 'Vous devez renseigner un ID', }) 
@IsNotEmpty({ message: "L ID de commande est requis",})
@IsNumber()
id: number;

 @ApiProperty()

/*  @IsNotEmpty({ message: "Le Co est requis",})
 @IsString({ message: "Le Prénom ne doit pas être vide",})
 @IsDefined({message: 'Vous devez renseigner un Prénom', }) */
 @IsNotEmpty({ message: "Le Code est requis",})
 code: string;

 @ApiProperty()
 @IsNotEmpty({ message: "Le Statut est requis",})
 @IsEnum(DeliveryStatus, { message: "Le Statut ne figure pas dans la liste des status autorisés pour une commande" })
 state: DeliveryStatus;

 @ApiProperty()
 @IsNotEmpty({ message: "La Date de livraison est requise",})
/*  @IsDate({ message: "Date de livraison invalide" }) */
 scheduleTime: number;

 @ApiProperty()
 @IsOptional()
 @IsNotEmpty({ message: "Le Nom est requis",})
 @IsString({ message: "La Description est de type Sting",})
/*  @IsDefined({message: 'Vous devez renseigner un Nom', }) */
 description: string;

  @ApiProperty()
  @IsNotEmptyObject({},{ message: "L'objet Payement ne doit pas être vide",})
  @IsDefined({message: 'Vous devez renseigner L\'objet Payement', })
  @IsObject({message: 'Payement et de type objet', })
  @ValidateNested({message: 'Une ou plusieurs propriétés de l\'objet DestinationAddress sont invalides'})
  @Type(() => PaymentDto)
  payment: PaymentDto;
  
 
  @ApiProperty()
  @IsNotEmptyObject({},{ message: "L'objet DestinationAddress ne doit pas être vide",})
  @IsDefined({message: 'Vous devez renseigner L\'objet DestinationAddress', })
  @IsObject({message: 'DestinationAddress doit être de type objet', })
  @ValidateNested({message: 'Une ou plusieurs propriétés de l\'objet DestinationAddress sont invalides'})
  @Type(() => DestinationAddressDto)
  destinationAddress: DestinationAddressDto;
  


  @ApiProperty()
  @IsNotEmptyObject({},{ message: "L'objet PickupAddress ne doit pas être vide",})
  @IsDefined({message: 'Vous devez renseigner L\'objet PickupAddress', })
  @IsObject({message: 'PickupAddress doit être de type objet', })
  @ValidateNested({message: 'Une ou plusieurs propriétés de l\'objet DestinationAddress sont invalides'})
  @ValidateNested()
  @Type(() => PickupAddressDto)
  pickupAddress: PickupAddressDto;
  
}
