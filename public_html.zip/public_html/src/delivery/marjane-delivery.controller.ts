import { Body, HttpStatus, Post, Req, Res } from '@nestjs/common';
import { Controller, Get } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Request, Response } from 'express';
import { DeliveryService } from './delivery.service';
import { AssignDeliveryManMarjaneDto } from './Dtos/assignDeliveryManMarjane.dto';
import { AssignDriverDto } from './Dtos/assignDriver.dto';
import { CompleteOrderDto } from './Dtos/completeOrder.dto';
import { CreateDeliveryDto } from './Dtos/createDelivery.dto';
import { OrderRefDto } from './Dtos/orderRef.dto';

@Controller({
  path: ['marjane'],
  version: '1', // 👈
})
@ApiTags('MarjaneWebService')
@ApiBearerAuth('JWT')
export class MarjaneDeliveryController {
  constructor(private readonly deliveryService: DeliveryService) {}

  @Post("order/delivery")
  @ApiOperation({
    summary:
      'If not already exists, this endpoint will create a new Delivery Request. In the other case, it will update the existing Delivery Document ',
  })
  async createOrUpdateDelivery(@Body() createDeliveryDto: CreateDeliveryDto) {
    return await this.deliveryService.createOrUpdateDelivery(createDeliveryDto);
  }

  @Post('/assignDeliveryMan')
  @ApiOperation({
    summary:
      'Assign a DeliveryMan to a Delivery and update the delivery status to Status_validated ',
  })
  async assignDeliveryManAndSetActive(
    @Body() assignDriverDto: AssignDriverDto,
  ) {
    return await this.deliveryService.assignDeliveryMan(assignDriverDto);
  }

  @Post('/addProviderToOrder')
  @ApiOperation({
    summary:
      'Assign a DeliveryMan to a Delivery and update the delivery status to Status_validated ',
  })
  async assignDeliveryManMarjane(
    @Body() assignDmDto: AssignDeliveryManMarjaneDto,
  ) {
    return await this.deliveryService.assignDeliveryManMarjane(assignDmDto);
  }

  @Post('/SetOrderAsCompleted')
  @ApiOperation({
    summary:
      'Complete the requested Order Delivery',
  })
  async setOrderAsCompleted(@Body() orderDto: CompleteOrderDto) {
   /*  return await this.deliveryService.assignDeliveryManMarjane(orderDto); */
  }

  
  @Post('/joinRoom')
  @ApiOperation({
    summary:
      'Join the Signal R Socket Room connection based on delivery reference',
  })
  async trackByReference(@Body() orderDto: OrderRefDto, @Res() res: Response) {
    let response =  await this.deliveryService.trackDeliveryByCode(orderDto);
    if(response.success === true) {
      return res.status(HttpStatus.OK).json(response);
    }else{
      return res.status(HttpStatus.BAD_REQUEST).json(response);
    }
  }
}
