/* eslint-disable prettier/prettier */
import { HttpException, Injectable } from '@nestjs/common';
import * as firebase from 'firebase-admin';
import axios from 'axios';
import { DocumentReference } from '@google-cloud/firestore';
import { CreateDeliveryDto } from './Dtos/createDelivery.dto';
import { AssignDriverDto } from './Dtos/assignDriver.dto';
import { DeliveryStatus } from 'src/models/delivery_status.enum';
import { AssignDeliveryManMarjaneDto } from './Dtos/assignDeliveryManMarjane.dto';
import { CreateDeliveryInternalDto } from './Dtos/createDeliveryInternal.dto';
import { CompleteOrderByIdDto } from './Dtos/completeOrderById.dto';
import signalR from '@microsoft/signalr';
import { OrderCodeDto } from './Dtos/orderCode.dto';
import { OrderRefDto } from './Dtos/orderRef.dto';


@Injectable()
export class DeliveryService {


      async createOrUpdateDelivery(createDeliveryDto : CreateDeliveryDto) {
        try{
           
        const db = firebase.firestore();
      
        let obj = {...createDeliveryDto as any};
        delete obj.id;
       
        obj["external_id"] = createDeliveryDto.id;
      
        let createDeliveryInternalDto = new CreateDeliveryInternalDto();
        createDeliveryInternalDto = obj;

        console.log(createDeliveryInternalDto);

        const deliveryDoc = await db.collection('deliveries').where('external_id','==', createDeliveryInternalDto.external_id ).get();

        if(deliveryDoc.empty || deliveryDoc.size == 0){  
            const addDeliveryRef = await db.collection('deliveries')
            .add(
                {...createDeliveryInternalDto, 
                    deliveryManRef: null, 
                    internalStatus: "Created", 
                    scheduleTime: new Date(createDeliveryDto.scheduleTime * 1000), 
                    scheduleTimeBrut: createDeliveryDto.scheduleTime, 
                    creationTime: new Date(/* createDeliveryDto.scheduleTime * 1000 + 3600000 */)
                })
            .then(deliveryRef =>{
                console.log(deliveryRef)
                console.log("deliveryRef")

              return deliveryRef;
            })
            .catch(error => {
                console.log("error")
                console.log(error)
              return error;
            });
    
            if(addDeliveryRef.id){
             /*  console.log('delivery man id ok ==> '+addDeliveryRef.id) */
           /*    console.log((await userRef.get()).data()) */
              return { 
                success: true,
                message: "Livraison crée avec succés",
                data: {
                    delivery: {... (await addDeliveryRef.get()).data(), id: addDeliveryRef.id}, 
                }
            }
            }else{
                throw new HttpException(
                    {
                      success: false,
                      message: "Une erreur est survenue lors de la création de cette livraison.",
            
                    }, 
                    400);
            }
         /*   */
        }else{
            console.log("New Update Request Received From Marjane At : " + new Date())
            console.log("Delivery Data  =====> ");
            console.log(createDeliveryDto);


            const updateDeliveryRef = await db.collection('deliveries').doc(deliveryDoc.docs[0].id);

            // HANDLING UPDATE CASE WHEN DELIVERY IS CANCELLED TO LIBERATE DELIVERY MAN AND REMOVE ACTIVE DELIVERY
            if(createDeliveryDto.state == DeliveryStatus.CANCELLED && deliveryDoc.docs[0].data().deliveryManRef){
                const docRef = await db.collection("active_deliveries").where("delivery_man_ref", "==",deliveryDoc.docs[0].data().deliveryManRef)
                .get().then((elt)=>{
                   /*  if(elt.size > 0){
                        elt.forEach((item)=>{
                            item.ref.delete();
                        })
                    } */
                })

                /* const deliveryManDoc = 
                await  db.collection("delivery_men")
                        .doc(deliveryDoc.docs[0].data().deliveryManRef)
                        .update({
                            availability: true,
                        }); */
            }
            await updateDeliveryRef.update({
                state: createDeliveryInternalDto.state,
                description: createDeliveryInternalDto.description,
                destinationAddress: createDeliveryInternalDto.destinationAddress,
                pickupAddress: createDeliveryInternalDto.pickupAddress,
                payment: createDeliveryInternalDto.payment,
                updateTime: new Date()});
          
   
           
           /*    console.log((await userRef.get()).data()) */
           if(updateDeliveryRef.id){
           /*   console.log("Delivery updated successfully and activeDelivery will be updated") */
            /*console.log(deliveryDoc.docs[0].ref); */
             const activeDeliveryRef = await db.collection('active_deliveries').where("delivery_ref", "==",deliveryDoc.docs[0].ref )
            .get()
            .then(function(querySnapshot) {
              /*   console.log("Donc il trouve quelque chose") */
                 let activeDeliveriesSnapshot = [];
                  querySnapshot.forEach(function(doc) {
                     //    console.log(doc.data()); 
                     // doc.ref.update("delivery_ref",updateDeliveryRef.deliveryRef);
                     activeDeliveriesSnapshot.push(doc.ref.id);
                     //await db.collection('active_deliveries').doc(doc.ref.id).update({delivery_ref: updateDeliveryRef.deliveryRef})
                  });
                  return {success:true, activeDeliveries: activeDeliveriesSnapshot}

             });   
           /*   console.log(activeDeliveryRef.activeDeliveries[0]); */
      /*     let activeDelivery =  await (await db.collection('active_deliveries').doc(activeDeliveryRef.activeDeliveries[0]).get()).data();
           console.log("activeDelivery data");
           console.log(activeDelivery);
           console.log("updateDeliveryRef.deliveryRef");
           console.log(updateDeliveryRef);
           console.log()
             let updateResponse = await db.collection('active_deliveries').doc(activeDeliveryRef.activeDeliveries[0]).update({
                "delivery_ref":updateDeliveryRef
             })
        //             .update({delivery_ref: updateDeliveryRef.deliveryRef})
             .then(deliveryRef =>{
                 //   console.log(deliveryRef);
                console.log("updateResponse Success");

                  return {success:true, deliveryRef: deliveryRef};
                })
                .catch(error => {
                console.log("updateResponse Error");

                  return {success:false, deliveryRef: null, error: error};;
                });
                */
               /*  console.log("updateResponse"); */
/* 
                console.log(updateResponse); */

             /*    let activeDeliveryNew =  await (await db.collection('active_deliveries').doc(activeDeliveryRef.activeDeliveries[0]).get()).data();
                console.log(activeDeliveryNew) */

             return { 
                success: true, 
                message: 'Livraison mise à jour avec succés',
            }
           }
            
            return { 
                success: true, 
                message: 'Livraison mise à jour avec succés',
            }
        
        }
       

        }catch(error){
            console.error("update error");
            console.error(error);
            return {error: error, success: false};
        }
        
      }


      async assignDeliveryMan(assignDeliveryManDto : AssignDriverDto) {
        try{
            const db = firebase.firestore();
        
            const driverRef = await db.collection('delivery_men').doc(assignDeliveryManDto.driverId);
            const deliveryRef = await db.collection('deliveries').doc(assignDeliveryManDto.deliveryId);
            console.log("Driver ID from Assign ", driverRef.id)
            console.log("deliveryRef ID from Assign ", deliveryRef.id)
            const deliveryData = (await deliveryRef.get()).data();
            const driverData = await driverRef.get()
            .then(deliveryManDoc =>{
                console.log('test deliveryman doc')
                if(deliveryManDoc.exists){
                    console.log('exist')

                    return {deliveryMan: deliveryManDoc.data(), success:true};
                }else{
                    console.log('not exist')

                    return {deliveryMan: null , message: "Aucun Livreur n\'est associé à l'ID "+assignDeliveryManDto.driverId, success:false};
                }
            })
            .catch(error => {
                return {...error, success:false};
            });
            console.log("driverData Response", driverData)
            console.log("driverData Object ", driverData.deliveryMan)
            console.log("driverData Available ", driverData.deliveryMan.availability)

            if(driverData.success === true/*  && driverData.deliveryMan.availability === true */){
                console.log("All References received and availability is True also that's amazing ", driverData.deliveryMan.availability)
                /* await */ this.sendPushNotification(driverRef, deliveryData);

               // await this.trackDelivery(deliveryData, driverRef.id);

                const docRef = await db.collection("active_deliveries").select("delivery_man_ref").where("delivery_man_ref", "==",driverRef )
                              .get()
                              .then(function(querySnapshot) {
                                if (querySnapshot.size > 0){
                                        querySnapshot.docs[0].ref.update({
                                        delivery_ref: deliveryRef,
                                        code_commande: deliveryData.code});

                                        return {success:true, found:true, activeDeliveryRef: querySnapshot.docs[0].ref, activeDeliveryData: querySnapshot.docs[0].data()}
                                }else{
                                    return {success:true, found:false}
                                }
                                    /* querySnapshot.forEach(function(doc) {
                                        doc.ref.delete();
                                    }); */
                               });   
                if(docRef.success === true){
                    let addActiveDeliveryRef; 
                    if(docRef.found === false){
                        const addedActiveDeliveryRef = await db.collection('active_deliveries')
                        .add({delivery_man_ref: driverRef, delivery_ref: deliveryRef, code_commande: deliveryData.code})
                        .then(deliveryRef =>{
                            return deliveryRef;
                          })
                          .catch(error => {
                            return error;
                          });
                          addActiveDeliveryRef = addedActiveDeliveryRef;
                    }else{
                         addActiveDeliveryRef = docRef.activeDeliveryRef;
                    }
                     
                
                      if(addActiveDeliveryRef.id){
                        console.log('delivery man id ok ==> '+addActiveDeliveryRef.id)

                        const axios = require('axios');

                        console.log("Driver Data");
                        console.log(driverData.deliveryMan);
                        let data = JSON.stringify({
                        
                            "code": deliveryData.code,
                            "provider": {
                                "provider_id": driverRef.id,
                                "provider_name": driverData.deliveryMan.first_name+" "+driverData.deliveryMan.second_name,
                                "provider_phone": driverData.deliveryMan.phoneNumber,
                                "provider_location_latitude": driverData.deliveryMan.last_position ? driverData.deliveryMan.last_position.latitude : 0,
                                "provider_location_longitude": driverData.deliveryMan.last_position ? driverData.deliveryMan.last_position.longitude : 0
                        }
                        });

                        console.log("data prepared to be sent to marjane API");
                        console.log(data)
                        let config = {
                        method: 'post',
                        maxBodyLength: Infinity,
                        url: 'https://livraison-express.azurewebsites.net/api/AddProviderToOrder',
                        headers: { 
                            'API-KEY': '888ef76c-d460-41ca-bd2e-01ccd21410cd', 
                            'Content-Type': 'application/json'
                        },
                        data : data
                        };

                        let axiosResponse = await axios.request(config)
                        .then((response) => {
                        console.log(JSON.stringify(response.data));

                            return { success: true, result: response.data};
                        })
                        .catch((error) => {
                        console.log(error);
                            return { success: false, message: error.message, code: error.code};
                        });

                        console.log("axiosResponse");
                        console.log(axiosResponse);

                        const deliveryUpdateState = await deliveryRef.update({
                            deliveryManRef: driverRef,
                            internalStatus: "Affected"
                        /*     state: DeliveryStatus.CREATED */
                        });
                        const driverUpdate = driverRef.update({
                            availability: false,
                        });
                     /*    console.log((await userRef.get()).data()) */
                        return { 
                            activeDelivery: {
                                ... (await addActiveDeliveryRef.get()).data(), 
                                id: addActiveDeliveryRef.id
                            }, 
                            success: true, 
                            deliveryMan: driverData,
                            deliveryUpdateState: deliveryUpdateState,
                            message: "Livraison affectée avec succés et passée à l'état active"}
                      }else{
                        return {
                            message: addActiveDeliveryRef.message,
                            activeDelivery: addActiveDeliveryRef, 
                            success: false, 
                            deliveryMan: driverData
                        }
                      }
                }
    
            }else{

                if(driverData.deliveryMan.availability === false){
                    return { success: false, message: "Ce livreur a une autre mission en cours.", deliveryMan: driverData }
                }else{
                    return { success: false, message: "Cette référence de Livreur est invalide.", deliveryMan: driverData }
                }
            }

        }catch(error){
            return {error: error, success: false, message: error.message};
        }
        
      }

      async testPushNotification(){
        // This registration token comes from the client FCM SDKs.
        const registrationToken = 'dcOkWTtBQ-6-vhP91gpEp_:APA91bFkkAlr8_o17VO_BtA-KJz6OnKTUUCDYv4PsjymeQ6XhkumN9t3BuLuZjzAjwoHoEzc5wj6AQXKbANKb4tUNMyJxxElPW8BnpEVEUSkRDRIz0ruG2zDd4YxQUj8PyXS7AKg4ok7';

        const message = {
        data: {
            score: '850',
            time: '2:45'
        },
        notification:{
            title:"Portugal vs. Denmark",
            body:"great match!"
          },
        token: registrationToken
        };

            // Send a message to the device corresponding to the provided
            // registration token.
            firebase.messaging().send(message)
            .then((response) => {
                // Response is a message ID string.
                console.log('Successfully sent message:', response);
            })
            .catch((error) => {
                console.log('Error sending message:', error);
            });
      }
      async sendNotif(fcm_token, title, body){
        // This registration token comes from the client FCM SDKs.
        const registrationToken = fcm_token;

        const message = {
        notification:{
            title:title,
            body:body
          },
        token: registrationToken
        };

            // Send a message to the device corresponding to the provided
            // registration token.
            firebase.messaging().send(message)
            .then((response) => {
                // Response is a message ID string.
                console.log('Successfully sent message:', response);
            })
            .catch((error) => {
                console.log('Error sending message:', error);
            });
      }

      async sendPushNotification(deliveryManRef: DocumentReference, deliveryData){
        // This registration token comes from the client FCM SDKs.
        const db= firebase.firestore();
   
        const driverData= (await deliveryManRef.get()).data();
        console.log("driverData");
        console.log(driverData);
        const userRef = await db.collection("user").doc(driverData.userRef.id);
        console.log("userData");
        /* console.log(userRef); */
        const userData = (await userRef.get()).data();
        console.log(userData)
       
        const body = "Vous avez reçu une nouvelle demande de livraison "+deliveryData.code+" sur "+ deliveryData.pickupAddress.libeleMagasin+". Veuillez cliquer rapidement afin de la confirmer.";
        const title = "Nouvelle demande de livraison "+deliveryData.code;
        const fcm = await (await db.collection("user").doc(driverData.userRef.id).collection("fcm_tokens").get()).forEach(async (queryDocumentSnapshot)=>{
           if(queryDocumentSnapshot.exists){
           const devicesData = await queryDocumentSnapshot.data();
           console.log("devicesData");
           console.log(devicesData);
             const sendNotifResult = await this.sendNotif(devicesData.fcm_token, title, body);
             console.log("sendNotifResult");
             console.log(sendNotifResult);
           /*  queryDocumentSnapshot.data().forEach((elt)=>{
                console.log(elt)
            }) */
           }
        })
      
      }
      async assignDeliveryManMarjane(assignDeliveryManDto : AssignDeliveryManMarjaneDto) {
        try{
            const db = firebase.firestore();
        
            const driverRef = await db.collection('delivery_men').doc(assignDeliveryManDto.provider.provider_id);
            const deliveryRef = await db.collection('deliveries').where('code','==', assignDeliveryManDto.code);
            console.log("Driver ID from Assign ", driverRef.id)
            console.log("deliveryRef ID from Assign ", (await deliveryRef.get()).docs[0].id);
            const driverData = await driverRef.get()
            .then(deliveryManDoc =>{
                console.log('test deliveryman doc')
                if(deliveryManDoc.exists){
                    console.log('exist')

                    return {deliveryMan: deliveryManDoc.data(), success:true};
                }else{
                    console.log('not exist')

                    return {deliveryMan: null , message: "No Delviery man Exists with id "+assignDeliveryManDto.provider.provider_id, success:false};
                }
            })
            .catch(error => {
                return {...error, success:false};
            });
            console.log("driverData Response", driverData)
            console.log("driverData Object ", driverData.deliveryMan)
            console.log("driverData Available ", driverData.deliveryMan.availability)

            if(driverData.success === true && driverData.deliveryMan.availability === true){
                console.log("All References received and availability is True also that's amazing ", driverData.deliveryMan.availability)

                const docRef = await db.collection("active_deliveries").select("delivery_man_ref").where("delivery_man_ref", "==",driverRef )
                              .get()
                              .then(function(querySnapshot) {
                                if(querySnapshot.size > 0){
                                    querySnapshot.forEach(function(doc) {
                                        doc.ref.delete();
                                    });
                                }
                                 
                                    return {success:true}

                               });   
                if(docRef.success === true){
                    const addActiveDeliveryRef = await db.collection('active_deliveries').add({delivery_man_ref: driverRef, delivery_ref: deliveryRef})
                    .then(deliveryRef =>{
                        return deliveryRef;
                      })
                      .catch(error => {
                        return error;
                      });
              
                      if(addActiveDeliveryRef.id){
                        console.log('delivery man id ok ==> '+addActiveDeliveryRef.id)

                       /*  const deliveryUpdateState = await deliveryRef.update({state: DeliveryStatus.VALIDATED}); */
                     /*    console.log((await userRef.get()).data()) */
                        return { 
                            activeDelivery: {
                                ... (await addActiveDeliveryRef.get()).data(), 
                                id: addActiveDeliveryRef.id
                            }, 
                            success: true, 
                            deliveryMan: driverData,
                        /*     deliveryUpdateState: deliveryUpdateState, */
                            message: "Livraison affectée avec succés et passée à l'état active"}
                      }else{
                        return {
                            message: addActiveDeliveryRef.message,
                            activeDelivery: addActiveDeliveryRef, 
                            success: false, 
                            deliveryMan: driverData
                        }
                      }
                }
    
            }else{

                if(driverData.deliveryMan.availability === false){
                    return { success: false, message: "Ce livreur a une autre mission en cours.", deliveryMan: driverData }
                }else{
                    return { success: false, message: "Cette référence de Livreur est invalide.", deliveryMan: driverData }
                }
            }

        }catch(error){
            return {error: error, success: false, message: error.message};
        }
        
      }

      async complete(orderDto: CompleteOrderByIdDto){
        try {
          
            const db = firebase.firestore();
            let delivery =  await db
              .collection('deliveries')
              .doc(orderDto.id)
              .get()
              .then((qs) => {
                if (qs.exists) {
                    if(qs.data().deliveryManRef){
                        qs.ref.update({
                            isRoomJoined: false
                        })
                     /*    qs.data().deliveryManRef.update({
                            availability: true,
                            
                        }) */
                    }
                  return {
                    success: true,
                    data: { ...qs.data(), id: qs.id },
                    message: 'Données livraison envoyée avec succés',
                  };
                } else {
                  return { success: false, message: "Cette livraison n'existe pas" };
                }
              })
              .catch((error) => {
                return { success: false, message: error.message, data:null};
              });

              if(delivery.success === true){
              
                console.log("Attempting to send CompleteOrder Request to the Marjane Service Api at : ", new Date());
                console.log("Order Code to complete : ", delivery.data.code, delivery.data.creationTime.toDate());
              /*   console.log("Timestamp Creation : ", delivery.data.code, delivery.data.creationTime);
                console.log("Timestamp Creation to seconds : ", delivery.data.code, delivery.data.creationTime.toMillis()); */
                const currentDate = new Date();
                const timestamp = currentDate.getTime();
                console.log("Now Timestamp ", timestamp)
                let data = JSON.stringify({
                "code": delivery.data.code
                });

                let config = {
                method: 'post',
                maxBodyLength: Infinity,
                url: 'https://livraison-express.azurewebsites.net/api/SetOrderAsCompleted',
                headers: { 
                    'API-KEY': '888ef76c-d460-41ca-bd2e-01ccd21410cd', 
                    'Content-Type': 'application/json'
                },
                data : data
                };

               return await axios.request(config)
                .then(async (response) => {
                    console.log("Order "+ delivery.data.code+ " Completion Request successfully done at "+new Date());
                    console.log(JSON.stringify(response.data));
                    console.log(response.data.success);
                    if(response.data.success === true){
                        await db
                        .collection('deliveries')
                        .doc(orderDto.id).update({
                            state: DeliveryStatus.DELIVERED,
                            marjaneCompleteResponseSuccess: response.data.success, 
                            marjaneCompleteResponse: response.data, 
                            marjaneLastCompleteTime: new Date()});
                    }else{
                        await db
                        .collection('deliveries')
                        .doc(orderDto.id).update({
                            marjaneCompleteResponseSuccess: response.data.success, 
                            marjaneCompleteResponse: response.data,
                            marjaneLastCompleteTime: new Date()
                        });
                    }
                  
                    return response.data;
                })
                .catch((error) => {
                console.log(error);
                return error;
                });
              }
          } catch (error) {
            return { error: error, success: false, message: error.message };
          }
      }

      async completeAllBlockedDeliveries(){
        try {
            const db = firebase.firestore();
           let deliveryData =  await db.collection("deliveries").where("state", "==","STATUS_DELIVERING")
            .get()
            .then(function(querySnapshot) {
                if(querySnapshot.size == 0){
                  throw new HttpException({ success: false, message: "Aucune livraison n'est en cours" }, 400);
                }
                let deliveries = [];
                querySnapshot.docs.forEach((elt)=>{
                    //if(elt.data().marjaneCompleteResponseSuccess === false){
                        deliveries.push({...elt.data(), id: elt.id, updated: elt.data().updateTime ? elt.data().updateTime.toDate() :null })
                    //}
                })
                return {success:true, deliveries: deliveries, size: deliveries.length};
             }); 

             if(deliveryData.success === true && deliveryData.deliveries.length > 0){
                let deliveries = deliveryData.deliveries;

                deliveries.forEach(async (elt)=>{
                    console.log(elt);
                    await this.complete({id: elt.id});
                })
             }
            /*  console.log("deliveryData")
             console.log(deliveryData) */
             return deliveryData;
        
        }catch(error){
            console.log(error);
            throw new HttpException({ success: false, message: error.message }, 400);

        } 
      }

      async completeDeliveriesFromJob(){
        try {
            const db = firebase.firestore();
           // console.log("Timestamp Creation to seconds : ", delivery.data.code, delivery.data.creationTime.toMillis());
            const currentDate = new Date();
            const timestamp = currentDate.getTime();
        
           let deliveryData =  await db.collection("deliveries")
           .where("state", "==","STATUS_DELIVERING")
          // .where("marjaneCompleteResponseSuccess","==", false)
           .where("internalStatus","==", "Completed")
           .where("creationTime",">=", new Date( timestamp - 86400000)) 
          /*  .where("creationTime","<=", new Date( timestamp - 5400000)) */
            .get()
            .then(function(querySnapshot) {
                if(querySnapshot.size == 0){
                  throw new HttpException({ success: false, message: "Aucune livraison remplissant les conditions n'est en cours" }, 400);
                }
                let deliveries = [];
                querySnapshot.docs.forEach((elt)=>{
                    console.log("find a delivery fulfilling retry conditions : ", elt.data().code)
                    console.log(elt.data().finishedAt.toDate())
                   // if(elt.data().marjaneCompleteResponseSuccess === false){
                        deliveries.push({...elt.data(), id: elt.id, updated: elt.data().updateTime ? elt.data().updateTime.toDate() :null })
                   // }
                })
                return {success:true, deliveries: deliveries, size: deliveries.length};
             }); 

             if(deliveryData.success === true && deliveryData.deliveries.length > 0){
                let deliveries = deliveryData.deliveries;

                deliveries.forEach(async (elt)=>{
                    console.log(elt);
                    await this.complete({id: elt.id});
                })
             }
            /*  console.log("deliveryData")
             console.log(deliveryData) */
             return deliveryData;
        
        }catch(error){
            console.log(error);
            throw new HttpException({ success: false, message: error.message }, 400);

        } 
      }
      async trackDelivery(deliveryId){
        try {
            console.log("Hello from Track")
            const db = firebase.firestore();
            console.log(deliveryId);
            const deliveryData = (await db.collection('deliveries').doc(deliveryId.id).get()).data();
            console.log("deliveryDocData")
        /*  console.log(deliveryDocData) */
            const doc = db.collection('delivery_men').doc(deliveryData.deliveryManRef.id);
            /* doc.update({isRoomJoinded: true}); */
            const deliveryManData = (await doc.get()).data();

            const signalR = require("@microsoft/signalr");

            var connection = new 
                            signalR.HubConnectionBuilder()
                            .withUrl(process.env.MARJANE_WEBSOCKET_URL)
                            .build();
           
            /* let data = JSON.stringify({
                "reference": deliveryDocData.code
            }); */

            /* let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: 'https://asehubtracking.azurewebsites.net/api/joinRoom',
            headers: { 
                'Content-Type': 'application/json'
            },
            data : data
            };

            let isRoomJoined = await axios.request(config)
            .then((response) => {
                console.log(JSON.stringify(response.data));
                return [response.data, response.status];
            })
            .catch((error) => {
            console.log(error);
                return error
            }); */

         /*    console.log("isRoomJoined");
            console.log(isRoomJoined); */
            await connection.start().then(()=>{
                
                console.log("Successfully Started")
                const observer = doc.onSnapshot(docSnapshot => {
                    console.log(`Received doc snapshot: ${JSON.stringify(docSnapshot)}`);
     
                    connection.invoke("JoinRoomByDelivery", deliveryData.delivery.code)
                    .then((data)=>{
                         console.log("Room Joined Successfully");
         
                    })
                    .catch(function (err) {
                         console.error(err.toString());
                         return {
                             success:false,
                             message: err.toString()
                         }
                    });
                    
     
                    if(deliveryManData && deliveryManData.last_position && deliveryManData.last_position.latitude && deliveryManData.last_position.longitude){
                        let speed = 0;
                        if(deliveryManData.last_position_speed){
                            speed = deliveryManData.last_position_speed * 3.6
    
                            if(speed > 0.8){
                                deliveryManData.last_position_speed = speed.toFixed(4) +" km/h" 
                                deliveryManData.motion = true;
                            }else{
                                let zero = 0;
                                deliveryManData.last_position_speed = zero.toFixed(4) +" km/h" 
                                deliveryManData.motion = false;
                            }
                        }
                        let dataEmittedToRoom= {
                             latitude: deliveryManData.last_position.latitude.toString(),
                             longitude: deliveryManData.last_position.longitude.toString(),
                             timestamp: new Date(),
                             speed: deliveryManData.last_position_speed,
                             motion: deliveryManData.motion,
                     }
                     connection.invoke("SendPositionToRoom", deliveryData.delivery.code, dataEmittedToRoom).then((data)=>{
                             console.log("Successfully sent data to Marjane Socket");
                             console.log(dataEmittedToRoom);
                            return dataEmittedToRoom;
                        }).catch((err)=>{
                             console.error(err.toString());
                             return {
                                 success:false,
                                 message: err.toString()
                             }
                        });
                    }else{
                     console.log("Delivery Man Data don't cointain latitude and longitude")
                    }
                    
                
                  /*   if(docSnapshot.data().available === true){
                        console.log("This Delivery Man is now available so the connection close was called");
                        connection.invoke("LeaveRoom", delivery.code);
                    } */
                    /* docSnapshot.data();*/
                // ...
                }, err => {
                        console.log(`Encountered error in Listening to Delivery Man : ${err}`);
                });
            });
            
            return {
                 success: true,
                 message: "Delivery Man Location successfully emitted to Room",
                 data: {
                     latitude: deliveryManData.last_position.latitude.toString(),
                     longitude: deliveryManData.last_position.longitude.toString(),
                     speed: deliveryManData.last_position_speed,
                     motion: deliveryManData.motion,
                 }
             }
          /*  }else{
            return {success:false,error: "Aucun livreur associé à cette livraison"};
           } */
        }catch(error){
            console.log(error);
            throw new HttpException(
                {success:false, message: error.message},  400); 
        }
           

         

                    
      }


      async trackDeliveryByCode(codeDto: OrderRefDto){
        console.log("Track Delivery By Code Init")
        try {
           const db = firebase.firestore();
           let code = codeDto.reference;
           const deliveryData = await db.collection("deliveries").where("code", "==",code )
           .get()
           .then(function(querySnapshot) {
               if(querySnapshot.size == 0){
                 return {success:false, message: "Aucune livraison n'est associée à ce code"};
               }
               querySnapshot.docs[0].ref.update({isRoomJoinded: true});
               
               return {
                success:true, 
                deliveryId: querySnapshot.docs[0].id, 
                delivery: querySnapshot.docs[0].data()
                };
            }); 
            console.log("deliveryData")
            console.log(deliveryData)
            
            const signalR = require("@microsoft/signalr");
            var connection = new 
                            signalR.HubConnectionBuilder()
                            .withUrl("https://asehubtracking.azurewebsites.net/Tracking")
                            .build(); 

       if(deliveryData.delivery.deliveryManRef){
        const doc = db.collection('delivery_men').doc(deliveryData.delivery.deliveryManRef.id);
        /* doc.update({isRoomJoinded: true}); */
        const deliveryManData = (await doc.get()).data();
     
        await connection.start().then(()=>{
                
            console.log("Successfully Started")
            const observer = doc.onSnapshot(docSnapshot => {
                console.log(`Received doc snapshot: ${JSON.stringify(docSnapshot)}`);
 
                connection.invoke("JoinRoomByDelivery", deliveryData.delivery.code)
                .then((data)=>{
                     console.log("Room Joined Successfully");
     
                })
                .catch(function (err) {
                     console.error(err.toString());
                     return {
                         success:false,
                         message: err.toString()
                     }
                });
                
 
                if(deliveryManData && deliveryManData.last_position && deliveryManData.last_position.latitude && deliveryManData.last_position.longitude){
                    let speed = 0;
                    deliveryManData.motion = false;
                    if(deliveryManData.last_position_speed){
                        speed = deliveryManData.last_position_speed * 3.6

                        if(speed > 0.1){
                            deliveryManData.last_position_speed = speed.toFixed(4) +" km/h" 
                            deliveryManData.motion = true;
                        }else{
                            let zero = 0;
                            deliveryManData.last_position_speed = zero.toFixed(4) +" km/h" 
                            deliveryManData.motion = false;
                        }
                    }
                    let dataEmittedToRoom= {
                         latitude: deliveryManData.last_position ? deliveryManData.last_position.latitude.toString() : null,
                         longitude: deliveryManData.last_position ? deliveryManData.last_position.longitude.toString() : null,
                         timestamp: new Date().getTime().toString(),
                         vitesse_gps: deliveryManData.last_position_speed ? deliveryManData.last_position_speed : "0.0000 km/h",
                         acceleration: deliveryManData.motion ? deliveryManData.motion.toString(): "false",
                         altitude: deliveryManData.altitude ? deliveryManData.altitude.toString() : null,
                         vitesse_gps_accuracy: deliveryManData.last_position_speed_accuracy ? deliveryManData.last_position_speed_accuracy.toString() : null
                    }
                    console.log(dataEmittedToRoom)


                    connection.invoke("SendPositionToRoom", deliveryData.delivery.code, dataEmittedToRoom).then((data)=>{
                         console.log("Successfully sent data to Marjane Socket");
                         console.log(dataEmittedToRoom);
                        return dataEmittedToRoom;
                    }).catch((err)=>{
                         console.error(err.toString());
                         return {
                             success:false,
                             message: err.toString()
                         }
                    });
                }else{
                 console.log("Delivery Man Data don't cointain latitude and longitude")
                }
                
            
              /*   if(docSnapshot.data().available === true){
                    console.log("This Delivery Man is now available so the connection close was called");
                    connection.invoke("LeaveRoom", delivery.code);
                } */
                /* docSnapshot.data();*/
            // ...
            }, err => {
                    console.log(`Encountered error in Listening to Delivery Man : ${err}`);
            });
        });
        
        return {
             success: true,
             message: "Delivery Man Location successfully emitted to Room",
             data: {
                 //latitude: deliveryManData.last_position.latitude.toString(),
                 //longitude: deliveryManData.last_position.longitude.toString(),
                 latitude: deliveryManData.last_position ? deliveryManData.last_position.latitude.toString() : null,
                 longitude: deliveryManData.last_position ? deliveryManData.last_position.longitude.toString() : null,
                 timestamp: new Date().getTime().toString(),
                 vitesse_gps:   deliveryManData.last_position_speed 
                 && deliveryManData.last_position_speed * 3.6 > 0.5 ? (deliveryManData.last_position_speed * 3.6).toFixed(4) + " km/h" : "0.0000 km/h",
                 acceleration:  deliveryManData.last_position_speed 
                 && deliveryManData.last_position_speed * 3.6 > 0.1 ? "true" : "false",
                 altitude: deliveryManData.altitude ? deliveryManData.altitude.toString() : null,
                 vitesse_gps_accuracy: deliveryManData.last_position_speed_accuracy ? deliveryManData.last_position_speed_accuracy.toString() : null
             }
         }
       }else{
        return {success:false,error: "Aucun livreur associé à cette livraison"};
       }
      
       }catch(error){
           console.log(error);
           return {success:false,error: error};
       }           
     }
      async getDeliveryByCode(codeDto:OrderCodeDto){

        try {
            const db = firebase.firestore();
            let code = codeDto.code;
            const docRef = await db.collection("deliveries").where("code", "==",code )
            .get()
            .then(function(querySnapshot) {
                if(querySnapshot.size == 0){
                  return {success:false, message: "Aucune livraison n'est associée à ce code"};
                }
                return {success:true, deliveryId: querySnapshot.docs[0].id, delivery: querySnapshot.docs[0].data()};
             }); 
             return docRef;  
        }catch(error){
            console.log(error);
            throw new HttpException(
                {success:false, message: error.message},  400); 
        }

      }

      async getRoomJoinedDeliveryMen(){

        try {
            const db = firebase.firestore();
            let deliveries = [];
            return await db.collection("deliveries").where("isRoomJoined", "==",true).get()
            .then(async function(querySnapshot) {
                if(querySnapshot.size == 0){
                  return {success:false, message: "Aucune livraison n'est associée à ce code pour la tracker"};
                }
                    querySnapshot.docs.forEach(async (doc)=>{
                        deliveries.push(doc.data())
                        await this.trackDeliveryByCode(doc.data().code)
                    })
                return {success:true, deliveries: deliveries};
             }); 
              
        }catch(error){
            console.log(error);
            throw new HttpException(
                {success:false, message: error.message},  400); 
        }

      }
}
