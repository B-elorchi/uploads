import { Body, Post, Req } from '@nestjs/common';
import { Controller, Get } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import { DeliveryService } from './delivery.service';
import { AssignDeliveryManMarjaneDto } from './Dtos/assignDeliveryManMarjane.dto';
import { AssignDriverDto } from './Dtos/assignDriver.dto';
import { CompleteOrderDto } from './Dtos/completeOrder.dto';
import { CompleteOrderByIdDto } from './Dtos/completeOrderById.dto';
import { CreateDeliveryDto } from './Dtos/createDelivery.dto';
import { OrderCodeDto } from './Dtos/orderCode.dto';
import { OrderRefDto } from './Dtos/orderRef.dto';

@Controller({
  path: ['app/delivery'],
  version: '1', // 👈
})
@ApiTags('Operations')
@ApiBearerAuth('JWT')
export class DeliveryController {
  constructor(private readonly deliveryService: DeliveryService) {}

  @Get()
  getHello(@Req() request: Request): any {
    /*    res.status(500).json({ error: 'Error during token creation' }); */
    console.log('GetHello Successfully reached');
    console.log(request);
    return {
      success: true,
      authenticated: true,
      message: 'Congratulations, you are now authenticated',
    };
  }

  @Get('testPush')
  @ApiOperation({
    summary:
      'test Push Notifications',
  })
  async testPush() {
    return await this.deliveryService.testPushNotification();
  }

  @Post()
  @ApiOperation({
    summary:
      'If not already exists, this endpoint will create a new Operation Request. In the other case, it will update the existing Operation Document ',
  })
  async createOrUpdateOperation(@Body() createOperationDto: CreateDeliveryDto) {
    return await this.deliveryService.createOrUpdateDelivery(createOperationDto);
  }

  @Post('/assignValet')
  @ApiOperation({
    summary:
      'Assign a Valet to a Operation and update the Operation status to Status_validated ',
  })
  async assignValetAndSetActive(
    @Body() assignDriverDto: AssignDriverDto,
  ) {
    return await this.deliveryService.assignDeliveryMan(assignDriverDto);
  }

  @Post('/addProviderToOrder')
  @ApiOperation({
    summary:
      'Assign a OperationMan to a Operation and update the Operation status to Status_validated ',
  })
  async assignOperationManMarjane(
    @Body() assignDmDto: AssignDeliveryManMarjaneDto,
  ) {
    return await this.deliveryService.assignDeliveryManMarjane(assignDmDto);
  }

  @Post('/SetOrderAsCompleted')
  @ApiOperation({
    summary:
      'Complete the requested Order Operation',
  })
  async setOrderAsCompleted(@Body() orderDto: CompleteOrderDto) {
   /*  return await this.deliveryService.assignOperationManMarjane(orderDto); */
  }

  @Post('/complete')
  @ApiOperation({
    summary:
      'Complete the requested Order Operation',
  })
  async complete(@Body() orderDto: CompleteOrderByIdDto) {
    return await this.deliveryService.complete(orderDto);
  }


  @Get('/completeOperation')
  @ApiOperation({
    summary:
      'Complete the requested Order Operation',
  })
  async completeOperations() {
    return await this.deliveryService.completeAllBlockedDeliveries();
  }
  @Post('/getByCode')
  @ApiOperation({
    summary:
      'Get Operation Details By Code',
  })
  async getByCode(@Body() orderDto: OrderCodeDto) {
    return await this.deliveryService.getDeliveryByCode(orderDto);
  }

  
  @Post('/track')
  @ApiOperation({
    summary:
      'Complete the requested Order Operation',
  })
  async track(@Body() orderDto: CompleteOrderByIdDto) {
    return await this.deliveryService.trackDelivery(orderDto);
  }

  @Post('/joinRoom')
  @ApiOperation({
    summary:
      'Init the Signal R Socket connection ',
  })
  async trackByReference(@Body() orderDto: OrderRefDto) {
    return await this.deliveryService.trackDeliveryByCode(orderDto);
  }
}
