import { Body, Post, Req } from '@nestjs/common';
import { Controller, Get } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import { DeliveryService } from './delivery.service';
import { AssignDeliveryManMarjaneDto } from './Dtos/assignDeliveryManMarjane.dto';
import { AssignDriverDto } from './Dtos/assignDriver.dto';
import { CompleteOrderDto } from './Dtos/completeOrder.dto';
import { CreateDeliveryDto } from './Dtos/createDelivery.dto';

@Controller({
  path: ['Farmasi/deliveries'],
  version: '1', // 👈
})
@ApiTags('FarmasiWebService')
@ApiBearerAuth('JWT')
export class FarmasiDeliveryController {
  constructor(private readonly deliveryService: DeliveryService) {}

  @Post()
  @ApiOperation({
    summary:
      'If not already exists, this endpoint will create a new Delivery Request. In the other case, it will update the existing Delivery Document ',
  })
  async createOrUpdateDelivery(@Body() createDeliveryDto: CreateDeliveryDto) {
    return await this.deliveryService.createOrUpdateDelivery(createDeliveryDto);
  }

  @Post('/assignDeliveryMan')
  @ApiOperation({
    summary:
      'Assign a DeliveryMan to a Delivery and update the delivery status to Status_validated ',
  })
  async assignDeliveryManAndSetActive(
    @Body() assignDriverDto: AssignDriverDto,
  ) {
    return await this.deliveryService.assignDeliveryMan(assignDriverDto);
  }

  @Post('/addProviderToOrder')
  @ApiOperation({
    summary:
      'Assign a DeliveryMan to a Delivery and update the delivery status to Status_validated ',
  })
  async assignDeliveryManMarjane(
    @Body() assignDmDto: AssignDeliveryManMarjaneDto,
  ) {
    return await this.deliveryService.assignDeliveryManMarjane(assignDmDto);
  }

  @Post('/SetOrderAsCompleted')
  @ApiOperation({
    summary:
      'Complete the requested Order Delivery',
  })
  async setOrderAsCompleted(@Body() orderDto: CompleteOrderDto) {
   /*  return await this.deliveryService.assignDeliveryManMarjane(orderDto); */
  }
}
