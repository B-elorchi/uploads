import { Body, Controller, Param, Put } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { UsersService } from '../users.service';
import { UpdateProfileDto } from '../Dtos/update-profile.dto';
import { UpdatePasswordDto } from 'src/_global-dtos/update-password.dto';

@Controller({
    path: ['valet'],
    version: '1', // 👈
})
@ApiTags('Valet-Account')
@ApiBearerAuth('JWT')

export class UserValetController {
    constructor(private userService: UsersService){}

    @Put('/profile/edit/:id')
    @ApiOperation({
      summary:
        'Update User Profile',
    })
    @ApiParam({
      name: 'id',
      description: 'The Valet Document ID',
    })
    async updateProfile(@Param('id') id: string, @Body() updateProfileDto: UpdateProfileDto) {
       return await this.userService.updateProfile(id, updateProfileDto); 
    }


    @Put("/profile/updatePassword")
    @ApiOperation({
        summary:
        'Update Valet Password',
    })
    async updatePassword(@Body() updatePassDto: UpdatePasswordDto) {
        return await this.userService.updatePassword(updatePassDto);
    }
    
  

}