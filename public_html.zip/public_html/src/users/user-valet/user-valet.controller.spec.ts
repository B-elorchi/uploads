import { Test, TestingModule } from '@nestjs/testing';
import { UserValetController } from './user-valet.controller';

describe('UserValetController', () => {
  let controller: UserValetController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UserValetController],
    }).compile();

    controller = module.get<UserValetController>(UserValetController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
