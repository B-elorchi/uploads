import { Body, Controller, HttpException, Post } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RegisterDto } from 'src/auth/Dtos/register.dto';
import { UsersService } from './users.service';
import { EmailDto } from './Dtos/email.dto';
import { RegisterUserDto } from './Dtos/register-user.dto';
import { RegisterResponsableDto } from 'src/_global-dtos/register-responsable.dto';
import { SetUserClaimDto } from 'src/_global-dtos/set-user-claim.dto';

@Controller({
    path: ['app/users'],
    version: '1', // 👈
  })
@ApiTags('Users')
@ApiBearerAuth('JWT')
export class UsersController {
  constructor(private readonly userService: UsersService) {}

  @Post('/back-office/add')
  @ApiOperation({
    summary:
      'Register New BackOffice  User',
  })
  async registerUser(@Body() regDto: RegisterUserDto) {
    if(regDto.password != regDto.c_password){
      throw new HttpException({success:false, message: "Les mots de passes ne correspondent pas"}, 400)
    }
    return await this.userService.createBackoffice(
      regDto,
      "back-office"
    );
  }




  @Post('/getUserByEmail')
  @ApiOperation({
    summary:
      'Get User By Email',
  })
  async getUserByEmail(@Body() emailDto: EmailDto) {
    return await this.userService.getUserByEmail(
      emailDto.email
    );
  }

  
  @Post('/responsable/add')
  @ApiOperation({
    summary:
      'Register New User with Client Role and create Both Document Entities for User and Client associated By userRef using PhoneAuth & EmailAuth Firebase Providers',
  })
  async registerResponsable(@Body() regDto: RegisterResponsableDto) {
    if(regDto.password != regDto.c_password){
      throw new HttpException({success:false, message: "Les mots de passes ne correspondent pas"}, 400)
    }
    return await this.userService.registerResponsable(
      regDto.email,
      regDto.password,
      regDto.first_name,
      regDto.second_name,
      regDto.phone_number,
      regDto.hotspot_ref
    );
  }

  @Post('/setClaims')
  @ApiOperation({
    summary:
      'Register New User with Client Role and create Both Document Entities for User and Client associated By userRef using PhoneAuth & EmailAuth Firebase Providers',
  })
  async setUserClaim(@Body() claimDto: SetUserClaimDto) {

    return await this.userService.setUserClaim(claimDto.id, claimDto.claim);
  }
}
