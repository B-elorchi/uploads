/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsEmail, IsNotEmpty, IsString } from 'class-validator';

export class RegisterUserDto {

  @ApiProperty()

  @IsNotEmpty({ message: "Le Prénom est requis",})
  @IsString({ message: "Le Prénom ne doit pas être vide",})
  @IsDefined({message: 'Vous devez renseigner un Prénom', })
  first_name: string;

  @ApiProperty()

  @IsNotEmpty({ message: "Le Nom est requis",})
  @IsString({ message: "Le Nom ne doit pas être vide",})
  @IsDefined({message: 'Vous devez renseigner un Nom', })
  second_name: string;

  @ApiProperty()
  @IsNotEmpty({ message: "L'email ne doit pas être vide",})
  @IsEmail(undefined,{message: 'Veuillez saisir un email valide'})
  @IsDefined({message: 'Vous devez renseigner un Email', })
  email: string;
  
  @ApiProperty()
  @IsNotEmpty({ message: "Le mot de passe est requis",})
  @IsDefined({message: 'Veuillez saisir le mot de passe', })
  password: string;

  @ApiProperty()
  @IsNotEmpty({ message: "La confirmation du mot de passe est requise",})
  @IsDefined({message: 'Veuillez confirmer le mot de passe', })
  c_password: string;
  @ApiProperty()

  @IsNotEmpty({ message: "Le Numéro de tél est requis",})
  @IsDefined({message: 'Vous devez renseigner un Numéro de tél', })
  phone_number: string;

}
