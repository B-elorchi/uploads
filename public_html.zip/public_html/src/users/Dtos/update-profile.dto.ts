/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsEmail, IsNotEmpty, IsOptional, IsPhoneNumber, IsString } from 'class-validator';

export class UpdateProfileDto {


  @ApiProperty()

  @IsNotEmpty({ message: "Le Prénom est requis",})
  @IsString({ message: "Le Prénom ne doit pas être vide",})
  @IsDefined({message: 'Vous devez renseigner un Prénom', })
  first_name: string;

  @ApiProperty()

  @IsNotEmpty({ message: "Le Nom est requis",})
  @IsString({ message: "Le Nom ne doit pas être vide",})
  @IsDefined({message: 'Vous devez renseigner un Nom', })
  second_name: string;

  @ApiProperty()
  @IsNotEmpty({ message: "L'email ne doit pas être vide",})
  @IsEmail(undefined,{message: 'Veuillez saisir un email valide'})
  @IsDefined({message: 'Vous devez renseigner un Email', })
  email: string;
  
  
  @ApiProperty()
  @IsPhoneNumber("MA", {message: "Veuillez renseigner un numéro de tél valide"})
  @IsNotEmpty({ message: "Le Numéro de tél est requis",})
  @IsDefined({message: 'Vous devez renseigner un Numéro de tél', })
  phone_number: string;

/*   @ApiProperty()
  @IsOptional()
  @IsNotEmpty({ message: "Le Num de CIN est requis",})
  @IsString({ message: "Le Num de CIN est de type Sting",})
  cin_number: string;

  @ApiProperty()
  @IsOptional()
  @IsNotEmpty({ message: "Le Num de Permis est requis",})
  @IsString({ message: "Le Num de Permis est de type Sting",})
  num_permis: string; */
}
