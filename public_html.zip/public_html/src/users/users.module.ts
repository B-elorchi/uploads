import { Module } from '@nestjs/common';
import { UsersController } from './users.controller';
import { UsersService } from './users.service';
import { UserValetController } from './user-valet/user-valet.controller';
import { UserClientController } from './user-client/user-client.controller';

@Module({
  controllers: [UsersController, UserValetController, UserClientController],
  providers: [UsersService]
})
export class UsersModule {}
