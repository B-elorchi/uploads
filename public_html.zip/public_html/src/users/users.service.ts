import { HttpException, Injectable } from '@nestjs/common';
import * as firebase from 'firebase-admin';
import axios from 'axios';
import { DocumentReference } from '@google-cloud/firestore';
import { User } from 'src/models/user.model';

import { RegisterUserDto } from './Dtos/register-user.dto';
import { UpdatePasswordDto } from 'src/_global-dtos/update-password.dto';
import { AccountStatusDto } from 'src/_global-dtos/account-status.dto';
import { SetUserClaimDto } from 'src/_global-dtos/set-user-claim.dto';

@Injectable()
export class UsersService {
    async createBackoffice(regDto: RegisterUserDto, role) {
        try {
          let email = regDto.email;
          let firstName = regDto.first_name;
          let secondName = regDto.second_name;
          let password = regDto.password;
          let phoneNumber = regDto.phone_number;
  
          const db = firebase.firestore();
          const auth = firebase.auth();
  
  
          const createdUserResult =  await auth.createUser({
            email: email,
            emailVerified: false,
            phoneNumber: phoneNumber,
            password: password,
            displayName: firstName +' '+ secondName,
            photoURL: process.env.BACKEND_URL+'/static/profile_picture.png',
            disabled: false,
           
          })
          .then((userRecord) => {
            console.log('Successfully created new user:', userRecord.uid);
            return { userAuth: userRecord, success: true, message: 'Utilisateur crée avec succés', code:"success"};
          })
          .catch((error) => {
            console.log('Error creating new user:', error);
            if(error.code =="auth/email-already-exists") error.message = "Cette adresse Email est utilisée par un autre compte";
            return { userAuth: null, success: false, message: error.message, code:error.code};
          });
      
          if(createdUserResult.success === true){
            console.log('It s success')
            await firebase.auth().setCustomUserClaims(createdUserResult.userAuth.uid, {role: "back-office"}).then(() => {
              console.log(" The new custom claims will propagate to the BackOffice's ID token ", createdUserResult.userAuth.uid)
            });
            const userData = {
              uid: createdUserResult.userAuth.uid,
              first_name : firstName,
              second_name : secondName,
              email: email,
              phone_number: phoneNumber,
              disabled: false,
              email_verified: true,
              role: role,
              creation_time: new Date(),
              photo_url: process.env.BACKEND_URL+'/static/profile_picture.png'
            }
            
             const userRef: DocumentReference =  await db.collection('user').doc(userData.uid).set(userData)
             .then( (writeResult)=>{
                return db.collection("user").doc(userData.uid);
             })
             .catch((error)=> {
                return error;
             });
           
             if(userRef.id){
                return {... createdUserResult, user: (await userRef.get()).data(), id: userRef.id}
             }else{
                return {...createdUserResult, userCreateError: userRef}
             }
          }else{
            return createdUserResult;
          }
        } catch (error) {
          console.log(error)
        }
      
    }

    async setUserClaim(id,claim){
      try{
        const db = firebase.firestore();
        const auth = firebase.auth();
        let user = (await auth.getUser(id));
        let claims=["responsable","back-office","client","valet"];
        if(!claims.includes(claim)){
        throw new HttpException({success:false, message:"The claim is not in the authorized claims"}, 400);

        }
        let userDoc = await db.collection('user').doc(id).get();
        if(userDoc.exists && user){
          await firebase.auth().setCustomUserClaims(id, {role: claim}).then(() => {
            console.log(" The new custom claims will propagate to the BackOffice's ID token ", id)
          });

          return {success:true, message:"Claim set Successfully"};
        }else{

          return {success:true, message:"User Not Found, Claim not set."};
        }
      }catch(error){
        throw new HttpException({success:false, message: error.message}, 400);

      }
     
    }
    
    async getUserByEmail(email) {

      try{
        const db = firebase.firestore();
        return await db.collection("user")
        .where("email","==", email)
        .get()
        .then((qs)=>{
            if(qs.size == 0){
              throw new HttpException({success:false, message: "Aucun compte n'est associé à cette adresse Email"}, 400);
            }else{
              return { success: true, user: qs.docs[0].data(), id: qs.docs[0].id}
            }
        })

      }catch(error){
          throw new HttpException({success:false, message: error.message}, 400);
      }    
  }

    updatePassword = async (updatePassword: UpdatePasswordDto)=>{
      
      if(updatePassword.password == updatePassword.c_password){
        return await firebase
        .auth()
        .updateUser(updatePassword.uid, {
          password: updatePassword.password,
        })
        .then((userRecord) => {
          // See the UserRecord reference doc for the contents of userRecord.
          console.log('Successfully updated user', userRecord.toJSON());

          return { user: userRecord, success: true, message: 'Mot de passe modifié avec succés', code:"success"};

        })
        .catch((error) => {
          throw new HttpException({ user: null, success: false, message: error.message, code: error.code },400);
        });
      }else{
          throw new HttpException({ user: null, success: false, message: "Les mots de passes ne correspondent pas" },400);
      }
    }
    
    setAccountStatus = async (accountStatusDto: AccountStatusDto)=>{

      const db = firebase.firestore();

      const user =await  db.collection("user").doc(accountStatusDto.uid).update({
        disabled:  accountStatusDto.disabled
      })
      return await firebase
      .auth()
      .updateUser(accountStatusDto.uid, {
        disabled: accountStatusDto.disabled,
      })
      .then((userRecord) => {
        // See the UserRecord reference doc for the contents of userRecord.
        console.log('Successfully updated user', userRecord.toJSON());

        return { user: userRecord, success: true, message: 'Compte '+ (accountStatusDto.disabled === false ? 'désactivé' : 'activé' )+' avec succés', code:"success"};

      })
      .catch((error) => {
        throw new HttpException({ user: null, success: false, message: error.message, code: error.code },400);
      });
    }

    updateProfile = async (id, updateProfileDto) => {
      try {
          const db = firebase.firestore();
      /*     const isStoreExisting  = 
              await db.collection('valet').doc(id).get()
              .then((qs)=>{
                  if(qs.exists){
                      return { success: true, data: {...qs.data(), id: qs.id }, message: "Données Valet envoyée avec succés"}
                  }else{
                      return { success: false, message: "Ce Valet n\'existe pas", data: null}
                  }
              }).catch(error=>{
                  return { success: false, message: error.message, data: null}
              });
        
              if(isStoreExisting.success === true){ */
                /*   await db
                  .collection('valet').doc(id)
                  .update({
                    ...updateProfileDto,
                    updated_at: new Date(),
                  })
                  .then((writeResult) => {
                      return { success: true, data: isStoreExisting.data, message: "Données Valet mis à jour avec succés"}
                  })
                  .catch((error) => {
                      return { success: false, message: error.message, data: null}
                  }); */

                /*  await db
                  .collection('user').doc(isStoreExisting.data.userRef.id)
                  .update({
                    ...updateProfileDto,
                    updated_at: new Date(),
                  })
                  .then((writeResult) => {
                      return { success: true, data: isStoreExisting.data, message: "Données Valet mis à jour avec succés"}
                  })
                  .catch((error) => {
                      return { success: false, message: error.message, data: null}
                  }); */

                  return await firebase.auth().updateUser(id,{
                    email: updateProfileDto.email,
                    phoneNumber: updateProfileDto.phone_number,
                    displayName: updateProfileDto.first_name+" "+updateProfileDto.second_name,
                  
                  
                  })
                  .then((userRecord) => {
                    console.log('Successfully updated new user:', userRecord.uid);
                    // See the UserRecord reference doc for the contents of userRecord.
                    return { userAuth: userRecord, success: true, message: 'Utilisateur modifié avec succés', code:"success"};
                  })
                  .catch((error) => {
                    console.log('Error updating  user:', error);
                    if(error.code =="auth/email-already-exists") error.message = "Cette adresse Email est utilisée par un autre compte";
                    return { userAuth: null, success: false, message: error.message, code:error.code};
                  });
            /*   }else{
                  return { success: false, message : "Ce valet n\'existe pas"};
              } */
      } catch (error) {
        return { error: error, success: false, message: error.message };
      }
    };


    async registerResponsable(email, password, firstName, secondName,  phoneNumber, hotspot_ref) {

      
      const db = firebase.firestore();
  
      try{

        const authUser =  await firebase.auth().createUser({
          email: email,
          emailVerified: false,
          phoneNumber: phoneNumber,
          password: password,
          displayName: firstName +' '+ secondName,
          photoURL: process.env.BACKEND_URL+'/static/profile_picture.png',
          disabled: false,
        })
        .then((userRecord) => {
          console.log('Successfully created new user:', userRecord.uid);
         
          return { userAuth: userRecord, success: true, message: 'Utilisateur crée avec succés', code:"success"};
        })
        .catch((error) => {
          console.log('Error creating new user:', error);
          if(error.code =="auth/email-already-exists") error.message = "Cette adresse Email est utilisée par un autre compte";
          return { userAuth: null, success: false, message: error.message, code:error.code};
        });
    
        if(authUser.success === true){
          await firebase.auth().setCustomUserClaims(authUser.userAuth.uid, {role: "responsable"}).then(() => {
            console.log(" The new custom claims will propagate to the valets's ID token ", authUser.userAuth.uid)
          });
          console.log('It s success')
          const userData = {
            uid: authUser.userAuth.uid,
            first_name : firstName,
            second_name : secondName,
            email: email,
            phone_number: phoneNumber,
            disabled: false,
            email_verified: true,
            role: "responsable",
            creation_time: new Date(),
            photo_url: process.env.BACKEND_URL+'/static/profile_picture.png'
          }
          
           const userRef: DocumentReference =  await db.collection("user").doc(userData.uid).set(userData)
            .then( (writeResult)=>{
                return db.collection("user").doc(userData.uid);
            })
            .catch((error)=> {
                return error;
            });
         
            if(userRef && userRef.id){

              let hotspotRef = await db.collection('hotspots').doc(hotspot_ref);
              let hotspotDoc = await hotspotRef.get();
              let hotspotData = await hotspotDoc.data();

              await hotspotRef.update({
                responsableRef: userRef
              });

              return {success:true, hotspotId: hotspotDoc.id, ... authUser, user: (await userRef.get()).data(), id: userRef.id}
           }else{
              return {...authUser, userCreateError: userRef}
           }
        }else{
          return authUser;
        }
      }catch(error){
        throw new HttpException({success:false, message: error.message}, 400);

      }
    
    }
}
