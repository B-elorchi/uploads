/* eslint-disable prettier/prettier */
import { Req, Controller, Get, Body, HttpException, Post } from '@nestjs/common';
import { Request } from 'express';
import { AppService } from './app.service';
import * as firebase from 'firebase-admin';
import { SocketIoGateway } from './socket.io/socket.io.gateway';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RegisterUserDto } from './users/Dtos/register-user.dto';
import { NotifTestDto } from './users/Dtos/notif-test.dto';
/* import setTZ from 'set-tz'; */
@Controller()
export class AppController {
  constructor(private readonly appService: AppService, private gateway : SocketIoGateway) {
 
   /*  setTZ('Africa/Casablanca'); */
    /*   const db = firebase.firestore();
    const doc = db.collection('delivery_men');

    const observer = doc.onSnapshot(
      (docSnapshot) => {
        console.log(`Received new doc snapshot: ${JSON.stringify(docSnapshot.docChanges())}`);  
        docSnapshot.docChanges().forEach(change => {
            console.log(change.type);
            console.log('Modified Driver: ', change.doc.data(), change.doc.id);
            const message = {
                sender: change.doc.data().first_name+" "+change.doc.data().second_name,
                room: change.doc.id,
                message: {
                  lastPositionLatitude: change.doc.data()?.last_position?.latitude,
                  lastPositionLongitude: change.doc.data()?.last_position?.longitude,
                  lastPositionTime: change.doc.data()?.last_position_time
                }
            }
            if(change.doc.data().last_position) this.gateway.emitFromNestJs(message);
          
        });
      },
      (err) => {
        console.log(`Encountered error: ${err}`);
      },
    ); */
  }

  @Get('/test')
  getTest(@Req() request: Request): string {
    return JSON.stringify(this.appService.getHello()) + request['user']?.email;
  }
  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @ApiTags('Notifications')
  @ApiBearerAuth('JWT')
  @Post('notifications/send')
  @ApiOperation({
    summary:
      'TestSendNotif',
  })
  async registerUser(@Body() notifDto: NotifTestDto) {
  /*   if(regDto.password != regDto.c_password){
      throw new HttpException({success:false, message: "Les mots de passes ne correspondent pas"}, 400)
    } */
    return await this.appService.sendNotif(
      notifDto.token,
      notifDto.title,
      notifDto.message,
    );
  }

}
