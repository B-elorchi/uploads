/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-var-requires */
import { RequestMethod } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerDocumentOptions, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';
const { initializeApp, applicationDefault, cert } = require('firebase-admin/app');
const { getFirestore, Timestamp, FieldValue } = require('firebase-admin/firestore');
const serviceAccount = require('../valet-club-dev-e2559-firebase-adminsdk-htmmv-ca11f61a86.json');
import * as firebase from 'firebase-admin'
import { ValidationPipe } from '@nestjs/common/pipes/validation.pipe';
/* export const app = firebase.initializeApp({
  credential: firebase.credential.cert(serviceAccount),
});
export  const auth = getAuth(app); */

async function bootstrap() {
  firebase.initializeApp({
    credential: firebase.credential.cert(serviceAccount),
  });
  firebase.firestore().settings({
    ignoreUndefinedProperties: true,
  });

  /* initializeApp({
    credential: cert(serviceAccount)
  });
  
  const db = getFirestore();


  const docRef = db.collection("user").doc('alovelace');

  await docRef.set({
    first: 'Ada',
    last: 'Lovelace',
    born: 1815
  });

  const aTuringRef = db.collection("user").doc('aturing');

  await aTuringRef.set({
    'first': 'Alan',
    'middle': 'Mathison',
    'last': 'Turing',
    'born': 1912
  });



  const snapshot = await db.collection("user").get();
  snapshot.forEach((doc) => {
    console.log(doc.id, '=>', doc.data());
  }); */


  
  const app = await NestFactory.create(AppModule,{
    cors: true
   /*  httpsOptions: {
      key: '/etc/apache2/ssl/keys/gofleet-api-key.key',
      cert: '/etc/apache2/ssl/certs/gofleet-api-cert.pem',
    } */
  });


  app.useGlobalPipes(new ValidationPipe());
  
  app.setGlobalPrefix('/api/v1', {
    exclude: [{ path: 'confirm-email', method: RequestMethod.GET }],
  });

  const config = new DocumentBuilder()
  .setTitle('Valet CLub Api')
  .setDescription('The ValetClun Backend Service API description')
  .setVersion('1.0')
  .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },'JWT')
  .addTag('Auth')
  .addTag('Valets')
  .addTag('Clients')
  .addTag('Operations')
  .addTag('Hotspots')
  .addTag('Client-Account')
  .addTag('Valet-Account')
  .addTag('Payments')
  .addTag('Users')
  
  .build();
  
  const options: SwaggerDocumentOptions =  {
    operationIdFactory: (
      controllerKey: string,
      methodKey: string
    ) => methodKey
  };
  const document = SwaggerModule.createDocument(app, config, options);
  SwaggerModule.setup('', app, document);

  await app.listen(process.env.PORT || 3001);
  console.log(`Valet Club Backend Application is running on: ${await app.getUrl()}`);
}
bootstrap();
