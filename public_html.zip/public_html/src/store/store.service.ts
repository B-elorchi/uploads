/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { CreateStoreDto } from './Dtos/createStore.dto';
import * as firebase from 'firebase-admin';
@Injectable()
export class StoreService {
  createStore = async (createStoreDto: CreateStoreDto) => {
    try {
      const db = firebase.firestore();

      const existingStore = await db
        .collection('stores')
        .where('idMagasin', '==', createStoreDto.idMagasin)
        .get()
        .then((querySnap) => {
            console.log(querySnap);
            querySnap.forEach((doc)=>{
                console.log(doc.data());
            })
           
          if (querySnap.empty || querySnap.size == 0) {
            return false;
          }else {
            return true;
          }
        });
        if(!existingStore){
            const storeRef = await db
            .collection('stores')
            .add({
              ...createStoreDto,
              creationTime: new Date(),
            })
            .then((storeRef) => {
              return storeRef;
            })
            .catch((error) => {
              return error;
            });
    
          if (storeRef.id) {
            console.log('Store created Successfully ==> ' + storeRef.id);
            /*    console.log((await userRef.get()).data()) */
            return {
              store: {
                ...(await storeRef.get()).data(),
                id: storeRef.id,
              },
              success: true,
              message : "Magasin crée avec succés" 
            };
          } else {
            return { store: storeRef, success: false, message : "Référence de magasin introuvable" };
          }
        }else{
            return { success: false, message : "Un magasin portant le même ID existe déjà"};

        }
     
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };

  getStores = async () => {
    try {
      const db = firebase.firestore();

      let storesData = [];
      const stores = await db
        .collection('stores')
        .get().then((qs)=>{
            storesData = qs.docs.map(doc => new Object({...doc.data(), id: doc.id}));
        });
        
        return { success: true, data: {storesData}, message: "Liste des magasins envoyée avec succés"}
      
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };

  getStoreById = async (id) => {
    try {
        const db = firebase.firestore();
        return await db
        .collection('stores').doc(id).get().then(
            (qs)=>{
                if(qs.exists){
                    return { success: true, data: {...qs.data(),id: qs.id}, message: "Données Magasin envoyée avec succés"}
                }else{
                    return { success: false, message: "Ce magasin n\'existe pas"}
                }
            }
        ).catch(error=>{
            return { success: false, message: error.message}
        });
      
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };

  updateStore = async (id, updateStoreDto) => {
    try {
        const db = firebase.firestore();
        const isStoreExisting  = 
            await db.collection('stores').doc(id).get()
            .then((qs)=>{
                if(qs.exists){
                    return { success: true, data: {...qs.data(), id: qs.id }, message: "Données Magasin envoyée avec succés"}
                }else{
                    return { success: false, message: "Ce magasin n\'existe pas", data: null}
                }
            }).catch(error=>{
                return { success: false, message: error.message, data: null}
            });
      
            if(isStoreExisting.success === true){
                return await db
                .collection('stores').doc(id)
                .update({
                  ...updateStoreDto,
                  updateTime: new Date(),
                })
                .then((writeResult) => {
                    return { success: true, data: isStoreExisting.data, message: "Données Magasin mis à jour avec succés"}
                })
                .catch((error) => {
                    return { success: false, message: error.message, data: null}
                });
            }else{
                return { success: false, message : "Ce magasin n\'existe pas"};
            }
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };

  deleteStore = async (id) => {
    try {
        const db = firebase.firestore();
        return await db
        .collection('stores').doc(id).get().then(
            (qs)=>{
                if(qs.exists){
                    db.collection('stores').doc(id).delete();
                    return { success: true,id: qs.id, message: "Magasin supprimé avec succés"}
                }else{
                    return { success: false, message: "Ce magasin n\'existe pas"}
                }
            }
        )
      
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };
}
