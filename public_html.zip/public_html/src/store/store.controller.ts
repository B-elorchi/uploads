/* eslint-disable prettier/prettier */
import { Body, Controller, Delete, Get, Param, Post, Put } from '@nestjs/common';

import { ApiBearerAuth, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { CreateStoreDto } from './Dtos/createStore.dto';
import { UpdateStoreDto } from './Dtos/updateStore.dto';
import { StoreService } from './store.service';
@Controller({
  path: 'app/stores',
  version: '1', // 👈
})
@ApiTags('Stores')
@ApiBearerAuth('JWT')
export class StoreController {
  constructor(private readonly storeService: StoreService) {}

  @Get()
  @ApiOperation({
    summary:
      'Get All Stores Data',
  })
  async getStore() {
    return await this.storeService.getStores();
  }

  @Post()
  @ApiOperation({
    summary:
      'Create a New Store Entity',
  })
  async createStore(@Body() createStoreDto: CreateStoreDto) {
    return await this.storeService.createStore(createStoreDto);
  }

  @Get(':id')
  @ApiOperation({
    summary:
      'Get Store Data By Id',
  })
  @ApiParam({
    name: 'id',
    description: 'The Store Document ID',
  })
  async getStoreById(@Param() params) {
    return await this.storeService.getStoreById(params.id);
  }

  @Put(':id')
  @ApiOperation({
    summary:
      'Update Store Data By Id',
  })
  @ApiParam({
    name: 'id',
    description: 'The Store Document ID',
  })
  async updateStore(@Param('id') id: string, @Body() updateStoreDto: UpdateStoreDto) {
     return await this.storeService.updateStore(id, updateStoreDto); 
  }


  @Delete(':id')
  @ApiOperation({
    summary:
      'Delete Store Collection By Id',
  })
  @ApiParam({
    name: 'id',
    description: 'The Store Document ID',
  })
  async deleteStore(@Param('id') id: string) {
     return await this.storeService.deleteStore(id); 
  }
}
