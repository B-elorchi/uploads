/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined,  IsLatitude, IsLongitude, IsNotEmpty, IsString } from 'class-validator';


export class CreateStoreDto {

 @ApiProperty()
 @IsNotEmpty({ message: "L'id du Magasin est requis",})
 @IsString({ message: "L'id du Magasin ne doit pas être vide",})
 @IsDefined({message: 'Vous devez renseigner un id du Magasin', }) 
 @IsNotEmpty({ message: "L'id du Magasin est requis",})
 idMagasin: string;

 @ApiProperty()
 @IsNotEmpty({ message: "Le libelé du Magasin est requis",})
 @IsString({ message: "Le libelé du Magasin ne doit pas être vide",})
 @IsDefined({message: 'Vous devez renseigner un libelé du Magasin', }) 
 @IsNotEmpty({ message: "Le libelé du Magasin est requis",})
 libeleMagasin: string;
 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner une Latitude', }) 
 @IsNotEmpty({ message: "La Latitude est requise",})
 @IsLatitude({ message: "Format de Latitude invalide",})
 latitude: number;

 @ApiProperty()
 @IsDefined({message: 'Vous devez renseigner une Longitude', }) 
 @IsNotEmpty({ message: "La Longitude est requise",})
 @IsLongitude({ message: "Format de Longitude invalide",})
 longitude: number;
  
 @ApiProperty()
 @IsNotEmpty({ message: "La ville du Magasin est requise",})
 @IsString({ message: "La ville du Magasin ne doit pas être vide",})
 @IsDefined({message: 'Vous devez renseigner une ville du Magasin', }) 
 @IsNotEmpty({ message: "La ville du Magasin est requise",})
 city: string;
}
