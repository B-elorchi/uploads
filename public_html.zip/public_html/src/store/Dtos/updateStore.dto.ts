/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined,  IsLatitude, IsLongitude, IsNotEmpty, IsOptional, IsString } from 'class-validator';


export class UpdateStoreDto {

 @ApiProperty()
 @IsOptional()
 @IsNotEmpty({ message: "L'id du Magasin est requis",})
 @IsString({ message: "L'id du Magasin ne doit pas être vide",})
 idMagasin: string;

 @ApiProperty()
 @IsOptional()
 @IsNotEmpty({ message: "Le libelé du Magasin est requis",})
 @IsString({ message: "Le libelé du Magasin ne doit pas être vide",})
 libeleMagasin: string;
 
 @ApiProperty()
 @IsOptional()
 @IsNotEmpty({ message: "La Latitude est requise",})
 @IsLatitude({ message: "Format de Latitude invalide",})
 latitude: number;

 @ApiProperty() 
 @IsOptional()
 @IsNotEmpty({ message: "La Longitude est requise",})
 @IsLongitude({ message: "Format de Longitude invalide",})
 longitude: number;
  
 @ApiProperty()
 @IsNotEmpty({ message: "La ville du Magasin est requise",})
 @IsString({ message: "La ville du Magasin ne doit pas être vide",})
 @IsDefined({message: 'Vous devez renseigner une ville du Magasin', }) 
 @IsNotEmpty({ message: "La ville du Magasin est requise",})
 city: string;
}
