/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsEmail, IsNotEmpty, IsString } from 'class-validator';

export class RegisterDto {

 @ApiProperty()

 @IsNotEmpty({ message: "Le Prénom est requis",})
 @IsString({ message: "Le Prénom ne doit pas être vide",})
 @IsDefined({message: 'Vous devez renseigner un Prénom', })
 firstName: string;


 @ApiProperty()

 @IsNotEmpty({ message: "Le Nom est requis",})
 @IsString({ message: "Le Nom ne doit pas être vide",})
 @IsDefined({message: 'Vous devez renseigner un Nom', })
 secondName: string;

  @ApiProperty()
  @IsNotEmpty({ message: "L'email ne doit pas être vide",})
  @IsEmail(undefined,{message: 'Veuillez saisir un email valide'})
  @IsDefined({message: 'Vous devez renseigner un Email', })
  email: string;
  
  @ApiProperty()
  @IsNotEmpty({ message: "Le mot de passe est requis",})
  @IsDefined({message: 'Veuillez saisir le mot de passe', })
  password: string;

  @ApiProperty()

  @IsNotEmpty({ message: "Le Numéro de tél est requis",})
  @IsDefined({message: 'Vous devez renseigner un Numéro de tél', })
  phoneNumber: string;
}
