/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsEmail, IsNotEmpty, IsString } from 'class-validator';

export class LoginEmailDto {
  @ApiProperty()
  @IsNotEmpty({ message: "L'email ne doit pas être vide",})
  @IsEmail(undefined,{message: 'Veuillez saisir un email valide'})
  @IsDefined({message: 'Vous devez renseigner un Email', })
  email: string;
  
  @ApiProperty()
  @IsNotEmpty({ message: "Le mot de passe est requis",})
  @IsDefined({message: 'Veuillez saisir le mot de passe', })
  password: string;

  
}
