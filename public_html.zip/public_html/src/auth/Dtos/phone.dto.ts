/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsNotEmpty, IsString } from 'class-validator';

export class PhoneDto {
  @ApiProperty()

  @IsNotEmpty({ message: "Le Numéro de tél est requis",})
  @IsDefined({message: 'Vous devez renseigner un Numéro de tél', })
  phoneNumber: string;

  
}
