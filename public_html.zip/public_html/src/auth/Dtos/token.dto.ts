/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsEmail, IsNotEmpty, IsString } from 'class-validator';

export class TokenDto {
  @ApiProperty()

  @IsNotEmpty({ message: "Le token ne doit pas etre vide",})
  @IsDefined({message: 'Vous devez renseigner un TOKEN', })
  token: string;

  
}
