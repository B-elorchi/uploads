/* eslint-disable prettier/prettier */
import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response } from 'express';
import * as firebase from 'firebase-admin';

 // eslint-disable-next-line @typescript-eslint/no-var-requires

@Injectable()
export class ValetMiddleware implements NestMiddleware {
  private defaultApp: any = firebase;

  constructor() {
  
  }
  use(req: any, res: any, next: () => void) {

    const db = firebase.firestore();

    const token = req.headers.authorization;
    if( token != null && token != ''){
      this.defaultApp.auth().verifyIdToken(token.replace('Bearer ',''))
      .then(async decodedToken =>{
        const user = {
          email: decodedToken.email,
        }

        let userDoc = (await db.collection("user").doc(decodedToken.user_id).get()).data();

        if(userDoc && userDoc.role && !['admin','back-office','valet'].includes(userDoc.role)){
          this.accessDenied(req.url, res, "Cette route est restreinte à l'utilisation des valets ValetClub. Vous ne pouvez pas y accéder.");
        }
        console.log("Valet authorized ", decodedToken.user_id);
        
        req['user']=user;
        next();
      }).catch(error=>{
        console.log(error);
        this.accessDenied(req.url, res);
      })
    }else{
      this.accessDenied(req.url, res);
    }
  }
  accessDenied(url: string, res: Response, message: string= "Access Denied") {
    res.status(403).json({
      statusCode: 403,
      timestamp: new Date().toISOString(),
      path:url,
      message: message
    });
  }
}
