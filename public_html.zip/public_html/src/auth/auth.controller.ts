import { Get, HttpException, HttpStatus, Post, Res } from '@nestjs/common';
import { Body } from '@nestjs/common';
import { Controller } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { AuthService } from './auth.service';
import { EmailResetDto } from './Dtos/emailReset.dto';
import { LoginEmailDto } from './Dtos/loginEmail.dto';
import { PhoneDto } from './Dtos/phone.dto';
import { RegisterDto } from './Dtos/register.dto';
import { TokenDto } from './Dtos/token.dto';
import { RegisterUserDto } from 'src/users/Dtos/register-user.dto';
import { UsersService } from 'src/users/users.service';
import { RegisterValetDto } from 'src/_global-dtos/register-valet.dto';
import { RegisterResponsableDto } from 'src/_global-dtos/register-responsable.dto';
@ApiTags('Auth')
@Controller('auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly userServ: UsersService) {}

  @Post('/token')
  @ApiTags('Auth')
  @ApiOperation({
    summary:
      'Authenticate Delivery Man on Firebase and generate idToken and jwtToken',
  })
  async getDeliveryManToken(@Body() loginEmailDto: LoginEmailDto, @Res() res : Response) {
    const responseData =  await await this.authService.loginAndGetToken(
      loginEmailDto.email,
      loginEmailDto.password,
    );
    return res.status(HttpStatus.OK).json(responseData);
  }

  @Post('/login/email')
  @ApiTags('Auth')
  @ApiOperation({
    summary:
      'Authenticate User on Firebase and generate idToken and jwtToken Email And Password',
  })
  async loginByEmailAndPassword(@Body() loginEmailDto: LoginEmailDto, @Res() res : Response) {
    const responseData =  await await this.authService.loginAndGetToken(
      loginEmailDto.email,
      loginEmailDto.password,
    );
    return res.status(HttpStatus.OK).json(responseData);
  }

  @Post('/getUserByPhoneNumber')
  @ApiTags('users')
  @ApiOperation({
    summary:
      'Firebase get User By Phone Number to disable automatic signups on new phone login attempt',
  })
  async getUserByPhoneNumber(@Body() phoneDto: PhoneDto) {
    return await this.authService.getUserByPhoneNumber(phoneDto.phoneNumber);
  }

  @Post('/emailLogin')
  @ApiOperation({ summary: 'Firebase Login using Email Provider' })
  async loginByEmail(@Body() loginEmailDto: LoginEmailDto) {
    return await this.authService.loginByEmail(
      loginEmailDto.email,
      loginEmailDto.password,
    );
  }

  @Post('/register/valet')
  @ApiOperation({
    summary:
      'Register New User with Valet Role and create Both Document Entities for User and Valet associated By userRef using PhoneAuth & EmailAuth Firebase Providers',
  })
  async registerValet(@Body() regDto: RegisterValetDto) {
    if(regDto.password != regDto.c_password){
      throw new HttpException({success:false, message: "Les mots de passes ne correspondent pas"}, 400)
    }
    return await this.authService.newValet(
      regDto.email,
      regDto.password,
      regDto.first_name,
      regDto.second_name,
      regDto.phone_number,
      regDto.cin_number,
      regDto.num_permis
    );
  }


  @Post('/register/client')
  @ApiOperation({
    summary:
      'Register New User with Client Role and create Both Document Entities for User and Client associated By userRef using PhoneAuth & EmailAuth Firebase Providers',
  })
  async registerClient(@Body() regDto: RegisterUserDto) {
    if(regDto.password != regDto.c_password){
      throw new HttpException({success:false, message: "Les mots de passes ne correspondent pas"}, 400)
    }
    return await this.authService.registerClient(
      regDto.email,
      regDto.password,
      regDto.first_name,
      regDto.second_name,
      regDto.phone_number,
    );
  }

  @Post('/register/responsable')
  @ApiOperation({
    summary:
      'Register New User with Client Role and create Both Document Entities for User and Client associated By userRef using PhoneAuth & EmailAuth Firebase Providers',
  })
  async registerResponsable(@Body() regDto: RegisterResponsableDto) {
    if(regDto.password != regDto.c_password){
      throw new HttpException({success:false, message: "Les mots de passes ne correspondent pas"}, 400)
    }
    return await this.authService.registerResponsable(
      regDto.email,
      regDto.password,
      regDto.first_name,
      regDto.second_name,
      regDto.phone_number,
      regDto.hotspot_ref
    );
  }
/* 
  @Post('/register/partner')
  @ApiOperation({
    summary:
      'Register New User with Partner Role using PhoneAuth & EmailAuth Firebase Providers',
  })
  async registerPartner(@Body() regDto: RegisterDto) {
    return await this.authService.registerPartner(
      regDto.email,
      regDto.password,
      regDto.firstName,
      regDto.secondName,
      regDto.phoneNumber,
    );
  }
 */
  @Post('/resetPassword')
  @ApiOperation({ summary: 'Firebase Login using Email Provider' })
  async resetPassword(@Body() emailResetDto: EmailResetDto) {
    return await this.authService.resetPassword(emailResetDto.email);
  }

  @Post('/login/phone')
  @ApiOperation({ summary: 'Authenticate User on Firebase and generate idToken and jwtToken Email And Password' })
  async loginByPhone(@Body() phoneDto: PhoneDto) {
    return await this.authService.loginByPhone(phoneDto.phoneNumber);
  }

  @Post('/register/back-office')
  @ApiOperation({
    summary:
      'Register New Admin  User',
  })
  async registerAdminBackOfficeUser(@Body() regDto: RegisterUserDto) {
    if(regDto.password != regDto.c_password){
      throw new HttpException({success:false, message: "Les mots de passes ne correspondent pas"}, 400)
    }
    return await this.userServ.createBackoffice(
      regDto,
      "back-office"
    );
  }

  @Post('/admin/login')
  @ApiOperation({ summary: 'Firebase Admin Login using Email Provider' })
  async loginAdmin(@Body() loginEmailDto: LoginEmailDto) {
    return await this.authService.loginAdminByEmail(
      loginEmailDto.email,
      loginEmailDto.password,
    );
  }
}
