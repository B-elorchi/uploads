/* eslint-disable prettier/prettier */
import { HttpException, Injectable } from '@nestjs/common';
import * as firebase from 'firebase-admin';
import axios from 'axios';
import { DocumentReference } from '@google-cloud/firestore';
import { Valet } from 'src/_models/valet.model';
import { Client } from 'src/_models/client.model';

@Injectable()
export class AuthService {
  async generateFirebaseIdToken(userId) {
    const token = await firebase.auth().createCustomToken(userId);

    return { token: token };
  }

  async getUserByPhoneNumber(phone: string) {
    return await firebase
      .auth()
      .getUserByPhoneNumber(phone)
      .then((user) => {
        return { user: user, success: true, message: 'Succeeded' };
      })
      .catch((error) => {
        if(error.code == "auth/user-not-found") error.message = "Ce Numéro de téléphone n'est associé à aucun compte."
        return { user: null, success: false, message: error.message, code: error.code };
      });
  }


  async newValet(email, password, firstName, secondName,  phoneNumber, cinNumber?, permisNumber?) {
    
    console.log(firstName);
    console.log(secondName);
    console.log(email);
    console.log(password);
    console.log(phoneNumber);

    const db = firebase.firestore();

    const authUser =  await firebase.auth().createUser({
      email: email,
      emailVerified: false,
      phoneNumber: phoneNumber,
      password: password,
      displayName: firstName +' '+ secondName,
      photoURL: process.env.BACKEND_URL+'/static/profile_picture.png',
      disabled: false,
    })
    .then((userRecord) => {
      console.log('Successfully created new user:', userRecord.uid);
     
      return { userAuth: userRecord, success: true, message: 'Utilisateur crée avec succés', code:"success"};
    })
    .catch((error) => {
      console.log('Error creating new user:', error);
      if(error.code =="auth/email-already-exists") error.message = "Cette adresse Email est utilisée par un autre compte";
      return { userAuth: null, success: false, message: error.message, code:error.code};
    });

    if(authUser.success === true){
      await firebase.auth().setCustomUserClaims(authUser.userAuth.uid, {role: "valet"}).then(() => {
        console.log(" The new custom claims will propagate to the valets's ID token ", authUser.userAuth.uid)
      });
      console.log('It s success')
      const userData = {
        uid: authUser.userAuth.uid,
        first_name : firstName,
        second_name : secondName,
        email: email,
        phone_number: phoneNumber,
        disabled: false,
        email_verified: true,
        role: "valet",
        creation_time: new Date(),
        photo_url: process.env.BACKEND_URL+'/static/profile_picture.png'
      }
      
       const userRef: DocumentReference =  await db.collection("user").doc(userData.uid).set(userData)
          .then( (writeResult)=>{
              return db.collection("user").doc(userData.uid);
          })
          .catch((error)=> {
              return error;
          });
     
       if(userRef.id){
          const valetData: Valet = {
            first_name: firstName,
            second_name: secondName,
            userRef: userRef,
            reserved: false,
            cin_number: cinNumber ? cinNumber : null,
            num_permis: permisNumber ? permisNumber : null,
            status: 1,
            created_at: new Date(),
            phone_number: userData.phone_number,
            photo_url: process.env.BACKEND_URL+'/static/profile_picture.png',
            email: email,

          }
          const valetAddRef = await db.collection('valet').add(valetData)
          .then(valetAddRef =>{
            return valetAddRef;
          })
          .catch(error => {
            return error;
          });
         
          if(valetAddRef.id){
            console.log("Valet Created succesfully : ",valetAddRef.id);
            console.log(valetAddRef);
            console.log((await userRef.get()).data())
            return {... authUser, user: (await userRef.get()).data(), valet: {... (await valetAddRef.get()).data(), valet: {...valetData, id: valetAddRef.id}}}
          }else{
            return {... authUser, user:   (await userRef.get()).data(), delivery_man: null, id: null}
          }
       }else{
          return {...authUser, valetCreateError: userRef}
       }
    }else{
      return authUser;
    }
  }
/*   async registerValet(email, password, firstName, secondName,  phoneNumber) {
    
    console.log(firstName);
    console.log(secondName);
    console.log(email);
    console.log(password);
    console.log(phoneNumber);

    const db = firebase.firestore();

    const authUser =  await firebase.auth().createUser({
      email: email,
      emailVerified: false,
      phoneNumber: phoneNumber,
      password: password,
      displayName: firstName +' '+ secondName,
      photoURL: process.env.BACKEND_URL+'/static/profile_picture.png',
      disabled: false,
    })
    .then((userRecord) => {
      console.log('Successfully created new user:', userRecord.uid);
     
      return { userAuth: userRecord, success: true, message: 'Utilisateur crée avec succés', code:"success"};
    })
    .catch((error) => {
      console.log('Error creating new user:', error);
      if(error.code =="auth/email-already-exists") error.message = "Cette adresse Email est utilisée par un autre compte";
      return { userAuth: null, success: false, message: error.message, code:error.code};
    });

    if(authUser.success === true){
      await firebase.auth().setCustomUserClaims(authUser.userAuth.uid, {role: "valet"}).then(() => {
        console.log(" The new custom claims will propagate to the valets's ID token ", authUser.userAuth.uid)
      });
      console.log('It s success')
      const userData = {
        uid: authUser.userAuth.uid,
        first_name : firstName,
        second_name : secondName,
        email: email,
        phone_number: phoneNumber,
        disabled: false,
        email_verified: true,
        role: "valet",
        creation_time: new Date(),
        photo_url: process.env.BACKEND_URL+'/static/profile_picture.png'
      }
      
       const userRef: DocumentReference =  await db.collection("user").doc(userData.uid).set(userData)
          .then( (writeResult)=>{
              return db.collection("user").doc(userData.uid);
          })
          .catch((error)=> {
              return error;
          });
     
       if(userRef.id){
          const valetData: Valet = {
            first_name: firstName,
            second_name: secondName,
            userRef: userRef,
            status: 1,
            created_at: new Date(),
            phone_number: userData.phone_number,
            photo_url: process.env.BACKEND_URL+'/static/profile_picture.png',
            email: email,

          }
          const valetAddRef = await db.collection('valet').add(valetData)
          .then(valetAddRef =>{
            return valetAddRef;
          })
          .catch(error => {
            return error;
          });
         
          if(valetAddRef.id){
            console.log("Valet Created succesfully : ",valetAddRef.id);
            console.log(valetAddRef);
            console.log((await userRef.get()).data())
            return {... authUser, user: (await userRef.get()).data(), valet: {... (await valetAddRef.get()).data(), valet: {...valetData, id: valetAddRef.id}}}
          }else{
            return {... authUser, user:   (await userRef.get()).data(), delivery_man: null, id: null}
          }
       }else{
          return {...authUser, valetCreateError: userRef}
       }
    }else{
      return authUser;
    }
  } */

  async registerClient(email, password, firstName, secondName,  phoneNumber) {
    
    console.log(firstName);
    console.log(secondName);
    console.log(email);
    console.log(password);
    console.log(phoneNumber);

    const db = firebase.firestore();

    const authUser =  await firebase.auth().createUser({
      email: email,
      emailVerified: false,
      phoneNumber: phoneNumber,
      password: password,
      displayName: firstName +' '+ secondName,
      photoURL: process.env.BACKEND_URL+'/static/profile_picture.png',
      disabled: false,
    })
    .then((userRecord) => {
      console.log('Successfully created new user:', userRecord.uid);
     
      return { userAuth: userRecord, success: true, message: 'Utilisateur crée avec succés', code:"success"};
    })
    .catch((error) => {
      console.log('Error creating new user:', error);
      if(error.code =="auth/email-already-exists") error.message = "Cette adresse Email est utilisée par un autre compte";
      return { userAuth: null, success: false, message: error.message, code:error.code};
    });

    if(authUser.success === true){
      await firebase.auth().setCustomUserClaims(authUser.userAuth.uid, {role: "client"}).then(() => {
        console.log(" The new custom claims will propagate to the valets's ID token ", authUser.userAuth.uid)
      });
      console.log('It s success')
      const userData = {
        uid: authUser.userAuth.uid,
        first_name : firstName,
        second_name : secondName,
        email: email,
        phone_number: phoneNumber,
        disabled: false,
        email_verified: true,
        role: "client",
        creation_time: new Date(),
        photo_url: process.env.BACKEND_URL+'/static/profile_picture.png'
      }
      
       const userRef: DocumentReference =  await db.collection("user").doc(userData.uid).set(userData)
          .then( (writeResult)=>{
              return db.collection("user").doc(userData.uid);
          })
          .catch((error)=> {
              return error;
          });
     
       if(userRef.id){
          const clientData: Client = {
            first_name: firstName,
            second_name: secondName,
            userRef: userRef,
            status: 1,
            created_at: new Date(),
            phone_number: userData.phone_number,
            photo_url: process.env.BACKEND_URL+'/static/profile_picture.png',
            email: email,

          }
          const clientAddRef = await db.collection('client').add(clientData)
          .then(clientAddRef =>{
            return clientAddRef;
          })
          .catch(error => {
            return error;
          });
         
          if(clientAddRef.id){
            console.log("Client Created succesfully : ",clientAddRef.id);
            console.log(clientAddRef);
            console.log((await userRef.get()).data())
            return {... authUser, user: (await userRef.get()).data(), valet: {... (await clientAddRef.get()).data(), valet: {...clientData, id: clientAddRef.id}}}
          }else{
            return {... authUser, user:   (await userRef.get()).data(), valet: null, id: null}
          }
       }else{
          return {...authUser, clientCreateError: userRef}
       }
    }else{
      return authUser;
    }
  }

  async registerResponsable(email, password, firstName, secondName,  phoneNumber, hotspot_ref) {

    const db = firebase.firestore();

    const authUser =  await firebase.auth().createUser({
      email: email,
      emailVerified: false,
      phoneNumber: phoneNumber,
      password: password,
      displayName: firstName +' '+ secondName,
      photoURL: process.env.BACKEND_URL+'/static/profile_picture.png',
      disabled: false,
    })
    .then((userRecord) => {
      console.log('Successfully created new user:', userRecord.uid);
     
      return { userAuth: userRecord, success: true, message: 'Utilisateur crée avec succés', code:"success"};
    })
    .catch((error) => {
      console.log('Error creating new user:', error);
      if(error.code =="auth/email-already-exists") error.message = "Cette adresse Email est utilisée par un autre compte";
      return { userAuth: null, success: false, message: error.message, code:error.code};
    });

    if(authUser.success === true){
      await firebase.auth().setCustomUserClaims(authUser.userAuth.uid, {role: "responsable"}).then(() => {
        console.log(" The new custom claims will propagate to the valets's ID token ", authUser.userAuth.uid)
      });
      console.log('It s success')
      const userData = {
        uid: authUser.userAuth.uid,
        first_name : firstName,
        second_name : secondName,
        email: email,
        phone_number: phoneNumber,
        disabled: false,
        email_verified: true,
        role: "responsable",
        creation_time: new Date(),
        photo_url: process.env.BACKEND_URL+'/static/profile_picture.png'
      }
      
       const userRef: DocumentReference =  await db.collection("user").doc(userData.uid).set(userData)
        .then( (writeResult)=>{
            return db.collection("user").doc(userData.uid);
        })
        .catch((error)=> {
            return error;
        });
     
        if(userRef.id){
          return {... authUser, user: (await userRef.get()).data(), id: userRef.id}
       }else{
          return {...authUser, userCreateError: userRef}
       }
    }else{
      return authUser;
    }
  }

  async registerAdmin() {


    const db = firebase.firestore();

    const authUser =  await firebase.auth().createUser({
      email: "admin@gofleet.ma",
      emailVerified: false,
      phoneNumber: "+212619626222",
      password: "GoFleet23",
      displayName: "Said",
      photoURL: 'https://gofleet.evidence-way.com/static/profile_picture.png',
      disabled: false,
     
    })
    .then((userRecord) => {
      console.log('Successfully created new admin user:', userRecord.uid);
      // See the UserRecord reference doc for the contents of userRecord.
    
   

    /*   const userRef = db.collection("user").doc(userRecord.uid);

        userRef.update({
          role:'delivery_man',
          creation_time: new Date()
        });  */

        /* console.log(res); */
      return { userAuth: userRecord, success: true, message: 'Utilisateur crée avec succés', code:"success"};
    })
    .catch((error) => {
      console.log('Error creating new user:', error);
      if(error.code =="auth/email-already-exists") error.message = "Cette adresse Email est utilisée par un autre compte";
      return { userAuth: null, success: false, message: error.message, code:error.code};
    });

    if(authUser.success === true){
      console.log('It s success')
      const userData = {
        uid: authUser.userAuth.uid,
        display_name : "Said",
        email: "admin@valetclub.ma",
        phone_number: "+212611111111",
        disabled: false,
        emailVerified: true,
        role: "admin",
        created_time: new Date(),
        photo_url:  process.env.BACKEND_URL+'/static/profile_picture.png'
      }
      
       const userRef: DocumentReference =  await db.collection("user").doc(userData.uid).set(userData)
       .then( (writeResult)=>{
          return db.collection("user").doc(userData.uid);
       })
       .catch((error)=> {
          return error;
       });
     
       if(userRef.id){
          return {... authUser, user: (await userRef.get()).data(), id: userRef.id}
       }else{
          return {...authUser, userCreateError: userRef}
       }
       /* return {...authUser, delivery_man: addDeliveryManRef}; */
    }else{
      return authUser;
    }
  }

  async loginByEmail(email, password) {
    console.log('Hello Oussama');

    const db = firebase.firestore();
    const data = JSON.stringify({
      "email": email,
      "password": password,
      "returnSecureToken": true
    });
    
    const config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${process.env.IDENTITY_TOOLKIT_API_KEY}`,
      headers: { 
        'Content-Type': 'application/json'
      },
      data : data
    };
    
    const userLogin = await axios(config)
                        .then((user)=>{
                           /*  console.log(user); */
                            return { user: user.data.localId, idToken: user.data.idToken, success: true, message: 'Connecté avec succés', code:"success"};
                        }).catch((error) => {
                            console.log(JSON.stringify(error.response.data));
                            return { user: null,  idToken:null, success: false, message: error.response.data.error.message, code:  error.response.data.error.code };
                        });

  
    if ( userLogin.success === true ) {
      console.log('Successfully posting data to Custom Token Method');
      const response = await firebase
        .auth()
        .createCustomToken(userLogin.user)
        .then((token) => {
       
          return {
            token: token,
            user: userLogin.user,
            idToken: userLogin.idToken,
            success:true,
            message: "Token created successfully",
            code: "success"
          };
        })
        .catch((error) => {
          return { success: false, message: error.message, code: error.code };
        });

        const userRef = await db.collection("user").doc(userLogin.user);
        const userData = (await userRef.get()).data();
       /*  console.log("userData");
        console.log(userData); */
        if(userData && userData.role == "delivery_man"){
          const deliveryManRef = await db.collection("delivery_men")
          .where("userRef", "==",userRef );

          const snapshot = await deliveryManRef.get();
          if (snapshot.empty) {
          console.log('No matching documents.');
          return {...response, deliveryMan: null, success:false, message : "Aucun Livreur n\'est associé à ce compte utilisateur"}
          }  

          /*   console.log(snapshot.docs[0].id);
          console.log(snapshot.docs[0].data()); 
          console.log(snapshot.docs[0]) */

          return {...response, deliveryMan: deliveryManRef, deliveryManData: snapshot.docs[0].data(), deliveryManId: snapshot.docs[0].id}
        }else{
          return {...response}
        }
        
      
    } else {
      return { token: null, idToken:null, success: false, message: userLogin.message, code: userLogin.code  };
    }
  }


  async loginAdminByEmail(email, password) {
    console.log('Hello Oussama');

    const db = firebase.firestore();
    const data = JSON.stringify({
      "email": email,
      "password": password,
      "returnSecureToken": true
    });
    
    const config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${process.env.IDENTITY_TOOLKIT_API_KEY}`,
      headers: { 
        'Content-Type': 'application/json'
      },
      data : data
    };
    
    const userLogin = await axios(config)
                        .then((user)=>{
                            console.log(user);
                            return { user: user.data.localId, idToken: user.data.idToken, success: true, message: 'Connecté avec succés', code:"success"};
                        }).catch((error) => {
                            console.log(JSON.stringify(error.response.data));
                            return { user: null,  idToken:null, success: false, message: error.response.data.error.message, code:  error.response.data.error.code };
                        });

  
    if ( userLogin.success === true ) {
      console.log('Successfully posting data to Custom Token Method');
      const response = await firebase
        .auth()
        .createCustomToken(userLogin.user)
        .then((token) => {
       
          return {
            token: token,
            user: userLogin.user,
            idToken: userLogin.idToken,
            success:true,
            message: "Token created successfully",
            code: "success"
          };
        })
        .catch((error) => {
          return { success: false, message: error.message, code: error.code };
        });

        const userRef = await db.collection("user").doc(userLogin.user);

        if(userRef.id){
          const userData = (await userRef.get()).data();
          if(['admin', 'back-office'].includes(userData.role)){
            return {...response, userData: userData}
          }else{
            return { token: null, idToken:null, success: false, message: "Role non autorisé", code: "Auth/RoleRestriction"  };

          }
        }else{
            return { token: null, idToken:null, success: false, message: "Aucune donnée d'utilisateur n\'est associée à ces identifiants, veuillez contacter l'administrateur", code: "Auth/ErreurInterneFatale"  };
        }

    /*      const deliveryManRef = await db.collection("delivery_men")
                                .where("userRef", "==",userRef );
        
        const snapshot = await deliveryManRef.get();
        if (snapshot.empty) {
          console.log('No matching documents.');
          return {...response, deliveryMan: null, success:false, message : "Aucun Livreur n\'est associé à ce compte utilisateur"}
        }  
         */
      /*   console.log(snapshot.docs[0].id);
        console.log(snapshot.docs[0].data()); 
        console.log(snapshot.docs[0]) */

       
      
    } else {
      return { token: null, idToken:null, success: false, message: userLogin.message, code: userLogin.code  };
    }
  }

  async resetPassword(email) {
    const data = JSON.stringify({
      "email": email,
      "requestType": "PASSWORD_RESET"
    });
    
    const config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: `https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${process.env.IDENTITY_TOOLKIT_API_KEY}`,
      headers: { 
        'Content-Type': 'application/json'
      },
      data : data
    };
    
    return await axios(config)
    .then((response) => {
      console.log(JSON.stringify(response.data));
      return {...response.data, success:true};
    })
    .catch((error) => {
      console.log(error);
      return {...error.response.data, success:false}
    });
  }




  async loginByPhone(phone) {

    const db = firebase.firestore();

    const userLogin = await firebase
      .auth()
      .getUserByPhoneNumber(phone)
      .then((user) => {
        
        return { user: user, success: true, message: 'Succeeded', code:"success"};
      })
      .catch((error) => {
        return { user: null, success: false, message: error.message, code: error.code };
      });

      console.log(userLogin);
   
      if ( userLogin.success === true ) {
        const response = await firebase
          .auth()
          .createCustomToken(userLogin.user.uid)
          .then((token) => {
         
            return {
              token: token,
              user: userLogin.user,
              success:true,
              message: "Token created successfully",
              code: "success"
            };
          })
          .catch((error) => {
            return { success: false, message: error.message, code: error.code, idToken:null, token:null};
          });
  
          const userRef = await db.collection("user").doc(userLogin.user.uid);
  
          const userData = (await userRef.get()).data();
  
          if(userData && userData.role == "client"){
            const clientData = await db.collection("client")
            .where("userRef", "==", userRef).get()
            .then((qs)=>{
              if(qs.size > 0){
                return {...qs.docs[0].data(), id: qs.docs[0].id, ref: qs.docs[0].ref};
              }else{
                return null;
              }
            })

            return { 
              success : true, 
              message: "Authentification réussie",
              data: {
                user: {... userData, id: userRef.id},
                client: clientData,
                jwtToken: response.token,
              }
            }
          }
         

          if(userData && userData.role == "valet"){
            const valetData = await db.collection("valet")
            .where("userRef", "==", userRef).get()
            .then((qs)=>{
              if(qs.size > 0){
                return {...qs.docs[0].data(), id: qs.docs[0].id, ref: qs.docs[0].ref};
              }else{
                return null;
              }
            })

            return { 
              success : true, 
              message: "Authentification réussie",
              data: {
                user: {... userData, id: userRef.id},
                valet: valetData,
                jwtToken: response.token,
              }
            }
          }
        
      } else {
        throw new HttpException({ success: false, message: userLogin.message, code:userLogin.code }, 400);
      }
  }


  async loginAndGetToken(email, password) {
    const db = firebase.firestore();
    const data = JSON.stringify({
      "email": email,
      "password": password,
      "returnSecureToken": true
    });
    
    const config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${process.env.IDENTITY_TOOLKIT_API_KEY}`,
      headers: { 
        'Content-Type': 'application/json'
      },
      data : data
    };
    
    const userLogin = await axios(config)
                        .then((user)=>{
                            /* console.log(user); */
                            return { user: user.data.localId, idToken: user.data.idToken, success: true, message: 'Connecté avec succés', code:"success"};
                        }).catch((error) => {
                            console.log(JSON.stringify(error.response.data));
                            return { user: null,  idToken:null, success: false, message: error.response.data.error.message, code:  error.response.data.error.code };
                        });

  
    if ( userLogin.success === true ) {
      const response = await firebase
        .auth()
        .createCustomToken(userLogin.user)
        .then((token) => {
       
          return {
            token: token,
            user: userLogin.user,
            idToken: userLogin.idToken,
            success:true,
            message: "Token created successfully",
            code: "success"
          };
        })
        .catch((error) => {
          return { success: false, message: error.message, code: error.code, idToken:null};
        });

        const userRef = await db.collection("user").doc(userLogin.user);

        const userData = (await userRef.get()).data();

        /*  const deliveryManRef = await db.collection("delivery_men")
                                .where("userRef", "==",userRef );
        
        const snapshot = await deliveryManRef.get();
        if (snapshot.empty) {
          throw new HttpException(
            { 
            success:false,
            message : "Aucun Livreur n\'est associé à ce compte utilisateur",
            data: {...response, deliveryMan: null}, 
          }, 400);
        }   */

        return { 
          success : true, 
          message: "Authentification réussie",
          data: {
            user: {... userData, id: userRef.id},
            jwtToken: response.idToken,
          }
        }
      
    } else {
      throw new HttpException({ success: false, message: userLogin.message, code: userLogin.code}, 400);
    }
  }
}
