/* eslint-disable prettier/prettier */
import {
  ConnectedSocket,
  MessageBody,
  OnGatewayInit,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

@WebSocketGateway({ namespace: '/socket'})
export class SocketIoGateway implements OnGatewayInit {
  @WebSocketServer() server: Server;
  
  afterInit(server: any) {
   console.log("Socket Server Successfully Initialized");
  }
  
  handleConnection(client: Socket){
    console.log("client connected : ", client.id);
  }
  handleDisconnect (client: Socket){
    console.log("client disconnected : ", client.id);
  }
 /*  @SubscribeMessage('test')
  handleMessage(@MessageBody() data: string): string {
    return data;
  }
 */
  @SubscribeMessage('sendToServer')
  handleMessage(@ConnectedSocket() client: Socket, @MessageBody() message: { sender :string, room:string, message:string }) {
   /*  console.log(message)
    console.log(client.id+" is sending a message to room "+ message.room)
    console.log("Message is dispatched to other room Members - Room : "+ message.room) */
   /*  const messageJson = JSON.parse(message); */

    this.server.to(message.room).emit('sendToClient', message);
  }


  
  emitFromNestJs(message: { sender :string, room:string, message:any }) {
    console.log(message)
    console.log("NestJs is sending a message to a DeliveryMan "+message.sender +" room "+ message.room)
    console.log("Message is dispatched to other room Members - Room : "+ message.room)

    this.server.to(message.room).emit('tracking', message);
  }
  @SubscribeMessage('joinRoom')
  handleJoinRoom(@ConnectedSocket() client: Socket,@MessageBody() room: string) {
    client.join(room)
    console.log(client.id+" Successfully Joined Room "+ room)
    this.server.emit('joinRoom', room);
  }
  @SubscribeMessage('leaveRoom')
  handleLeaveRoom(client: Socket, room: string) {
    client.join(room)
    console.log(client.id+" Successfully Left Room "+ room)
    this.server.emit('leftRoom', room);
  }
}
