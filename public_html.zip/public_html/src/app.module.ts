import { NestModule } from '@nestjs/common';
import { MiddlewareConsumer } from '@nestjs/common';
import { RequestMethod } from '@nestjs/common';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { BackOfficeMiddleware } from './auth/back-office.middleware';
import { AuthModule } from './auth/auth.module';
import { DeliveryModule } from './delivery/delivery.module';
import { ProfileModule } from './profile/profile.module';
import env from './config/env';
import { HttpModule } from '@nestjs/axios';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { SocketIoGateway } from './socket.io/socket.io.gateway';
import { StoreModule } from './store/store.module';
import { DeliveryManModule } from './delivery-man/delivery-man.module';
import { UsersModule } from './users/users.module';
import { ValetMiddleware } from './auth/valet.middleware';
import { RetryJobService } from './job/retry-job/retry-job.service';
import { ScheduleModule } from '@nestjs/schedule';
import { DeliveryService } from './delivery/delivery.service';
import { ClientMiddleware } from './auth/client.middleware';
import { OperationModule } from './operation/operation.module';
import { ServiceModule } from './service/service.module';
import { ValetModule } from './valet/valet.module';
import { ClientModule } from './client/client.module';
import { ValetService } from './valet/valet.service';
import { ResponsableMiddleware } from './auth/responsable.middleware';
import { NotificationsModule } from './notifications/notifications.module';
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [env],
    }),
    AuthModule,
    DeliveryModule,
    ProfileModule,
    HttpModule,
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, '..', 'assets/images'),
      renderPath: '/static',
      serveRoot: '/static/',
    }),
    StoreModule,
    DeliveryManModule,
    UsersModule,
    ScheduleModule.forRoot(),
    OperationModule,
    ServiceModule,
    ValetModule,
    ClientModule,
    NotificationsModule
  ],
  controllers: [AppController],
  providers: [AppService, SocketIoGateway, RetryJobService, DeliveryService, ValetService],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(BackOfficeMiddleware).forRoutes({
      path: 'app/*',
      method: RequestMethod.ALL,
    });
    consumer.apply(ClientMiddleware).forRoutes({
      path: 'client/*',
      method: RequestMethod.ALL,
    });
    consumer.apply(ValetMiddleware).forRoutes({
      path: 'valet/*',
      method: RequestMethod.ALL,
    });
    consumer.apply(ResponsableMiddleware).forRoutes({
      path: 'responsable/*',
      method: RequestMethod.ALL,
    });
  }
}
