import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { DeliveryService } from 'src/delivery/delivery.service';
import { ValetService } from 'src/valet/valet.service';

@Injectable()
export class RetryJobService {

    private readonly logger = new Logger("Valet Automatic Jobs Service ");

    constructor(private valetService: ValetService){

    }
   // @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
    @Cron(CronExpression.EVERY_DAY_AT_1PM)
    async handleCron() {
      const completeResult = await this.valetService.resetCharteApproval();
      console.log("Result", completeResult.message)
      this.logger.debug("Result", completeResult.message);
    }

/* 
    @Cron(CronExpression.EVERY_10_MINUTES)
    async handleTracking() {
      console.log("triggred")
      const completeResult = await this.deliveryService.getRoomJoinedDeliveryMen();
      
      this.logger.debug('TRYING TO TRACK DELIVERIES WITH IS JOINED ROOM TRUE at '+new Date());
    } */
}
