import { Test, TestingModule } from '@nestjs/testing';
import { RetryJobService } from './retry-job.service';

describe('RetryJobService', () => {
  let service: RetryJobService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [RetryJobService],
    }).compile();

    service = module.get<RetryJobService>(RetryJobService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
