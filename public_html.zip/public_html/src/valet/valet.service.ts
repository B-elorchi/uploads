import { DocumentReference, FieldValue } from '@google-cloud/firestore';
import { HttpResponse } from '@microsoft/signalr';
import { HttpException, Injectable } from '@nestjs/common';
import * as firebase from'firebase-admin';
import { Valet } from 'src/_models/valet.model';

@Injectable()
export class ValetService {

    async newValet(email, password, firstName, secondName,  phoneNumber, cinNumber?, permisNumber?) {
    
        console.log(firstName);
        console.log(secondName);
        console.log(email);
        console.log(password);
        console.log(phoneNumber);
    
        const db = firebase.firestore();
    
        const authUser =  await firebase.auth().createUser({
          email: email,
          emailVerified: false,
          phoneNumber: phoneNumber,
          password: password,
          displayName: firstName +' '+ secondName,
          photoURL: process.env.BACKEND_URL+'/static/profile_picture.png',
          disabled: false,
        })
        .then((userRecord) => {
          console.log('Successfully created new user:', userRecord.uid);
         
          return { userAuth: userRecord, success: true, message: 'Utilisateur crée avec succés', code:"success"};
        })
        .catch((error) => {
          console.log('Error creating new user:', error);
          if(error.code =="auth/email-already-exists") error.message = "Cette adresse Email est utilisée par un autre compte";
          return { userAuth: null, success: false, message: error.message, code:error.code};
        });
    
        if(authUser.success === true){
          await firebase.auth().setCustomUserClaims(authUser.userAuth.uid, {role: "valet"}).then(() => {
            console.log(" The new custom claims will propagate to the valets's ID token ", authUser.userAuth.uid)
          });
          console.log('It s success')
          const userData = {
            uid: authUser.userAuth.uid,
            first_name : firstName,
            second_name : secondName,
            email: email,
            phone_number: phoneNumber,
            disabled: false,
            email_verified: true,
            role: "valet",
            creation_time: new Date(),
            photo_url: process.env.BACKEND_URL+'/static/profile_picture.png'
          }
          
           const userRef: DocumentReference =  await db.collection("user").doc(userData.uid).set(userData)
              .then( (writeResult)=>{
                  return db.collection("user").doc(userData.uid);
              })
              .catch((error)=> {
                  return error;
              });
         
           if(userRef.id){
              const valetData: Valet = {
                first_name: firstName,
                second_name: secondName,
                userRef: userRef,
                reserved: false,
                cin_number: cinNumber ? cinNumber : null,
                num_permis: permisNumber ? permisNumber : null,
                status: 1,
                created_at: new Date(),
                phone_number: userData.phone_number,
                photo_url: process.env.BACKEND_URL+'/static/profile_picture.png',
                email: email,
    
              }
              const valetAddRef = await db.collection('valet').add(valetData)
              .then(valetAddRef =>{
                return valetAddRef;
              })
              .catch(error => {
                return error;
              });
             
              if(valetAddRef.id){
                console.log("Valet Created succesfully : ",valetAddRef.id);
                console.log(valetAddRef);
                console.log((await userRef.get()).data())
                return {... authUser, user: (await userRef.get()).data(), valet: {... (await valetAddRef.get()).data(), valet: {...valetData, id: valetAddRef.id}}}
              }else{
                return {... authUser, user:   (await userRef.get()).data(), delivery_man: null, id: null}
              }
           }else{
              return {...authUser, valetCreateError: userRef}
           }
        }else{
          return authUser;
        }
    }

    delete = async (id) => {
        try {
          const db = firebase.firestore();
          const valetDoc =  await db
            .collection('valet')
            .doc(id)
            .get()
            .then((qs) => {
              if (qs.exists) {
                const valetData = qs.data();
                return {
                  success: true,
                  valetData: valetData,
                };
              } else {
                throw new HttpException( { success: false, message: "Ce Valet n'existe pas" },400);
              }
            });
    
            if(valetDoc.success === true){
              await db.collection('valet').doc(id).delete();
              await db.collection("user").doc(valetDoc.valetData.userRef.id).delete();
            
              return await firebase.auth().deleteUser(valetDoc.valetData.userRef.id)
                    .then(()=>{
                        return {    
                          success: true,
                          deliveryMan: valetDoc.valetData,
                          message: 'Valet supprimé avec succés',}
                    })
            }
        } catch (error) {
          throw new HttpException( { success: false, message: error.message },400);
        }
    };


    resetCharteApproval = async () => {
      try {
          const db = firebase.firestore();

          const valets = this.getIsCharteNullOrNotApproved();

          (await valets).forEach((doc)=>{
              doc.ref.update({
                is_charte_approved: false
              })
          });

          return {
            success: true,
            messsage : "Charte réinitialisée pour tous les valets"
          };
          
      } catch (error) {
        return { error: error, success: false, message: error.message };
      }
    };

    getIsCharteNullOrNotApproved = async () =>{
      const db = firebase.firestore();
      let valetsRef = db.collection('valet');

      let isCharteNull = valetsRef.where("is_charte_approved",'==',null).get();
      let isCharteNotApproved = valetsRef.where("is_charte_approved",'!=', false).get();
   
      const [charteNullQuerySnapshot, charteNotApprovedQuerySnapshot] = await Promise.all([
        isCharteNull,
        isCharteNotApproved
      ]);
      const charteNullArray = charteNullQuerySnapshot.docs;
      const charteNotApprovedArray = charteNotApprovedQuerySnapshot.docs;

      const valetCharteArray = charteNullArray.concat(charteNotApprovedArray);

      console.log("liste des valets")
      console.log(valetCharteArray)
      return valetCharteArray;
    }

}
