import { Module } from '@nestjs/common';
import { ValetController } from './valet.controller';
import { ValetService } from './valet.service';
import { UsersService } from 'src/users/users.service';

@Module({
  controllers: [ValetController],
  providers: [ValetService, UsersService]
})
export class ValetModule {}
