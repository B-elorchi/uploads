import { Body, Controller, Delete, Get, HttpException, Param, Post, Put } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiParam } from '@nestjs/swagger';
import { ValetService } from './valet.service';
import { UsersService } from 'src/users/users.service';
import { AccountStatusDto } from 'src/_global-dtos/account-status.dto';
import { RegisterDto } from 'src/_global-dtos/register.dto';
import { UpdatePasswordDto } from 'src/_global-dtos/update-password.dto';
import { RegisterValetDto } from 'src/_global-dtos/register-valet.dto';

@Controller({
    path: ['app/valets'],
    version: '1', // 👈
})
@ApiTags('Valets')
@ApiBearerAuth('JWT')
export class ValetController {

    constructor(private valetService: ValetService, private usersService: UsersService){}

    
    @Post('/add')
    @ApiOperation({
        summary:
        'Register New User with Client Role and create Both Document Entities for User and Client associated By userRef using PhoneAuth & EmailAuth Firebase Providers',
    })
    async registerValet(@Body() regDto: RegisterValetDto) {
        if(regDto.password != regDto.c_password){
        throw new HttpException({success:false, message: "Les mots de passes ne correspondent pas"}, 400)
        }
        return await this.valetService.newValet(
        regDto.email,
        regDto.password,
        regDto.first_name,
        regDto.second_name,
        regDto.phone_number,
        regDto.cin_number,
        regDto.num_permis,
        );
    }

    
    @Put("/updatePassword")
    @ApiOperation({
        summary:
        'Update user password',
    })
    async updatePassword(@Body() updatePassDto: UpdatePasswordDto) {
        return await this.usersService.updatePassword(updatePassDto);
    }
    
    
    @Put("/setStatus")
    @ApiOperation({
        summary:
        'Set Client User Status',
    })
    async setStatus(@Body() accountStatusDto: AccountStatusDto) {
        return await this.usersService.setAccountStatus(accountStatusDto);
    }
    @Delete(':id')
    @ApiOperation({
        summary: 'Delete Valet Collection By Id and related User from Firestore Database and Firebase Authentication',
    })
    @ApiParam({
        name: 'id',
        description: 'The Valet Document ID and the User associated',
    })
    async delete(@Param('id') id: string) {
        return await this.valetService.delete(id);
    }

    @Get("/resetCharteApproval")
    @ApiOperation({
        summary:
        'Reset Charte de Bonne Conduite approval to all Valets',
    })
    async resetCharteApproval() {
        return await this.valetService.resetCharteApproval();
    }
    
}
