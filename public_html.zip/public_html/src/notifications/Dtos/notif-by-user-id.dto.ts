/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsNotEmpty, IsString } from 'class-validator';

export class NotifByUserIdDto {
  @ApiProperty()
  @IsNotEmpty({ message: "L'id utilisteur ne doit pas être vide",})
 
  @IsDefined({message: 'Vous devez renseigner un id utilisateur', })
  id: string;

  @ApiProperty()
  @IsNotEmpty({ message: "L'email ne doit pas être vide",})
 
  @IsDefined({message: 'Vous devez renseigner un Email', })
  title: string;

  @ApiProperty()
  @IsNotEmpty({ message: "L'email ne doit pas être vide",})
 
  @IsDefined({message: 'Vous devez renseigner un Email', })
  message: string;
 
}
