import { Body, Controller, Post } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { NotifByFCMTokenDto } from './Dtos/notif-by-fcm-token.dto';
import { NotifByUserIdDto } from './Dtos/notif-by-user-id.dto';
import { NotificationsService } from './notifications.service';


@Controller({
    path: ['notifications'],
    version: '1', // 👈
  })
@ApiTags('Notifications')
@ApiBearerAuth('JWT')
export class NotificationsController {

  constructor(private readonly nfService: NotificationsService) {}


    @Post('sendByFCMToken')
    @ApiOperation({
      summary:
        'Send notification to a defined FCM Token',
    })
    async sendByFCMToken(@Body() notifDto: NotifByFCMTokenDto) {
      return await this.nfService.sendNotif(
        notifDto.token,
        notifDto.title,
        notifDto.message,
      );
    }

    @Post('sendByUserId')
    @ApiOperation({
      summary:
        'Send notification to a defined User Id',
    })
    async sendByUserId(@Body() notifDto: NotifByUserIdDto) {
      return await this.nfService.sendPushToUser(
        notifDto
      );
    }

    @Post('getAllFcmTokens')
    @ApiOperation({
      summary:
        'Get all FCMs tokens',
    })
    async getAllFcmTokens() {
      return await this.nfService.getAllFcmTokens();
    }
}
