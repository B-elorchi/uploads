import { Injectable } from '@nestjs/common';
import * as firebase from 'firebase-admin';
import { NotifByUserIdDto } from './Dtos/notif-by-user-id.dto';

@Injectable()
export class NotificationsService {

    
    async sendNotif(fcm_token, title, body, userId = null, fcmId = null, language ="fr"){
        // This registration token comes from the client FCM SDKs.
        const registrationToken = fcm_token;
    
        const message = {
        notification:{
            title:title,
            body:body
          },
        token: registrationToken
        };
    
            // Send a message to the device corresponding to the provided
            // registration token.
           return await firebase.messaging().send(message)
            .then((response) => {
                // Response is a message ID string.
                console.log('Successfully sent message:', response);
                return {success: true, message: "Notif Successfully sent"}
            })
            .catch(async (error) => {
                console.log(error);
                console.log("code")
                console.log(error.code);
              
                let deletion = {message: "Pas de suppression"};
                if (error.code == "messaging/registration-token-not-registered"){
                    if(userId && fcmId){
                        deletion = await this.deleteToken(userId, fcmId);
                    }
                    console.log(deletion);
                    console.log(message.token);
                    console.log(userId ? userId : "le User ID n est pas fourni comme argument")
                }
              /* throw new HttpException( */ return {success:false, message: error.message, deletionResult: deletion}/* , 400) */
            });
    }

    async sendPushToUser(notifByUserDto: NotifByUserIdDto){
        // This registration token comes from the client FCM SDKs.
        const db= firebase.firestore();
   
       
        let id = notifByUserDto.id;
        let body = notifByUserDto.message;
        let title = notifByUserDto.title
     

        let results = [];
        const fcmTokens = await (await db.collection("user").doc(id)
                .collection("fcm_tokens").get())
            if(fcmTokens.size > 0){
                const devicesData = await Promise.all(fcmTokens.docs.map(e => {return { ...e.data(), id : e.id} as any}));

                for(let i = 0; i < devicesData.length; i++){
                    const sendNotifResult = await this.sendNotif(devicesData[i].fcm_token, title, body, id, devicesData[i].id);
                    console.log("sendNotifResult");
                    console.log(sendNotifResult);
                    results.push(sendNotifResult);
                    
                }
            }
        return results;
/* 


     
        const fcm = await (await db.collection("users").doc(id)
                .collection("fcm_tokens").get())
                .forEach(async (queryDocumentSnapshot)=>{
                    if(queryDocumentSnapshot.exists){
                    const devicesData = await queryDocumentSnapshot.data();
                    console.log("devicesData");
                    console.log(devicesData);
                        const sendNotifResult = await this.sendNotif(devicesData.fcm_token, title, body);
                        console.log("sendNotifResult");
                        console.log(sendNotifResult);
                        results.push(sendNotifResult);
                  
                        }
                });
        return results; */
      
      }


    
    getAllFcmTokens = async () => {
    const db= firebase.firestore();
       let usersQuery = (await db.collection("user").get());
       let usersData = null;
       if (!usersQuery.empty){
         usersData = 
             await Promise.all(
                usersQuery.docs.map(async (item)=>{
                     let fcms = await item.ref.collection("fcm_tokens").get();
                    if(!fcms.empty){
                        return  await Promise.all(fcms.docs.map((elt)=>{return {...elt.data(), fcmDocId: elt.id, userId: item.id, language: item.data().app_language}}))
                    }
                })
            )
       }
       return usersData.filter(function (el) {
        return el != null;
      });;
    }

    deleteToken = async (userId, fcmId) => {
        const db = firebase.firestore();

        return await db.collection("user").doc(userId)
                    .collection("fcm_tokens").doc(fcmId).delete().then(()=>{
                        return {success:true, message: "Fcm deleted"}
                    })
    }
}
