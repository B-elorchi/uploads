/* eslint-disable prettier/prettier */

export interface Payment {
    method: string;
    price: number;
}
  