/* eslint-disable prettier/prettier */

import { DocumentReference } from "@google-cloud/firestore";

export interface ActiveDelivery {
  id:string;
  delivery_man_ref: DocumentReference;
  delivery_ref: DocumentReference;
  creationTime?: Date;
  updateTime?: Date;
}
