/* eslint-disable prettier/prettier */

export interface User {
  uid: string;
  display_name?: string;
  email: string;
  phone_number: string;
  role:string,
  email_verified: boolean;
  disabled: boolean;
  password?: string;
  created_time?: Date;
}
