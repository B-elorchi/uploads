/* eslint-disable prettier/prettier */

import { DocumentReference } from "@google-cloud/firestore";

export interface Store {
  id:string;
  idMagasin: string;
  libeleMagasin: DocumentReference;
  latitude: number;
  longitude: number;
  creationTime: Date;
}
