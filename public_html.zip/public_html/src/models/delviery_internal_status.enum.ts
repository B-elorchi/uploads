/* eslint-disable prettier/prettier */
export enum DeliveryInternalStatus {
  INIT = 'EN_ATTENTE',
  AFFECTED = 'AFFECTED',
  IN_PROGRESS = 'IN_PROGRESS',
  DELIVERING = 'DELIVERING',
  DELIVERED = 'DELIVERED',
  CANCELED = 'CANCELED',
}
