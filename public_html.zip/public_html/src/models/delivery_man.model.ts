/* eslint-disable prettier/prettier */

import { DocumentReference } from "@google-cloud/firestore";

export interface DeliveryMan {
  id: string;
  first_name?: string;
  second_name?: string;
  userRef?: DocumentReference;
  email: string;
  phone_number: string;
  role:string,
  email_verified: boolean;
  disabled: boolean;
  password?: string;
  created_time?: Date;
}
