/* eslint-disable prettier/prettier */

import { DestinationAddressDto } from "src/delivery/Dtos/destinationAddress.dto";
import { PaymentDto } from "src/delivery/Dtos/payment.dto";
import { DeliveryStatus } from "./delivery_status.enum";

export interface Delivery {
  id: string;
  internalId: number;
  code: string;
  state: DeliveryStatus;
  scheduleTime: Date;
  description: string;
  payment?: PaymentDto;
  destinationAddress: DestinationAddressDto;
  pickupAddress: DestinationAddressDto;
  status: number;
  creationTime: Date;
  updateTime: Date;
}
