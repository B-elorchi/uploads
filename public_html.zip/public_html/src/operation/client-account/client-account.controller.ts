import { Controller, Param, Post, Put } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiParam } from '@nestjs/swagger';
import { OperationService } from '../operation.service';

@Controller({
    path: ['client/operations'],
    version: '1', // 👈
  })
  @ApiTags('ClientAccount-Operations')
  @ApiBearerAuth('JWT')
export class ClientAccountController {


    constructor(private operationService: OperationService){

    }

    
    @Put('calculateFinalPrice/:id')
    @ApiOperation({
        summary: 'This Route calculates the final Pricing according to the hourly prices defined in the hotspot and services option pricing rules',
    })
    @ApiParam({
        name: 'id',
        description: 'The Operation Document ID',
    })
    async calculateFinalPrice(@Param('id') id: string) {
        return await this.operationService.calculateFinalPrice(id);
    }

    @Post('cancel/:id')
    @ApiOperation({
        summary: 'Fully cancel an operation and update Valets rseserved status',
    })
    @ApiParam({
        name: 'id',
        description: 'The Operation Document ID',
    })
    async cancelOperation(@Param('id') id: string) {
        return await this.operationService.cancelOperation(id);
    }
  


}
