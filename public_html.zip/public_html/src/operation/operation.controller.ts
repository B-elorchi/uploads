import { Body, Controller, Param, Post, Put, Get } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { OperationService } from './operation.service';
import { AssignValetToOperationDto } from './Dtos/assignValetToOperation.dto';

@Controller({
    path: ['app/operations'],
    version: '1', // 👈
  })
  @ApiTags('Operations')
  @ApiBearerAuth('JWT')
export class OperationController {

  constructor(private readonly operationService: OperationService) {}

  @Post('/assignValet')
  @ApiOperation({
    summary:
      'Assign a Valet to a Operation and update the Operation status to Status_validated ',
  })
  async assignValetAndSetActive(
    @Body() assignValetDto: AssignValetToOperationDto,
  ) {
    return await this.operationService.assignValetToOperation(assignValetDto);
  }

  @Post('/assignReturnValet')
  @ApiOperation({
    summary:
      'Assign a Return Valet to an Operation and update the Operation status to VALET_RETURN_ASSIGNED ',
  })
  async assignReturnValet(
    @Body() assignValetDto: AssignValetToOperationDto,
  ) {
    return await this.operationService.assignReturnValet(assignValetDto);
  }

  @Get('services/:id')
  @ApiOperation({
      summary: 'Get All services ordered in an operation',
  })
  @ApiParam({
      name: 'id',
      description: 'The Operation Document ID',
  })
  async getServices(@Param('id') id: string) {
      return await this.operationService.getServices(id);
  }

  @Put('calculateFinalPrice/:id')
  @ApiOperation({
      summary: 'This Route calculates the final Pricing according to the hourly prices defined in the hotspot and services option pricing rules',
  })
  @ApiParam({
      name: 'id',
      description: 'The Operation Document ID',
  })
  async calculateFinalPrice(@Param('id') id: string) {
      return await this.operationService.calculateFinalPrice(id);
  }

  @Post('cancel/:id')
  @ApiOperation({
      summary: 'Fully cancel an operation and update Valets rseserved status',
  })
  @ApiParam({
      name: 'id',
      description: 'The Operation Document ID',
  })
  async cancelOperation(@Param('id') id: string) {
      return await this.operationService.cancelOperation(id);
  }

  

}
