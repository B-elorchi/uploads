import { HttpException, Injectable } from '@nestjs/common';
import { AssignValetToOperationDto } from './Dtos/assignValetToOperation.dto';
import * as firebase from 'firebase-admin';
import { Console } from 'console';
import { DocumentReference, FieldValue } from '@google-cloud/firestore';
import { AnyARecord } from 'dns';
import { OperationStatus } from 'src/_models/operation-status.enum';

@Injectable()
export class OperationService {

    db= firebase.firestore();

    async assignValetToOperation(assignValet : AssignValetToOperationDto) {
        try{
            const db = firebase.firestore();
        
            const valetRef = await db.collection('valet').doc(assignValet.valetId);
            const operationRef = await db.collection('operation').doc(assignValet.operationId);
            console.log("Valet ID from Assign ", valetRef.id)
            console.log("Operation ID from Assign ", operationRef.id)
            const operationData = (await operationRef.get()).data();
            const valetData = await valetRef.get()
            .then(valetDoc =>{
                console.log('test valet doc')
                if(valetDoc.exists){
                    console.log('exist')
                    console.log(valetDoc.data())
                    return {valet: valetDoc.data(), success:true};
                }else{
                    console.log('not exist');
                    return {valet: null , message: "Aucun Valet n\'est associé à l'ID "+assignValet.valetId, success:false};
                }
            })
            .catch(error => {
                return {...error, success:false};
            });
            console.log("driverData Response", valetData);
            console.log("driverData Object ", valetData.valet)
         

            if(valetData.success === true  && valetData.valet != null){
                console.log("All References received and reserved is False also that's amazing ", valetData.valet.reserved)
                /* await this.sendPushNotification(driverRef, deliveryData);*/

                if(valetData.valet.reserved === false){
                    const operationUpdate = await operationRef.update({
                        valet: valetRef,
                        valets: [valetRef],
                        valetData: valetData.valet,
                        status: OperationStatus.ASSIGNED,
                        assigned_at: new Date(),
                        updated_at: new Date()
                    }).then(()=>{
                        return {success: true}
                    }).catch((error)=>{
                        return {success:false, error: error.message};
                    });
                    const valetUpdate = await valetRef.update({
                        reserved: true
                    }).then(()=>{
                        return {success: true}
                    }).catch((error)=>{
                        return {success:false, error: error.message};
                    }); 
                    if(operationUpdate.success === true && valetUpdate.success === true){
                        const docRef = await db.collection("active_operation").select("valetRef")
                        .where("valetRef", "==",valetRef)
                        .get()
                        .then(function(querySnapshot) {
                          if (querySnapshot.size > 0){
                                 /*  querySnapshot.docs[0].ref.update({
                                  valetRef: valetRef,
                                  code_commande: deliveryData.code}); */

                                  return {success:true, found:true, activeOperationRef: querySnapshot.docs[0].ref, activeOperationData: querySnapshot.docs[0].data()}
                          }else{
                              return {success:true, found:false}
                          }
                              /* querySnapshot.forEach(function(doc) {
                                  doc.ref.delete();
                              }); */
                         }); 
                        
                         if(docRef.success === true){
                            let addActiveOperationRef; 
                            if(docRef.found === false){
                               return await db.collection('active_operation').where('operationRef','==', operationRef)
                                .get()
                                .then(operationRefSnapshot =>{
                                    console.debug("Heello from Active Operation")
                                    if(operationRefSnapshot.size > 0){
                                        operationRefSnapshot.docs[0].ref.update({
                                            valetRef: valetRef,
                                            valets: [valetRef],
                                            updated_at: new Date()
                                        })
                                        return { 
                                            operation: operationData, 
                                            valet: valetData,
                                            success: true, 
                                            activeOperation: operationRefSnapshot.docs[0].data(),
                                            message: "Opération affectée avec succés et passée à l'état Confirmée"}
                                    }else{
                                        return {success:false, message:"Aucune Opération active ne correspond à cette opération"}
                                    }
                                  })
                                  .catch(error => {
                                    return error;
                                  });
                               
                          
                            }else{
                                return {success:false, message:"Ce valet a déjà une opération en cours actuellement"}
                               
                            }
                         }
                    }else{
                        throw new HttpException(
                            {
                                success: false,
                                message: "Un problème est survenue lors de l'affectation",
                      
                              }, 
                              400);
                    }
                }else{
                    throw new HttpException(
                        {
                            success: false,
                            message: "Ce valet est indisponible pour le moment, il a déjà une opération en cours",
                  
                          }, 
                          400);
                }
              
            }else{
                throw new HttpException(
                    {
                        success: false,
                        message: "Aucun Valet n'est associé à cet identifiant.",
              
                      }, 
                      400);
            } 

        }catch(error){
            throw new HttpException(
                {
                    success: false,
                    error: error,
                    message: error.message
            
                }, 
            400);
        }
        
    }

    async assignReturnValet(assignValet : AssignValetToOperationDto) {
        try{
            const db = firebase.firestore();
        
            const valetRef = await db.collection('valet').doc(assignValet.valetId);
            const operationRef = await db.collection('operation').doc(assignValet.operationId);
            console.log("Valet ID from Assign ", valetRef.id)
            console.log("Operation ID from Assign ", operationRef.id)
            const operationData = (await operationRef.get()).data();
            const valetData = await valetRef.get()
            .then(valetDoc =>{
                console.log('test valet doc')
                if(valetDoc.exists){
                    console.log('exist')
                    console.log(valetDoc.data())
                    return {valet: valetDoc.data(), success:true};
                }else{
                    console.log('not exist');
                    return {valet: null , message: "Aucun Valet n\'est associé à l'ID "+assignValet.valetId, success:false};
                }
            })
            .catch(error => {
                return {...error, success:false};
            });
            console.log("driverData Response", valetData);
            console.log("driverData Object ", valetData.valet)
         

            if(valetData.success === true  && valetData.valet != null){
                console.log("All References received and reserved is False also that's amazing ", valetData.valet.reserved)
                /* await this.sendPushNotification(driverRef, deliveryData);*/

                if(valetData.valet.reserved === false){
                    const operationUpdate = await operationRef.update({
                        returnValet: valetRef,
                        returnValetData:  valetData.valet,
                        valets: [operationData.valet, valetRef],
                        status: OperationStatus.RETURN_VALET_ASSIGNED,
                        return_valet_assigned_at: new Date(),
                        updated_at: new Date()
                    }).then(()=>{
                        return {success: true}
                    }).catch((error)=>{
                        return {success:false, error: error.message};
                    });
                    const valetUpdate = await valetRef.update({
                        reserved: true
                    }).then(()=>{
                        return {success: true}
                    }).catch((error)=>{
                        return {success:false, error: error.message};
                    }); 
                    if(operationUpdate.success === true && valetUpdate.success === true){
                        const docRef = await db.collection("active_operation").select("valetRef")
                        .where("valetRef", "==",valetRef)
                        .get()
                        .then(function(querySnapshot) {
                          if (querySnapshot.size > 0){
                                 /*  querySnapshot.docs[0].ref.update({
                                  valetRef: valetRef,
                                  code_commande: deliveryData.code}); */

                                  return {success:true, found:true, activeOperationRef: querySnapshot.docs[0].ref, activeOperationData: querySnapshot.docs[0].data()}
                          }else{
                              return {success:true, found:false}
                          }
                              /* querySnapshot.forEach(function(doc) {
                                  doc.ref.delete();
                              }); */
                         }); 
                        
                         if(docRef.success === true){
                            let addActiveOperationRef; 
                            return await db.collection('active_operation').where('operationRef','==', operationRef)
                                .get()
                                .then(operationRefSnapshot =>{
                                    console.debug("Heello from Active Operation")
                                    if(operationRefSnapshot.size > 0){

                                        let valets = [operationData.valet]
                                        let data = {};

                                        if(operationData.valet.id != valetRef.id){
                                            valets.push(valetRef);
                                            operationRefSnapshot.docs[0].ref.update({
                                                /*     valetRef: valetRef, */
                                                    valets: valets,
                                                    updated_at: new Date(),
                                                    isReturn: true,
                                                    isSameValet: false
                                                })
                                        }else{
                                            operationRefSnapshot.docs[0].ref.update({
                                                /*     valetRef: valetRef, */
                                                    updated_at: new Date(),
                                                    isReturn: true,
                                                    isSameValet: true,
                                                    valets:[valetRef]
                                                })
                                        }
                                       
                                        return { 
                                            operation: operationData, 
                                            valet: valetData,
                                            success: true, 
                                            activeOperation: operationRefSnapshot.docs[0].data(),
                                            message: "Opération affectée avec succés et passée à l'état Confirmée"}
                                    }else{
                                        return {success:false, message:"Aucune Opération active ne correspond à cette opération"}
                                    }
                                  })
                                  .catch(error => {
                                    return error;
                                  });
                               
                            /* if(docRef.found === false){
                               
                          
                            }else{
                                return {success:false, message:"Ce valet a déjà une opération en cours actuellement"}
                               
                            } */
                         }
                    }else{
                        throw new HttpException(
                            {
                                success: false,
                                message: "Un problème est survenue lors de l'affectation",
                      
                              }, 
                              400);
                    }
                }else{
                    throw new HttpException(
                        {
                            success: false,
                            message: "Ce valet est indisponible pour le moment, il a déjà une opération en cours",
                  
                          }, 
                          400);
                }
              
            }else{
                throw new HttpException(
                    {
                        success: false,
                        message: "Aucun Valet n'est associé à cet identifiant.",
              
                      }, 
                      400);
            } 

        }catch(error){
            throw new HttpException(
                {
                    success: false,
                    error: error,
                    message: error.message
            
                }, 
            400);
        }
        
    }

    
    getServices =  async (id)=> {

        try{
            console.log("GetServices Execution Start")
            

            const operationRef = await this.db.collection("operation").doc(id);
            const operationDoc = await operationRef.get();

           
            if(operationDoc.exists){
                const servicesSnap = await this.db
                .collection("operation_service_option")
                .where('operation','==',operationRef).get();

                if (!servicesSnap.empty){
                    let services = [];
                    servicesSnap.forEach((item)=>{
                        services.push({...item.data(), id: item.id})
                    })
                    return {
                        success:true, 
                        message: "Liste des services envoyée avec succés", 
                        data: services
                    }
                }else{
                    return {
                        success:true, 
                        message: "Liste des services envoyée avec succés", 
                        data: []
                    }
                }
               
            }else{
                throw new HttpException(
                    {
                        success: false,
                        error: "L'ID ne correspond a aucune opération",
                        message: "L'ID ne correspond a aucune opération",
                
                    }, 
                400);
            }
           
        }catch(error){
            throw new HttpException(
                {
                    success: false,
                    error: error,
                    message: error.message
            
                }, 
            400);
        }
       
    }

    calculateFinalPrice =  async (id)=> {

        try{
            console.log("Hello from calculateprice")
            

            const operationRef = await this.db.collection("operation").doc(id);
            const operationDoc = await operationRef.get();

            if(operationDoc.exists){
                const operationData = operationDoc.data();

                const operationServiceOptionData = await this.getServiceOptions(operationRef);

                let parkingService = null;
                let activeDuration = 0;
                let parkingPrice = 0;
                let otherServicesPrice = 0;
                let pricingData = {} as any;
                let pricingDataOther = {} as any;
                let awaiting_return_at = new Date();
                if(operationData.active_at && awaiting_return_at){
                    activeDuration = this.hourlyDifference( operationData.active_at?.toMillis(),  awaiting_return_at.getTime());
                    parkingService = this.getParkingService(operationServiceOptionData);
                    console.log(parkingService);
                    console.log("Creation timestamp ", operationData.created_at?.toMillis())
                    console.log("Active timestamp ", operationData.active_at?.toMillis())
                    console.log(this.hourlyDifference( operationData.created_at?.toMillis(),  operationData.active_at?.toMillis()))
              
                    let hotspotData = await this.getHotspotDoc(operationData.hotspotRef);
                    console.log("hotspotData")
                    if(parkingService){
                        pricingData =this.calculateParkingPrice(parkingService, hotspotData,activeDuration);
                        parkingPrice = pricingData.finalPrice; 
                    
                    }else{
                        pricingData =null;
                        parkingPrice = 0; 

                    }
                    console.log("AfterParkingPrice")

                    pricingDataOther =this.calculateOtherServicePrice(operationServiceOptionData, hotspotData,activeDuration);
                    otherServicesPrice = pricingDataOther.finalPrice; 


                    let finalPricingData = {
                        parkingPrice:  parkingPrice ? parkingPrice : 0,
                        otherServicesPrice: otherServicesPrice ? otherServicesPrice : 0,
                        operationActiveDuration: activeDuration
                    };
                    await operationRef.update({
                        final_price: parkingPrice + otherServicesPrice,
                        pricingData: finalPricingData,
                        status: OperationStatus.AWAITING_RETURN,
                        awaiting_return_at: new Date(),
                        payment_status: "UNPAID"
                    })

                    return{
                        success:true,
                        finalPrice: parkingPrice + otherServicesPrice,
                        parkingPrice: parkingPrice ? parkingPrice.toFixed(2) : 0,
                        otherServicesPrice: otherServicesPrice ? otherServicesPrice.toFixed(2) : 0,
                        operation: operationData.id,
                        
                        service_option: operationServiceOptionData.length,
                        parkingService: parkingService?.id,
                        operationActiveHourlyDuration: activeDuration,
                        
                        pricingData: finalPricingData,
                        pricingDataOther:pricingDataOther
        
                    }
                }else{
                    throw new HttpException(
                        {
                            success: false,
                            error: "Cette opération ne comporte pas la données active_at nécessaire pour calculer la durée",
                            message: "Cette opération ne comporte pas la données active_at nécessaire pour calculer la durée",
                    
                        }, 
                    400);
                }
               
            }else{
                throw new HttpException(
                    {
                        success: false,
                        error: "Operation ID ne correspond a aucune opération",
                        message: "Operation ID ne correspond a aucune opération",
                
                    }, 
                400);
            }
           
        }catch(error){
            throw new HttpException(
                {
                    success: false,
                    error: error,
                    message: error.message
            
                }, 
            400);
        }
       
    }

    hourlyDifference(start,end){
        return (end - start)/3600000;
    }

    async getServiceOptions(operationRef){
        const operationServiceOption = await (await this.db.collection("operation_service_option").where("operation","==",operationRef).get()).docs;

        const operationServiceOptionData = await Promise.all(operationServiceOption.map((elt)=>{
                return elt.data();
        }));

        return operationServiceOptionData;
    }

    getParkingService(operationServiceOptionData: any[]): any | null{
        let parkingServices = operationServiceOptionData.filter((elt)=>{
            return elt.isPriceIncludeParking === true;
        })
        if(parkingServices.length > 0){
            return parkingServices[0];
        }else{
            return null;
        }
    }

    async getHotspotDoc(hotspotRef: DocumentReference){
        const hotspotDoc = await this.db.collection("hotspots").doc(hotspotRef.id).get();
        let hotspotData = null;
        if(hotspotDoc.exists){
         hotspotData = await hotspotDoc.data();
        }
        return hotspotData;
    }

    calculateParkingPrice(serviceOption:any, hotspot, hourlyDuration){
        let price = 0;
        let coutHoraireStationnement = 0;
        let coutHoraireValet = 0;
        let averageImmobilisationTime = 18;
        console.log("serviceOption")
        console.log(serviceOption)
        if(hotspot.coutHoraireStationnement){
            coutHoraireStationnement = hotspot.coutHoraireStationnement;
        }
        if(hotspot.coutHoraireValet){
            coutHoraireValet = hotspot.coutHoraireValet;
        }
        if(serviceOption.averageImmobilisationTime){
            averageImmobilisationTime = serviceOption.averageImmobilisationTime;
        }
        price =coutHoraireStationnement * hourlyDuration + averageImmobilisationTime / 60 * coutHoraireValet + serviceOption.fixedPrice;

        return {
            finalPrice: price,
            coutHoraireStationnement: coutHoraireStationnement,
            coutHoraireValet: coutHoraireValet,
            operationHourlyDuration: hourlyDuration,
            averageImmobilisationTime: averageImmobilisationTime / 60,

           };
    }

    
    calculateOtherServicePrice(serviceOption:any[], hotspot, hourlyDuration){
        let price = 0;
        let coutHoraireStationnement = 0;
        let coutHoraireValet = 0;
        let averageImmobilisationTime = 18;
        if(hotspot.coutHoraireStationnement){
            coutHoraireStationnement = hotspot.coutHoraireStationnement;
        }
        if(hotspot.coutHoraireValet){
            coutHoraireValet = hotspot.coutHoraireValet;
        }
        if(serviceOption.length > 0){

           for(let item of serviceOption){
            let itemPrice = 0;
            let immotime = 18;
            let immo = 0;
            if (item.averageImmobilisationTime == null) {
              immo = immotime;
            } else {
              immo = item.averageImmobilisationTime;
            }
            if (item.isPriceIncludeParking == false ||
                item.isPriceIncludeParking == null) {
              itemPrice = item.fixedPrice + (immo / 60 * hotspot.coutHoraireValet);
            }
        
            price = price + itemPrice;
           }
        }
        return {
            finalPrice: price,
            coutHoraireStationnement: coutHoraireStationnement,
            coutHoraireValet: hotspot.coutHoraireValet,

           };
    }


    cancelOperation =  async (id)=> {

        try{
            console.log("Hello from cancelOperation")
            

            const operationRef = await this.db.collection("operation").doc(id);
            const operationDoc = await operationRef.get();

            const activeOperation = await this.db.collection("active_operation").where("operationRef","==",operationRef).get();
                
            if(!activeOperation.empty){
               
               await activeOperation.docs[0].ref.delete();
               await operationRef.update({
                status: OperationStatus.CANCELLED,
                updated_at: new Date()   
               });

               if(operationDoc.data().valet){
                await this.db.collection("valet").doc(operationDoc.data().valet.id).update({
                    reserved: false
                });
               }
               if(operationDoc.data().returnValet){
                await this.db.collection("valet").doc(operationDoc.data().returnValet.id).update({
                    reserved: false
                });
               }
                
               return {
                success: true,
                operation: operationDoc.data(),
                message: "Opération annulée avec succés et valets libérés"
               }
                
               
            }else{
                throw new HttpException(
                    {
                        success: false,
                        error: "Aucune opération active ne correspond à l'ID envoyé ",
                        message: "Aucune opération active ne correspond à l'ID envoyé ",
                
                    }, 
                400);
            }
           
        }catch(error){
            throw new HttpException(
                {
                    success: false,
                    error: error,
                    message: error.message
            
                }, 
            400);
        }
       
    }
}
