/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsNotEmpty, IsString} from 'class-validator';

export class AssignValetToOperationDto {

 @ApiProperty()

/*  @IsNotEmpty({ message: "Le Co est requis",})*/
 @IsString({ message: "L'ID du valet ne doit pas être vide",})
 @IsDefined({message: 'Vous devez renseigner un ID de valet', }) 
 @IsNotEmpty({ message: "L'Id du Valet est requis",})
 valetId: string;

 @ApiProperty()
 @IsString({ message: "L'ID de l'opération ne doit pas être vide",})
 @IsDefined({message: 'Vous devez renseigner un ID de l\'opération', }) 
 @IsNotEmpty({ message: "L'Id de l'opération est requis",})
  operationId: string;
}
