import { Module } from '@nestjs/common';
import { OperationController } from './operation.controller';
import { OperationService } from './operation.service';
import { ClientAccountController } from './client-account/client-account.controller';

@Module({
    controllers: [OperationController,  ClientAccountController],
    providers: [OperationService],
  })
export class OperationModule {}
