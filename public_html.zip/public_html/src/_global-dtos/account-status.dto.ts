/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsDefined, IsNotEmpty, IsString} from 'class-validator';

export class AccountStatusDto  {

  @ApiProperty()

  @IsNotEmpty({ message: "L'id est requis",})
  @IsString({ message: "L'id est requis",})
  @IsDefined({message: 'L\'id est requis', }) 
  @IsNotEmpty({ message:"L'id est requis",})
  uid: string;

  @ApiProperty()

  @IsNotEmpty({ message: "Le statut est requis",})
  @IsBoolean({ message: "Le statut est requis",})
  @IsDefined({message: 'Le statut est requis', }) 
  @IsNotEmpty({ message:"Le statut est requis",})
  disabled: boolean;

}
