/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsEmail, IsNotEmpty, IsOctal, IsOptional, IsString } from 'class-validator';

export class SetUserClaimDto {

  @ApiProperty()
  @IsNotEmpty({ message: "Le  ID est requis",})
  @IsString({ message: "Le  ID ne doit pas être vide",})
  @IsDefined({message: 'Vous devez renseigner un  ID', })
  id: string;


  @ApiProperty()

  @IsNotEmpty({ message: "Le Claim est requis",})
  @IsString({ message: "Le Claim ne doit pas être vide",})
  @IsDefined({message: 'Vous devez renseigner un Claim', })
  claim: string;

  /* @IsOptional()
  @ApiProperty()
  @IsString({ message: "Le Numéro de Cin est requis",})
  @IsNotEmpty({ message: "Le Numéro de Cin est requis",})
  @IsDefined({message: 'Vous devez renseigner un Numéro de Permis', })
  cin_number: string;

  @IsOptional()
  @ApiProperty()
  @IsString({ message: "Le Numéro de Permis est requis",})
  @IsNotEmpty({ message: "Le Numéro de Permis est requis",})
  @IsDefined({message: 'Vous devez renseigner un Numéro de Permis', })
  num_permis: string; */

}
