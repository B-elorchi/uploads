import { Module } from '@nestjs/common';
import { ClientController } from './client.controller';
import { ClientService } from './client.service';
import { UsersService } from 'src/users/users.service';

@Module({
  controllers: [ClientController],
  providers: [ClientService, UsersService]
})
export class ClientModule {}
