import { DocumentReference } from '@google-cloud/firestore';
import { HttpException, Injectable } from '@nestjs/common';
import * as firebase from 'firebase-admin';
import { Client } from 'src/_models/client.model';
@Injectable()
export class ClientService {


    async newClient(email, password, firstName, secondName,  phoneNumber, address?, city?) {
 
        const db = firebase.firestore();
    
        const authUser =  await firebase.auth().createUser({
          email: email,
          emailVerified: false,
          phoneNumber: phoneNumber,
          password: password,
          displayName: firstName +' '+ secondName,
          photoURL: process.env.BACKEND_URL+'/static/profile_picture.png',
          disabled: false,
        })
        .then((userRecord) => {
          console.log('Successfully created new user:', userRecord.uid);
         
          return { userAuth: userRecord, success: true, message: 'Utilisateur crée avec succés', code:"success"};
        })
        .catch((error) => {
          console.log('Error creating new user:', error);
          if(error.code =="auth/email-already-exists") error.message = "Cette adresse Email est utilisée par un autre compte";
          return { userAuth: null, success: false, message: error.message, code:error.code};
        });
    
        if(authUser.success === true){
          await firebase.auth().setCustomUserClaims(authUser.userAuth.uid, {role: "client"}).then(() => {
            console.log(" The new custom claims will propagate to the valets's ID token ", authUser.userAuth.uid)
          });
          console.log('It s success')
          const userData = {
            uid: authUser.userAuth.uid,
            first_name : firstName,
            second_name : secondName,
            email: email,
            phone_number: phoneNumber,
            disabled: false,
            email_verified: true,
            role: "client",
            creation_time: new Date(),
            photo_url: process.env.BACKEND_URL+'/static/profile_picture.png'
          }
          
           const userRef: DocumentReference =  await db.collection("user").doc(userData.uid).set(userData)
              .then( (writeResult)=>{
                  return db.collection("user").doc(userData.uid);
              })
              .catch((error)=> {
                  return error;
              });
         
           if(userRef.id){
              const clientData: Client = {
                first_name: firstName,
                second_name: secondName,
                userRef: userRef,
                status: 1,
                created_at: new Date(),
                city: city ? city : null,
                address: address ? address: null,
                phone_number: userData.phone_number,
                photo_url: process.env.BACKEND_URL+'/static/profile_picture.png',
                email: email,
    
              }
              const clientAddRef = await db.collection('client').add(clientData)
              .then(clientAddRef =>{
                return clientAddRef;
              })
              .catch(error => {
                return error;
              });
             
              if(clientAddRef.id){
                console.log("Client Created succesfully : ",clientAddRef.id);
                console.log(clientAddRef);
                console.log((await userRef.get()).data())
                return {... authUser, user: (await userRef.get()).data(), valet: {... (await clientAddRef.get()).data(), valet: {...clientData, id: clientAddRef.id}}}
              }else{
                return {... authUser, user:   (await userRef.get()).data(), valet: null, id: null}
              }
           }else{
              return {...authUser, clientCreateError: userRef}
           }
        }else{
          return authUser;
        }
    }

    delete = async (id) => {
        try {
          const db = firebase.firestore();
          const clientDoc =  await db
            .collection('client')
            .doc(id)
            .get()
            .then((qs) => {
              if (qs.exists) {
                const clientData = qs.data();
                return {
                  success: true,
                  clientData: clientData,
                };
              } else {
                throw new HttpException( { success: false, message: "Ce Client n'existe pas" },400);
              }
            });
    
            if(clientDoc.success === true){
              await db.collection('client').doc(id).delete();
              await db.collection("user").doc(clientDoc.clientData.userRef.id).delete();
            
              return await firebase.auth().deleteUser(clientDoc.clientData.userRef.id)
                    .then(()=>{
                        return {    
                          success: true,
                          deliveryMan: clientDoc.clientData,
                          message: 'Client supprimé avec succés',}
                    })
            }
        } catch (error) {
          throw new HttpException( { success: false, message: error.message },400);
        }
    };
}
