import { Body, Controller, Delete, HttpException, Param, Post, Put } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiParam } from '@nestjs/swagger';
import { ClientService } from './client.service';
import { RegisterDto } from '../_global-dtos/register.dto';
import { UpdatePasswordDto } from 'src/_global-dtos/update-password.dto';
import { UsersService } from 'src/users/users.service';
import { AccountStatusDto } from 'src/_global-dtos/account-status.dto';
import { RegisterClientDto } from 'src/_global-dtos/register-client.dto';

@Controller({
    path: ['app/clients'],
    version: '1', // 👈
})
@ApiTags('Clients')
@ApiBearerAuth('JWT')
export class ClientController {

    constructor(private clientService : ClientService, private usersService: UsersService){

    }

    @Post('/add')
    @ApiOperation({
        summary:
        'Register New User with Client Role and create Both Document Entities for User and Client associated By userRef using PhoneAuth & EmailAuth Firebase Providers',
    })
    async registerClient(@Body() regDto: RegisterClientDto) {
        if(regDto.password != regDto.c_password){
        throw new HttpException({success:false, message: "Les mots de passes ne correspondent pas"}, 400)
        }
        return await this.clientService.newClient(
        regDto.email,
        regDto.password,
        regDto.first_name,
        regDto.second_name,
        regDto.phone_number,
        regDto.address,
        regDto.city
        );
    }


    @Put("/updatePassword")
    @ApiOperation({
        summary:
        'Update user password',
    })
    async updatePassword(@Body() updatePassDto: UpdatePasswordDto) {
        return await this.usersService.updatePassword(updatePassDto);
    }
    
    
    @Put("/setStatus")
    @ApiOperation({
        summary:
        'Set Client User Status',
    })
    async setStatus(@Body() accountStatusDto: AccountStatusDto) {
        return await this.usersService.setAccountStatus(accountStatusDto);
    }

    @Delete(':id')
    @ApiOperation({
        summary: 'Delete Valet Collection By Id and related User from Firestore Database and Firebase Authentication',
    })
    @ApiParam({
        name: 'id',
        description: 'The Valet Document ID and the User associated',
    })
    async delete(@Param('id') id: string) {
        return await this.clientService.delete(id);
    }
}
