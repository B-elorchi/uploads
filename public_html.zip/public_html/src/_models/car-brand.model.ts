import { Timestamp } from "@firebase/firestore-types";
import { CarBrandStatus } from "./car-model-status.enum";

export interface CarBrand
{
    id:string;
    brand:string;
    brand_logo:string;
    brand_picto:string;
    status: CarBrandStatus;
    created_at: Date | Timestamp;
    updated_at?: Date | Timestamp; 
}