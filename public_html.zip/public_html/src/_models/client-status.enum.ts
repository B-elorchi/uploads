export enum ClientStatus {
    DISABLED = 0,
    ENABLED = 1,
}