export enum FavoriteLocationStatus {
    ACTIVE = "ACTIVE",
    INACTIVE = "INACTIVE",
  }