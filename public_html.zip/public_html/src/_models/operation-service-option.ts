import { DocumentReference, Timestamp } from "@firebase/firestore-types";
import { Operation } from "./operation.model";
import { ServiceOption } from "./service-option.model";
import { OperationServiceOptionStatus } from "./operation-service-option-status";

export interface OperationServiceOption {
    final_price : number;
    operation : DocumentReference<Operation>;
    service_option_data: ServiceOption;
    service_option: DocumentReference<ServiceOption>;
    status: OperationServiceOptionStatus;
    started_at?: Date | Timestamp;
    completed_at?: Date | Timestamp;
}
