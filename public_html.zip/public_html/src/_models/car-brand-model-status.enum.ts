
export enum CarBrandModelStatus {
    ACTIVE = "ACTIVE",
    INACTIVE = "INACTIVE",
}
