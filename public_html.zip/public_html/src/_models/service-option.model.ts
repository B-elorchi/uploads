import { DocumentData, DocumentReference, Timestamp } from "@firebase/firestore-types";
import { Service } from "./service.model";
import { PricingRules } from "./pricing-rules.enum";

export interface ServiceOption {
    id?: string;
    name: string;
    description?: string;
    /* priceConstant?: number;
    priceHourlyValet?: number;
    priceHourlyParking?: number;
    customPriceConstant?: boolean;
    customPriceHourlyValet?: boolean;
    customPriceHourlyParking?: boolean; */
    service: DocumentReference<DocumentData | Service>;
    serviceData: Service;
   /*  pricingRule: PricingRules; */
    isPriceIncludeParking: boolean;
    averageImmobilisationTime: number;
    fixedPrice: number;
    created_at?: Date | Timestamp;
    updated_at?: Date | Timestamp;
}
