
import { Timestamp } from "@firebase/firestore-types";
import { Store } from "./store";
import { DeliveryMan } from "./delivery-man";
import { DocumentReference } from "@google-cloud/firestore";

export interface Payment {
    id?:string;
    creationTime: Timestamp | Date;
    updated_at: Timestamp | Date;
    deliveryManRef: DocumentReference<DeliveryMan>;
    detail: string;
    price: number;
    type:string;
    status: string;
    deliveryMan?:string | DeliveryMan;
}