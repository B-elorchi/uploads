import { DocumentReference, Timestamp } from "@firebase/firestore-types";
import { Car } from "./car.model";

export interface User {
    id?: string;
    first_name: string;
    second_name: string;
    email: string;
    email_verified: boolean;
    phone_number: string;
    disabled: boolean;
    role:string;
    photo_url?: string;
    creation_time: Timestamp;
    updated_at?: Timestamp
    defaultCarRef?: DocumentReference<Car>
}
