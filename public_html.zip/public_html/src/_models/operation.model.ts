import { DocumentData, DocumentReference, Timestamp } from "@firebase/firestore-types";
import { LatLng, Valet } from "./valet.model";
import { Client } from "./client.model";
import { OperationStatus } from "./operation-status.enum";
import { Car } from "./car.model";
import { Hotspot } from "./hotspot.model";

export interface Operation {
    id?: string;
    startLocation?: LatLng;
    endLocation?: LatLng;
    valets?: DocumentReference<Valet>[];
    valet?: DocumentReference<Valet>;
    valetData?: string | Valet;
    returnValet? : DocumentReference<Valet>;
    returnValetData? : string | Valet;
    client?: DocumentReference<Client>;
    clientData?: string | Client;
    hotspotRef: DocumentReference<Hotspot>;
    hostspotData: Hotspot;
    returnKeys?: boolean;
    returnCar?: boolean;
    startTime?: Date | Timestamp;
    endTime?: Date | Timestamp;
    status?: OperationStatus;
    owner_images?: string[];
    estimated_price?: number;
    final_price?: number;
    assigned_at?: Date | Timestamp;
    confirmed_client_at? : Date | Timestamp;
    confirmed_at?: Date | Timestamp;
    accepted_at?: Date | Timestamp;
    active_at?: Date | Timestamp;
    in_progress_at?: Date | Timestamp;
    completed_at?: Date | Timestamp;
    key_deposited_at_hotspot_at?: Date | Timestamp;
    awaiting_return_at?: Date | Timestamp;
    return_valet_assigned_at?: Date | Timestamp;
    return_accepted_at?: Date | Timestamp;
    unpaid_at?: Date | Timestamp;
    paid_at?: Date | Timestamp;
    successfully_scanned_at?: Date | Timestamp;
    cancelled_at?: Date | Timestamp;
    car?: DocumentReference<Car>;
    created_at?: Date | Timestamp;
    updated_at?: Date | Timestamp;
    startLocationName?: string;
    endLocationName?: string;

}


