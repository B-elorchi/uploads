export enum CarStatus {
    ACTIVE = "ACTIVE",
    INACTIVE = "INACTIVE",
}