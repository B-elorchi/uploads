import { DocumentReference } from "@firebase/firestore-types";
import { Operation } from "./operation.model";

export interface OperationValetMedia
{
    id:string;
    media_type:MediaType;
    image_path?:string;
    video_path?:string;
    type?: ValetMediaType;
    operationRef?:DocumentReference<Operation>;

}

export enum MediaType 
{
    Image = 'image',
    Video = 'video'
}

export enum ValetMediaType 
{
    After = 'after',
    Before = 'before'
}