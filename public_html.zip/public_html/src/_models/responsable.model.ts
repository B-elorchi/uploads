import { Timestamp } from "@firebase/firestore-types";
import { ValetStatus } from "./valet-status.enum";
import { DocumentData, DocumentReference } from "@google-cloud/firestore";
import { User } from "./user.model";
import { LatLng } from "./valet.model";
import { ClientStatus } from "./client-status.enum";

export interface Client {
    id?: string;
    first_name: string;
    second_name: string;
    email: string;
    phone_number: string;
    photo_url?: string;
    created_at: Date | Timestamp;
    updated_at?: Date | Timestamp;
    city?: string;
    address?: string;

    last_position?: LatLng;
    last_position_time?: Date | Timestamp;
    userRef:DocumentReference<DocumentData>

    status: ClientStatus;
}
