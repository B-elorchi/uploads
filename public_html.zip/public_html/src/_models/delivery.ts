
import { Timestamp } from "@firebase/firestore-types";
import { DeliveryMan } from "./delivery-man";
import { DocumentReference } from "@google-cloud/firestore";

export interface Delivery {
    id?:string;
    deliveryMan?: string | DeliveryMan;
    external_id: number;
    code: string;
    creationTime: Timestamp;
    confirmedAt: Timestamp;
    finishedAt: Timestamp;
    scheduleTime: Date;
    scheduleTimeBrut: number;
    internalStatus: string;
    deliveryManRef: DocumentReference;
    destinationAddress: DestinationAddress;
    pickupAddress: PickupAddress;
    payment: Payment;
    state:State;
    updateTime: Timestamp;
    marjaneCompleteResponseSuccess: boolean;
    marjaneLastCompleteTime: Timestamp;
    city?: string;


}

export interface DestinationAddress {
    address: string;
    contactPerson: string;
    contactPhone: string;
    latitude: number;
    longitude: number;
}
export interface PickupAddress {
    idMagasin: string;
    libeleMagasin: string;
    latitude: number;
    longitude: number;
}
export interface Payment {
    method: string;
    price: number;
}

export enum State {
   
    CANCELLED = "STATUS_CANCELLED",
    CREATED = "STATUS_CREATED",
    DELIVERED = "STATUS_DELIVERED",
    DELIVERING = "STATUS_DELIVERING",
    IN_PROGRESS = "STATUS_IN_PROGRESS",
    PREPARING = "STATUS_PREPARING",
    READY = "STATUS_READY",
    REFUSED = "STATUS_REFUSED",
    VALIDATED = "STATUS_VALIDATED",
    ERROR_PAYMENT = "STATUS_ERROR_PAYMENT"
}