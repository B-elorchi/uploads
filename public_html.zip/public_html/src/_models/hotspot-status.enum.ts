export enum HotspotStatus {
    ACTIVE = "ACTIVE",
    INACTIVE = "INACTIVE",
  }