
import { Timestamp } from "@firebase/firestore-types";
import { Store } from "./store";
import { DocumentReference } from "@google-cloud/firestore";

export interface DeliveryMan {
    id?:string;
    store?: string | Store;
    picture?: string;
    disabled?: boolean;
    nbr_deliveries?: number;
    first_name: string;
    second_name: string;
    city: string;
    phoneNumber: string;
    cin_number: string;
    creation_time: Date;
    last_position: LatLng;
    last_position_time: Timestamp;
    availability: boolean;
    storeRef: DocumentReference;
    userRef: DocumentReference;
    updated_at: Timestamp;

}

export interface LatLng {
    latitude: number;
    longitude: number;
}