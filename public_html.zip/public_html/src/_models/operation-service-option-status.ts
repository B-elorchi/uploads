export enum OperationServiceOptionStatus {
    PENDING = 'PENDING',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
}

// When all OperationServiceOptions are still in the pending state ==> the Operation should take the Active State
// If at least one OperationServiceOption is in the InProgress Status ===> The Operation should pass to the In Progress Status
// When all OperationServiceOptions are Completed  ==> the Operation should pass to the Completed State
