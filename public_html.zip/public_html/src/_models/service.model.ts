import { DocumentData, DocumentReference, Timestamp } from "@firebase/firestore-types";

export interface Service {
    id?: string;
    name: string;
    description?:string;
    priceConstant?: number;
    priceHourlyValet?: number;
    priceHourlyParking?: number;
    customPriceConstant?: boolean;
    customPriceHourlyValet?: boolean;
    customPriceHourlyParking?: boolean;
    icon?:string;
    created_at?: Date | Timestamp;
    updated_at?: Date | Timestamp;
}
