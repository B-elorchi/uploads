
import { Timestamp } from "@firebase/firestore-types";

export interface Store {
    idMagasin: string;
    libeleMagasin: string;
    latitude: number;
    longitude: number;
    city: string;
    creationTime: Timestamp;
    id?:string;
    nbr_deliveries?: number;
    nbr_delivery_men?: number;
    updated_at: Timestamp;
}