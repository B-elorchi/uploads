import { DocumentReference, GeoPoint, Timestamp } from '@firebase/firestore-types';
import { Hotspot } from './hotspot.model';
import { Service } from './service.model';

export interface Partner {
  id?: string;
  business_name: string; // Nom de l'enseigne
  company_legal_name: string; // Nom SARL
  ice: string;
  category: PartnerCategory;
  serviceTypes: Service[];
  hotspots: Hotspot[];
  phone_number: string;
  location: GeoPoint;
  address: string;
  phone_number_for_client: string;
  responsible_name: string;
  open_at?: string[] | Date[] | Timestamp[];
  close_at?: string[] | Date[] | Timestamp[];
  website: string;
  partnership_type: PartnershipType;
  support_level: SupportLevel;
  city: string;
  created_at?: Date | Timestamp;
  updated_at?: Date | Timestamp;
  serviceRefs?: DocumentReference<Service>[];
  hotspotRefs?: DocumentReference<Hotspot>[];
}

export enum PartnershipType {
  SERVICE = 'Service',
  CLIENT = 'Client',
}

export enum SupportLevel {
  FULL_SUPPORT = 'Full prise en charge',
  HALF_SUPPORT = 'À moitié',
  NO_SUPPORT = 'Pas de prise en charge',
}

export enum PartnerCategory {
  RESTAURANT = 'Restaurant',
  HOTEL = 'Hôtel',
  CLINIQUE = 'Clinique',
  ENTREPRISE = 'Entreprise',
  MEDECIN = 'Médecin',
  EVENTEMENTIEL = 'Événementiel',
}
