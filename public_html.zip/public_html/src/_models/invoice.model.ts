import { DocumentData, DocumentReference, Timestamp } from "@firebase/firestore-types";

import { OperationServiceOption } from "./operation-service-option";
import { Operation } from "./operation.model";

export interface Invoice {
    id?: string;
    operationRef?: DocumentReference<Operation>;
    serviceOptionsRefs?: DocumentReference<OperationServiceOption>[]
   
}


