import { Timestamp } from "@firebase/firestore-types";
import { OperationStatus } from "./operation-status.enum";

export interface OperationEvent {
    id?: string;
    status: OperationStatus;
    label : string;
    created_at: Date | Timestamp;
}