import { Timestamp } from "@firebase/firestore-types";

export interface CarAttachment {
    doc_name:string;
    doc_url:string;
    doc_type:string;
    expiration_time: Date | Timestamp;
    uploaded_at: Date | Timestamp;
}