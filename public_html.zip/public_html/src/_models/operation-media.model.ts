export interface OperationMedia
{
    id:string;
    media_type:MediaType;
    image_path?:string;
    video_path?:string;
}

export enum MediaType 
{
    Image = 'image',
    Video = 'video'
}