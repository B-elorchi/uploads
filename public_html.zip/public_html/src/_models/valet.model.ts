import { DocumentData, DocumentReference, Timestamp } from "@firebase/firestore-types";
import { ValetStatus } from "./valet-status.enum";

import { User } from "./user";
import { Hotspot } from "./hotspot.model";
import { CarAttachment } from "./car-attachment";

export interface Valet {
    id?: string;
    first_name: string;
    second_name: string;
    email: string;
    reserved:boolean;
    phone_number: string;
    photo_url?: string;
    created_at: Date | Timestamp;
    updated_at?: Date | Timestamp;
    cin_number?: string;
    num_permis?: string;
    last_position?: LatLng;
    last_position_name?:string;
    last_position_time?: Date | Timestamp;
    user?: User;
    userRef:DocumentReference | any;
    hotspotRef?: DocumentReference<Hotspot>;
    hotspot?: Hotspot;
    status: ValetStatus;
    is_charte_approved?: boolean;
    last_charte_approval_at?: Date | Timestamp;
    last_available_at?: Date | Timestamp;
    attachments?: CarAttachment[];

}

export interface LatLng{
    latitude:number;
    longitude:number;
}