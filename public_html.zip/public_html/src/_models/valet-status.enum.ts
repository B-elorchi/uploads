export enum ValetStatus {
    DISABLED = 0,
    AVAILABLE = 1,
    BUSY = 2,
}