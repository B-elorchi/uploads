import { DocumentReference, Timestamp } from "@firebase/firestore-types";
import { LatLng } from "./valet.model";
import { User } from "./user";
import { FavoriteLocationStatus } from "./favorite-location-status.enum";

export interface FavoriteLocation
{
    id:string;
    name:string;
    latlng: LatLng;
    user: DocumentReference<User>
    userData: User;
    status: FavoriteLocationStatus;
    created_at?: Date | Timestamp;
    updated_at?: Date | Timestamp;
}