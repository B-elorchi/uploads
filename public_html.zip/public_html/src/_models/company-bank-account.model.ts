import { Timestamp } from "@firebase/firestore-types";

export interface CompanyBankAccount
{
  id:string;
  label: string;
  name: string;
  rib: string;
  type: BankAccountType;
  amount: number;
  created_at: Date | Timestamp;
  updated_at: Date | Timestamp;
}

enum BankAccountType  
{
    CURRENT_ACCOUNT = 'CURRENT_ACCOUNT',
    CASH = 'CASH'
}