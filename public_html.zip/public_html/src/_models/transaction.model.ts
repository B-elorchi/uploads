import { DocumentReference, Timestamp } from "@firebase/firestore-types";
import { Wallet } from "./wallet.model";
import { CompanyBankAccount } from "./company-bank-account.model";

export interface Transaction
{
    id:string;
    wallet_ref:DocumentReference<Wallet>;
    operation_ref?:DocumentReference<Wallet>;
    company_bank_account_ref?: DocumentReference<CompanyBankAccount>
    description:string;
    amount:number;
    type: TransactionType;
    created_at: Date | Timestamp;
}

export enum TransactionType
{
    CREDIT = 'CREDIT',
    DEBIT  = 'DEBIT'
}