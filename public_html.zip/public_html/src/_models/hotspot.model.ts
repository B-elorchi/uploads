import { DocumentData, DocumentReference, Timestamp } from "@firebase/firestore-types";
/* import { LatLng } from "./valet.model"; */

import { HotspotStatus } from "./hotspot-status.enum";
import { GeoPoint } from "firebase/firestore";
import { User } from "./user";

export interface Hotspot {
    id?: string;
    location?: GeoPoint;
    name: string;
    adress: string;
    rayonKm?: number;
    coutHoraireValet?: number;
    coutHoraireStationnement?: number;
    responsibleRef : DocumentReference<User>;
    status?: HotspotStatus;
    created_at?: Date | Timestamp;
    updated_at?: Date | Timestamp;
    open_at?: string[] | Date[] | Timestamp[];
    close_at?: string[] | Date[] | Timestamp[];

}
