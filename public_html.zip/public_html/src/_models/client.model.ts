import { DocumentData, DocumentReference, Timestamp } from "@firebase/firestore-types";
import { ValetStatus } from "./valet-status.enum";
import { User } from "./user";
import { LatLng } from "./valet.model";
import { ClientStatus } from "./client-status.enum";

export interface Client {
    id?: string;
    first_name: string;
    second_name: string;
    email: string;
    phone_number: string;
    photo_url?: string;
    created_at: Date | Timestamp;
    updated_at?: Date | Timestamp;
    city?: string;
    address?: string;
    last_position_name?:string;
    last_position?: LatLng;
    last_position_time?: Date | Timestamp;
    user?:User;
    userRef:DocumentReference | any;

    status: ClientStatus;
}
