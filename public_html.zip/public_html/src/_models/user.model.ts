import { Timestamp } from "@firebase/firestore-types";

export interface User {
    id?: string;
    first_name: string;
    second_name: string;
    email: string;
    phone_number: string;
    disabled: boolean;
    role:string;
    photo_url?: string;
    creation_time: Timestamp;
    last_login_time: Timestamp;
}
