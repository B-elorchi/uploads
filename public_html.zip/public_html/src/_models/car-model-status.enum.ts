export enum CarBrandStatus {
    ACTIVE = "ACTIVE",
    INACTIVE = "INACTIVE",
}