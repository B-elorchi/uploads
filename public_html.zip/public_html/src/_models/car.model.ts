import { DocumentData, DocumentReference, FieldValue, Timestamp } from "@firebase/firestore-types";

import { CarBrand } from "./car-brand.model";
import { CarStatus } from "./car-status.enum";
import { User } from "./user";
import { CarAttachment } from "./car-attachment";
import { CarBrandModel } from "./car-brand-model.model";

export interface Car {
    id: string;
    name?: string;
    carModelRef: DocumentReference<CarBrandModel>;
    carModelData: CarBrandModel;
    userRef: DocumentReference<User>;
    userData: User;
    plate_number:string;
    odemeter_last_km:number;
    insurance_police_number:number;
    insurance_expiration_date:Date | Timestamp;
    carte_grise_number:string;
    circulation_date:Date | Timestamp;
    last_visit_technique_date: Date | Timestamp;
    vignette_year: number;
    vignette_status: string;
    carburant?:string;
    year?:number;
    status:CarStatus;
    attachments : CarAttachment[];
    created_at: Date | Timestamp;
    updated_at?: Date | Timestamp;
}
