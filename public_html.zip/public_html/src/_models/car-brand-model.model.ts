import { DocumentReference, Timestamp } from "@firebase/firestore-types";
import { CarBrand } from "./car-brand.model";
import { CarBrandModelStatus } from "./car-brand-model-status.enum";

export interface CarBrandModel 
{
    id?:string;
    model: string;
    year?: number;
    category?:string;
    status : CarBrandModelStatus;
    created_at: Date | Timestamp;
    updated_at?: Date | Timestamp;
    carBrandRef : DocumentReference<CarBrand>;
    carBrandData? : CarBrand;
}

