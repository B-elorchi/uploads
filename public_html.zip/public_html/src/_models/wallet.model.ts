import { DocumentReference, Timestamp } from "@firebase/firestore-types";
import { User } from "./user";

export interface Wallet
{
    id    : string;
    amount: number;
    owner: DocumentReference<User>;
    user?: User;
    type: WalletType;
    created_at: Date | Timestamp;
    updated_at?: Date | Timestamp; 
}

export enum WalletType
{
    CLIENT = 'Client',
    VALET  = 'Valet'
}