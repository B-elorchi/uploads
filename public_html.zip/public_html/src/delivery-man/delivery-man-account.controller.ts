/* eslint-disable prettier/prettier */
import {
  Body,
  Controller,
  Post,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { DeliveryService } from 'src/delivery/delivery.service';
import { CompleteOrderByIdDto } from 'src/delivery/Dtos/completeOrderById.dto';


@Controller({
  path: 'deliveryMan',
  version: '1', // 👈
})
@ApiTags('DeliveryManAccount')
@ApiBearerAuth('JWT')
export class DeliveryManAccountController {
  constructor(private readonly deliveryService: DeliveryService) {}
  @Post('/complete')
  @ApiOperation({
    summary:
      'Complete the requested Order Delivery',
  })
  async complete(@Body() orderDto: CompleteOrderByIdDto) {
    return await this.deliveryService.complete(orderDto);
  }
}
