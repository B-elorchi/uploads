import { Module } from '@nestjs/common';
import { DeliveryModule } from 'src/delivery/delivery.module';
import { DeliveryService } from 'src/delivery/delivery.service';
import { DeliveryManAccountController } from './delivery-man-account.controller';
import { DeliveryManController } from './delivery-man.controller';
import { DeliveryManService } from './delivery-man.service';
import { ClientController } from './client.controller';

@Module({
  controllers: [],
  providers: [DeliveryManService, DeliveryService],
  imports:[DeliveryModule]
})
export class DeliveryManModule {}
