/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined,  IsLatitude, IsLongitude, IsNotEmpty, IsOptional, IsString } from 'class-validator';


export class UpdateDeliveryManDto {

 @ApiProperty()
 @IsOptional()
 @IsNotEmpty({ message: "Le prénom du livreur est requis",})
 @IsString({ message: "Le prénom du livreur ne doit pas être vide",})
 first_name: string;

 @ApiProperty()
 @IsOptional()
 @IsNotEmpty({ message: "Le nom du livreur est requis",})
 @IsString({ message: "Le nom du livreur ne doit pas être vide",})
 second_name: string;

 @ApiProperty()
 @IsOptional()
 @IsNotEmpty({ message: "Le num de tél du livreur est requis",})
 @IsString({ message: "Le num de tél du livreur ne doit pas être vide",})
 phoneNumber: string;
 
}
