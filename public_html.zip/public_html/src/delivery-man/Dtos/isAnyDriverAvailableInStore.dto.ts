/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty} from 'class-validator';

export class IsAnyDriverAvailableInStoreDto  {

 @ApiProperty()
  @IsNotEmpty({ message:"L'Id du Magasin est requis",})
  storeId: string;
}
