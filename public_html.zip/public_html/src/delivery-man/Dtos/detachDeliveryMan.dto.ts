/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty} from 'class-validator';

export class DetachDeliveryManDto {

 @ApiProperty()

/*  @IsNotEmpty({ message: "Le Co est requis",})
 @IsString({ message: "Le Prénom ne doit pas être vide",})
 @IsDefined({message: 'Vous devez renseigner un Prénom', }) */
 @IsNotEmpty({ message: "L'Id du Delivery Man est requis",})
 deliverymanId: string;

}
