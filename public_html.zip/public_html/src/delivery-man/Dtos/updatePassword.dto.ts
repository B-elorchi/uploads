/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsDefined, IsNotEmpty, IsString} from 'class-validator';

export class UpdatePasswordDto  {

  @ApiProperty()

  @IsNotEmpty({ message: "L'id est requis",})
  @IsString({ message: "L'id est requis",})
  @IsDefined({message: 'L\'id est requis', }) 
  @IsNotEmpty({ message:"L'id est requis",})
  uid: string;

 @ApiProperty()

 @IsNotEmpty({ message: "Le mot de passe est requis",})
 @IsString({ message: "Le mot de passe est requis",})
 @IsDefined({message: 'Le mot de passe est requis', }) 
 @IsNotEmpty({ message:"Le mot de passe est requis",})
 password: string;

 @ApiProperty()

  @IsNotEmpty({ message: "Le mot de passe est requis",})
  @IsString({ message: "Le mot de passe est requis",})
  @IsDefined({message: 'Le mot de passe est requis', }) 
  @IsNotEmpty({ message:"Le mot de passe est requis",})
  c_password: string;
}
