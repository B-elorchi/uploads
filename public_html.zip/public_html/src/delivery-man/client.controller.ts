/* eslint-disable prettier/prettier */
import {
  Body,
  Controller,
  Delete,
  Get,
  HttpException,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiTags,
} from '@nestjs/swagger';
import { RegisterDto } from 'src/auth/Dtos/register.dto';
import { CreateDeliveryDto } from 'src/delivery/Dtos/createDelivery.dto';
import { UpdateStoreDto } from 'src/store/Dtos/updateStore.dto';
import { StoreService } from 'src/store/store.service';
import { DeliveryManService } from './delivery-man.service';
import { AccountStatusDto } from '../_global-dtos/account-status.dto';
import { AssignDeliveryManToStoreDto } from './Dtos/assignDeliveryManToStore.dto';
import { CreateDeliveryManDto } from './Dtos/createDeliveryMan.dto';
import { DetachDeliveryManDto } from './Dtos/detachDeliveryMan.dto';
import { IsAnyDriverAvailableInStoreDto } from './Dtos/isAnyDriverAvailableInStore.dto';
import { IsDriverAvailableInStoreDto } from './Dtos/isDriverAvailableInStore.dto';
import { UpdateDeliveryManDto } from './Dtos/updateDeliveryMan.dto';
import { UpdatePasswordDto } from './Dtos/updatePassword.dto';

@Controller({
  path: 'app/',
  version: '1', // 👈
})
/* @ApiTags('Clients') */
@ApiBearerAuth('JWT')
export class ClientController {
  constructor(private readonly dManService: DeliveryManService) {}

  @Get()
  @ApiOperation({
    summary: 'Get All Client Men Data',
  })
  async getClient() {
    return await this.dManService.getDeliveryMen();
  }

  @Post()
  @ApiOperation({
    summary:
      'Create new Vale Man Entity and link the userRef',
  })
  async createClient(@Body() createDmDto: CreateDeliveryManDto) {
    return await this.dManService.newDeliveryMan(createDmDto);
  }

  @Put("/updatePassword")
  @ApiOperation({
    summary:
      'Update user password',
  })
  async updatePassword(@Body() updatePassDto: UpdatePasswordDto) {
    return await this.dManService.updatePassword(updatePassDto);
  }
 
  
  @Put("/setStatus")
  @ApiOperation({
    summary:
      'Set User Status',
  })
  async setStatus(@Body() accountStatusDto: AccountStatusDto) {
    return await this.dManService.setAccountStatus(accountStatusDto);
  }

  @Put(':id')
  @ApiOperation({
    summary: 'Update Client Data By Id',
  })
  @ApiParam({
    name: 'id',
    description: 'The Client Document ID',
  })
  async update(
    @Param('id') id: string,
    @Body() updateDeliveryManDto: UpdateDeliveryManDto,
  ) {
    return await this.dManService.update(id, updateDeliveryManDto);
  }

  @Delete(':id')
  @ApiOperation({
    summary: 'Delete Client Collection By Id',
  })
  @ApiParam({
    name: 'id',
    description: 'The Client Document ID and the User associated',
  })
  async delete(@Param('id') id: string) {
    return await this.dManService.delete(id);
  }

  @Post('/assignToHotspot')
  @ApiOperation({
    summary:
      'Assign a Client to a Hotspot ',
  })
  async assignClientAndSetBusy(
    @Body() data: AssignDeliveryManToStoreDto,
  ) {
    return await this.dManService.assignDeliveryManToStore(data);
  }

  @Post('/detachFromHotspot')
  @ApiOperation({
    summary:
      'Detach a Client from a Hotspot and update the Client status ',
  })
  async detachClient(@Body() data: DetachDeliveryManDto) {
    return await this.dManService.detach(data);
  }
/* 
  @Post('/isAvailableInStore')
  @ApiOperation({
    summary:
      'Detach a DeliveryMan from a Store and update the delivery Man status to State 1 : IDLE Status ',
  })
  async isDriverAvailableInStore(@Body() data: IsDriverAvailableInStoreDto) {
    return await this.dManService.isDriverAvailableInStore(
      data.deliverymanId,
      data.storeId,
    );
  }
 */
  @Post('/disponibilityByGoogleId')
  @ApiOperation({
    summary:
      'Check if there is any Client  available ',
  })
  async disponibilityPost(@Body() data) {
    return await this.dManService.disponibility(data.storeId);
  }

  @Get('/disponibilityByGoogleId')
  @ApiParam({
    name: 'SiteCodeWynd',
    description: 'The Store Document ID',
  })
  @ApiOperation({
    summary:
      'Check if there is any Client available in the Hotspot desired',
  })
  async disponibilityGet(@Query('SiteCodeWynd') SiteCodeWynd) {
    if(!SiteCodeWynd) return {success:false, message: 'Veuillez ajouter le Paramètre ID Hotspot à votre requête'}
    return await this.dManService.disponibility(SiteCodeWynd);
  }

  @Get('/disponibility')

  /* @ApiParam({
    name: 'idMagasin',
    description: 'ID du Magasin'
  }) */
  @ApiQuery({
    name: 'idMagasin',
    description: 'ID du Magasin'
  })
  @ApiOperation({
    summary:
      'Check if there is any Client available in the requested Hotspot ',
  })
  async disponibility(@Query("idMagasin") idMagasin) {
    console.log("Hello", idMagasin);
    if(!idMagasin) throw new HttpException(
        {success:false, message: 'Veuillez ajouter le Paramètre ID Magasin à votre requête'},  400);  
    return await this.dManService.disponibilityByMarjaneId(idMagasin);
  }


  @Get(':id')
  @ApiOperation({
    summary: 'Get Client Data By Id',
  })
  @ApiParam({
    name: 'id',
    description: 'The Client Document ID',
  })
  async getById(@Param() params) {
    return await this.dManService.getById(params.id);
  }
  @Get('getTrackingData/:id')
  @ApiOperation({
    summary: 'Get Client Tracking Data By Id',
  })
  @ApiParam({
    name: 'id',
    description: 'The Client Document ID',
  })
  async getTrackingData(@Param() params) {
    return await this.dManService.getTrackingData(params.id);
  }
}
