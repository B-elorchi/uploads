/* eslint-disable prettier/prettier */
import { DocumentReference, FieldValue } from '@google-cloud/firestore';
import { HttpException, Injectable } from '@nestjs/common';
import * as firebase from 'firebase-admin';
import { RegisterDto } from 'src/auth/Dtos/register.dto';
import { AccountStatusDto } from '../_global-dtos/account-status.dto';
import { AssignDeliveryManToStoreDto } from './Dtos/assignDeliveryManToStore.dto';
import { CreateDeliveryManDto } from './Dtos/createDeliveryMan.dto';
import { DetachDeliveryManDto } from './Dtos/detachDeliveryMan.dto';
import { UpdatePasswordDto } from './Dtos/updatePassword.dto';
@Injectable()
export class DeliveryManService {
  getDeliveryMen = async () => {
    try {
      const db = firebase.firestore();

      let dMenData = [];
      const dMen = await db
        .collection('delivery_men')
        .get()
        .then((qs) => {
          dMenData = qs.docs.map(
            (doc) => new Object({ ...doc.data(), id: doc.id }),
          );
        });

      return {
        success: true,
        data: { dMenData },
        message: 'Liste des Livreurs envoyées avec succés',
      };
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };

  getById = async (id) => {
    try {
      const db = firebase.firestore();
      return await db
        .collection('delivery_men')
        .doc(id)
        .get()
        .then((qs) => {
          if (qs.exists) {
            return {
              success: true,
              data: { ...qs.data(), id: qs.id },
              message: 'Données Livreur envoyée avec succés',
            };
          } else {
            return { success: false, message: "Ce Livreur n'existe pas" };
          }
        })
        .catch((error) => {
          return { success: false, message: error.message };
        });
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };

  async getTrackingData(id) {

    try{
      const db = firebase.firestore();
      return await db.collection('delivery_men').doc(id)
      .get()
      .then((qs)=>{
        let deliveryMan =  qs.data();
        let kph = deliveryMan.last_position_speed * 3.6
        console.log("kph",kph)
        if(kph > 0.8){
          deliveryMan.last_position_speed = kph.toFixed(4) +" km/h" 
          deliveryMan.motion = true;
        }else{
          let zero = 0;
          deliveryMan.last_position_speed = zero.toFixed(4) +" km/h" 
          deliveryMan.motion = false;
        }
        return { success: true, deliveryMan:deliveryMan, id: qs.id}
      })

    }catch(error){
        throw new HttpException({success:false, message: error.message}, 400);
    }
  
  }
  update = async (id, updateDeliveryManDto) => {
    try {
      const db = firebase.firestore();
      const isDmExisting = await db
        .collection('delivery_men')
        .doc(id)
        .get()
        .then((qs) => {
          if (qs.exists) {
            return {
              success: true,
              data: { ...qs.data(), id: qs.id },
              message: 'Données Livreur envoyée avec succés',
            };
          } else {
            return {
              success: false,
              message: "Ce magasin n'existe pas",
              data: null,
            };
          }
        })
        .catch((error) => {
          return { success: false, message: error.message, data: null };
        });

      if (isDmExisting.success === true) {
        return await db
          .collection('delivery_men')
          .doc(id)
          .update({
            ...updateDeliveryManDto,
            updateTime: new Date(),
          })
          .then((writeResult) => {
            return {
              success: true,
              data: isDmExisting.data,
              message: 'Données Livreur mis à jour avec succés',
            };
          })
          .catch((error) => {
            return { success: false, message: error.message, data: null };
          });
      } else {
        return { success: false, message: "Ce Livreur n'existe pas" };
      }
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };

  delete = async (id) => {
    try {
      const db = firebase.firestore();
      const deliverymanDeletion =  await db
        .collection('delivery_men')
        .doc(id)
        .get()
        .then((qs) => {
          if (qs.exists) {
            const deliveryManData = qs.data();
            return {
              success: true,
              deliveryManData: deliveryManData,
            };
          } else {
            throw new HttpException( { success: false, message: "Ce Livreur n'existe pas" },400);
          }
        });

        if(deliverymanDeletion.success === true){
          await db.collection('delivery_men').doc(id).delete();
          await db.collection("user").doc(deliverymanDeletion.deliveryManData.userRef.id).delete();
        
          return await firebase.auth().deleteUser(deliverymanDeletion.deliveryManData.userRef.id)
                .then(()=>{
                    return {    
                      success: true,
                      deliveryMan: deliverymanDeletion.deliveryManData,
                      message: 'Livreur supprimé avec succés',}
                })
        }
    } catch (error) {
      throw new HttpException( { success: false, message: error.message },400);
    }
  };

  async newDeliveryMan(createDmDto: CreateDeliveryManDto) {
    
    let firstName = createDmDto.firstName;
    let secondName = createDmDto.secondName;
    let email = createDmDto.email;
    let password = createDmDto.password;
    let phoneNumber = createDmDto.phoneNumber;
    let city = createDmDto.city;
    let cinNumber = createDmDto.cinNumber ? createDmDto.cinNumber : null ;
    const db = firebase.firestore();

    const authUser =  await firebase.auth().createUser({
      email: email,
      emailVerified: false,
      phoneNumber: phoneNumber,
      password: password,
      displayName: firstName +' '+ secondName,
      photoURL: process.env.BACKEND_URL+'/static/profile_picture.png',
      disabled: false,
     
    })
    .then((userRecord) => {
      console.log('Successfully created new user:', userRecord.uid);
      // See the UserRecord reference doc for the contents of userRecord.
      return { userAuth: userRecord, success: true, message: 'Utilisateur crée avec succés', code:"success"};
    })
    .catch((error) => {
      console.log('Error creating new user:', error);
      if (error.code == 'auth/email-already-exists'){
        error.message ='Cette adresse Email est utilisée par un autre compte';
      }else if (error.code == 'auth/phone-number-already-exists'){
        error.message ='Ce Num de Tél est associé à un autre compte';
      }else if (error.code == 'auth/invalid-phone-number'){
        error.message ='Ce Num de Tél est invalide veuillez respecter le format ';
      }
      return { userAuth: null, success: false, message: error.message, code:error.code};
    });

    if(authUser.success === true){
      const userData = {
        uid: authUser.userAuth.uid,
        display_name : firstName +' '+ secondName,
        email: email,
        phone_number: phoneNumber,
        disabled: false,
        emailVerified: true,
        role: 'delivery_man',
        created_time: new Date(),
        photo_url: process.env.BACKEND_URL+'/static/profile_picture.png'
      }
      
       const userRef: DocumentReference =  await db.collection("user").doc(userData.uid).set(userData)
       .then( (writeResult)=>{
          return db.collection("user").doc(userData.uid);
       })
       .catch((error)=> {
          return error;
       });
     
       if(userRef.id){
          const deliveryManData = {
            first_name: firstName,
            second_name: secondName,
            userRef: userRef,
            status: 1,
            availability: true,
            creation_time: new Date(),
            phoneNumber: userData.phone_number,
            cin_number: cinNumber,
            city: city,
          }
          const addDeliveryManRef = await db.collection('delivery_men').add(deliveryManData)
          .then(deliveryManRef =>{
            return deliveryManRef;
          })
          .catch(error => {
            return error;
          });
          console.log("DeliveryMan cerated succesfully ID,", addDeliveryManRef.id);
          if(addDeliveryManRef.id){
            console.log((await userRef.get()).data())
            return {... authUser, user: (await userRef.get()).data(), delivery_man: {... (await addDeliveryManRef.get()).data(), id: addDeliveryManRef.id, deliveryManRef: addDeliveryManRef}}
          }else{
            throw new HttpException( {... authUser, user:   (await userRef.get()).data(), delivery_man: null, id: null, deliveryManRef: addDeliveryManRef}, 400) 
          }
       }else{
          throw new HttpException({...authUser, userCreateError: userRef}, 400) 
       }
    }else{
        throw new HttpException(authUser, 400) 
    }
  }

  create = async (registerDto: RegisterDto) => {
    const firstName = registerDto.firstName;
    const secondName = registerDto.secondName;
    const email = registerDto.email;
    const password = registerDto.password;
    const phoneNumber = registerDto.phoneNumber;

    const db = firebase.firestore();

    const authUser = await firebase
      .auth()
      .createUser({
        email: email,
        emailVerified: false,
        phoneNumber: phoneNumber,
        password: password,
        displayName: firstName + ' ' + secondName,
        photoURL: process.env.BACKEND_URL + 'static/profile_picture.png',
        disabled: false,
      })
      .then((userRecord) => {
        console.log('Successfully created new user:', userRecord.uid);
        // See the UserRecord reference doc for the contents of userRecord.

        /*   const userRef = db.collection("user").doc(userRecord.uid);

        userRef.update({
          role:'delivery_man',
          creation_time: new Date()
        });  */

        /* console.log(res); */
        return {
          userAuth: userRecord,
          success: true,
          message: 'Utilisateur crée avec succés',
          code: 'success',
        };
      })
      .catch((error) => {
        console.log('Error creating new user:', error);
        if (error.code == 'auth/email-already-exists'){
          error.message ='Cette adresse Email est utilisée par un autre compte';
        }else if (error.code == 'auth/phone-number-already-exists'){
          error.message ='Ce Num de Tél est associé à un autre compte';
        }else if (error.code == 'auth/invalid-phone-number'){
          error.message ='Ce Num de Tél est invalide veuillez respecter le format ';
        }
        
        return {
          userAuth: null,
          success: false,
          message: error.message,
          code: error.code,
        };
      });

    if (authUser.success === true) {
      const userData = {
        uid: authUser.userAuth.uid,
        display_name: firstName + ' ' + secondName,
        email: email,
        phone_number: phoneNumber,
        disabled: false,
        emailVerified: true,
        role: 'delivery_man',
        created_time: new Date(),
        photo_url: process.env.BACKEND_URL + 'static/profile_picture.png',
      };

      const userRef: DocumentReference = await db
        .collection("user")
        .doc(userData.uid)
        .set(userData)
        .then((writeResult) => {
          return db.collection("user").doc(userData.uid);
        })
        .catch((error) => {
          return error;
        });

      if (userRef.id) {
        const deliveryManData = {
          first_name: firstName,
          second_name: secondName,
          userRef: userRef,
          status: 1,
          availability: true,
          creation_time: new Date(),
          phoneNumber: userData.phone_number,
        };
        const addDeliveryManRef = await db
          .collection('delivery_men')
          .add(deliveryManData)
          .then((deliveryManRef) => {
            return deliveryManRef;
          })
          .catch((error) => {
            return error;
          });
        console.log('DeliveryMan created succesfully ID', addDeliveryManRef.id);

        if (addDeliveryManRef.id) {
          console.log('delivery man id ok ==> ' + addDeliveryManRef.id);
          console.log((await userRef.get()).data());
          return {
            ...authUser,
            user: (await userRef.get()).data(),
            delivery_man: {
              ...(await addDeliveryManRef.get()).data(),
              id: addDeliveryManRef.id,
            },
          };
        }else{
          throw new HttpException( {... authUser, user:   (await userRef.get()).data(), delivery_man: null, id: null, deliveryManRef: addDeliveryManRef}, 400) 
        }
      }else{
          throw new HttpException({...authUser, userCreateError: userRef}, 400) 
      }
    }else{
        throw new HttpException(authUser, 400) 
    }
  };

  updatePassword = async (updatePassword: UpdatePasswordDto)=>{
    
      if(updatePassword.password == updatePassword.c_password){
        return await firebase
        .auth()
        .updateUser(updatePassword.uid, {
          password: updatePassword.password,
        })
        .then((userRecord) => {
          // See the UserRecord reference doc for the contents of userRecord.
          console.log('Successfully updated user', userRecord.toJSON());
  
          return { user: userRecord, success: true, message: 'Mot de passe modifié avec succés', code:"success"};
  
        })
        .catch((error) => {
          throw new HttpException({ user: null, success: false, message: error.message, code: error.code },400);
        });
      }else{
          throw new HttpException({ user: null, success: false, message: "Les mots de passes ne correspondent pas" },400);
      }
  }

  setAccountStatus = async (accountStatusDto: AccountStatusDto)=>{

      const db = firebase.firestore();

      const user =await  db.collection("user").doc(accountStatusDto.uid).update({
        disabled:  accountStatusDto.disabled
      })
      return await firebase
      .auth()
      .updateUser(accountStatusDto.uid, {
        disabled: accountStatusDto.disabled,
      })
      .then((userRecord) => {
        // See the UserRecord reference doc for the contents of userRecord.
        console.log('Successfully updated user', userRecord.toJSON());

        return { user: userRecord, success: true, message: 'Compte '+ (accountStatusDto.disabled === false ? 'désactivé' : 'activé' )+' avec succés', code:"success"};

      })
      .catch((error) => {
        throw new HttpException({ user: null, success: false, message: error.message, code: error.code },400);
      });
  }
  async assignDeliveryManToStore(
    assignDeliveryManToStoreDto: AssignDeliveryManToStoreDto,
  ) {
    try {
      const db = firebase.firestore();

      const storeRef = await db
        .collection('stores')
        .doc(assignDeliveryManToStoreDto.storeId);

      const driverRef = await db
        .collection('delivery_men')
        .doc(assignDeliveryManToStoreDto.deliverymanId);

      console.log('Driver ID from Assign ', driverRef.id);
      console.log('Store  ID from Assign ', storeRef.id);
      const deliveryManDoc = await driverRef.get();
      const storeDoc = await storeRef.get();

      if (!deliveryManDoc.exists) {
        return { success: false, message: 'ID Livreur introuvable' };
      }
      if (!storeDoc.exists) {
        return { success: false, message: 'ID Magasin introuvable' };
      }
      return await driverRef
        .update({
          storeRef: storeRef,
          status: 2,
        })
        .then((wr) => {
          return {
            data: {
              deliveryMan: {
                ...deliveryManDoc.data(),
                id: assignDeliveryManToStoreDto.deliverymanId,
              },
              store: {
                ...storeDoc.data(),
                id: assignDeliveryManToStoreDto.storeId,
              },
            },
            message: `Livreur ${deliveryManDoc.id} affecté au Magasin ${storeDoc.id} avec succés`,
            success: true,
          };
        })
        .catch((error) => {
          return { ...error, success: false };
        });
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  }

  detach = async (detachDeliveryManDto: DetachDeliveryManDto) => {
    try {
      const db = firebase.firestore();
      /* 
      const storeRef = await db
        .collection('stores')
        .doc(detachDeliveryManDto.storeId); */

      const driverRef = await db
        .collection('delivery_men')
        .doc(detachDeliveryManDto.deliverymanId);

      console.log('Driver ID from Assign ', driverRef.id);
      const deliveryManDoc = await driverRef.get();

      if (!deliveryManDoc.exists) {
        return { success: false, message: 'ID Livreur introuvable' };
      }
      if (!deliveryManDoc.data().storeRef) {
        return { success: false, message: 'Ce livreur est dèjà libre' };
      }
      return await driverRef
        .update({
          storeRef: FieldValue.delete(),
          status: 1,
        })
        .then((wr) => {
          return {
            data: {
              deliveryMan: {
                ...deliveryManDoc.data(),
                id: detachDeliveryManDto.deliverymanId,
              },
            },
            message: `Livreur ${deliveryManDoc.id} libéré avec succés`,
            success: true,
          };
        })
        .catch((error) => {
          return { ...error, success: false };
        });
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };

  isDriverAvailableInStore = async (id, storeId) => {
    try {
      const db = firebase.firestore();

      const storeRef = await db.collection('stores').doc(storeId);

      const driverRef = await db.collection('delivery_men').doc(id);

      console.log('Driver ID from Assign ', driverRef.id);
      const deliveryManDoc = await driverRef.get();
      const storeDoc = await storeRef.get();

      if (!deliveryManDoc.exists) {
        return { success: false, message: 'ID Livreur introuvable' };
      }
      if (!storeDoc.exists) {
        return { success: false, message: 'ID Magasin introuvable' };
      }
      if (!deliveryManDoc.data().storeRef) {
        return {
          success: false,
          available: false,
          message: "Ce livreur n'est associé à aucun magasin",
        };
      }
      if (deliveryManDoc.data().storeRef.id != storeRef.id) {
        return {
          success: false,
          available: false,
          message: 'Ce livreur est affecté à un autre magasin',
        };
      }
      if (deliveryManDoc.data().availability === false) {
        return {
          success: false,
          available: false,
          message: 'Ce livreur a une livraison en cours',
        };
      }
      return {
        success: true,
        available: true,
        message: `Livreur ${id} disponible dans le magasin ${storeId} et n'a aucune livraison en cours`,
      };
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };

  disponibility = async (storeId) => {
    try {
      const db = firebase.firestore();

      const storeRef = await db.collection('stores').doc(storeId);
      const storeDoc = await storeRef.get();
      if(!storeDoc.exists){  return {
        success: false,
        message: "Magasin introuvable",
        data: null
      }; }
      let dMenData = [];
      const dMenDataFree = [];
      return await db
        .collection('delivery_men')
        .where('storeRef', '==', storeRef)
        .get()
        .then((qs) => {
          if (!qs.empty) {
            /*     db.collection("user").doc(qs.data().userRef.id).delete();  */
            dMenData = qs.docs.map(
              (doc) => new Object({ ...doc.data(), id: doc.id }),
            );

            let nbrAvailableSurSite = 0;
            dMenData.forEach((val) => {
              if (val.availability === true) {
                nbrAvailableSurSite++;
                dMenDataFree.push(val);
              }
            });

            if (nbrAvailableSurSite > 0) {
              return {
                success: true,
                data: {
                  livreursAffecteMagasin: dMenData,
                  livreursDisponibles: dMenDataFree,
                  totalLivreursAffecteMagasin: qs.size,
                  totalLivreursDisponiblen: nbrAvailableSurSite,
                },
                message: nbrAvailableSurSite > 1 ? 
                `${nbrAvailableSurSite} livreurs parmi ${qs.size} sont disponibles au site ${storeDoc.data().libeleMagasin}`
                : `${nbrAvailableSurSite} livreur parmi ${qs.size} est disponible au site ${storeDoc.data().libeleMagasin}`,
              };
            } else {
              return {
                success: false,
                data: {
                  livreursAffecteMagasin: dMenData,
                  livreursDisponibles: dMenDataFree,
                  totalLivreursAffecteMagasin: qs.size,
                  totalLivreursDisponiblen: nbrAvailableSurSite,
                },
                message: `Aucun livreur disponible au site ${
                  storeDoc.data().libeleMagasin
                }`,
              };
            }
          } else {
            return {
              success: false,
              message: "Aucun livreur n'est associé à ce Magasin",
              data: null
            };
          }
        })
        .catch((error) => {
          return { success: false, message: error.message, error:error };
        });

   
    } catch (error) {
      return { error: error, success: false, message: error.message };
    }
  };

  disponibilityByMarjaneId = async (idMagasin) => {
    try {
      const db = firebase.firestore();

      const storesDoc = await db.collection('stores').where('idMagasin','==', idMagasin).get();

      if(storesDoc.empty || storesDoc.size == 0){  
        throw new HttpException(
        {
          success: false,
          message: "Magasin introuvable",
          data: null
        }, 
        400);
      }
      let storeDocument = [];
      storeDocument = storesDoc.docs.map(
        (doc) => new Object({ ...doc.data(), id: doc.id }),
      );
      const storeRef = await db.collection('stores').doc(storeDocument[0].id);
      const storeDoc = await storeRef.get();
    
      console.log("storeRef.id");
      console.log(storeRef.id);
      console.log(storeDocument[0]);
      let dMenData = [];
      const dMenDataFree = [];
      return await db
        .collection('delivery_men')
        .where('storeRef', '==', storeRef)
        .get()
        .then((qs) => {
          if (!qs.empty) {
            /*     db.collection("user").doc(qs.data().userRef.id).delete();  */
            dMenData = qs.docs.map(
              (doc) => new Object({ ...doc.data(), id: doc.id }),
            );

            let nbrAvailableSurSite = 0;
            dMenData.forEach((val) => {
              if (val.availability === true) {
                nbrAvailableSurSite++;
                dMenDataFree.push(val);
              }
            });

            if (nbrAvailableSurSite > 0) {
              return {
                success: true,
                data: {
                  disponible:true,
                  livreursAffecteMagasin: dMenData,
                  livreursDisponibles: dMenDataFree,
                  totalLivreursAffecteMagasin: qs.size,
                  totalLivreursDisponiblen: nbrAvailableSurSite,
                },
                message: nbrAvailableSurSite > 1 ? 
                `${nbrAvailableSurSite} livreurs parmi ${qs.size} sont disponibles au site ${storeDoc.data().libeleMagasin}`
                : `${nbrAvailableSurSite} livreur parmi ${qs.size} est disponible au site ${storeDoc.data().libeleMagasin}`,
              };
            } else {
              return {
                success: true,
                data: {
                  disponible:false,
                  livreursAffecteMagasin: dMenData,
                  livreursDisponibles: dMenDataFree,
                  totalLivreursAffecteMagasin: qs.size,
                  totalLivreursDisponiblen: nbrAvailableSurSite,
                },
                message: `Aucun livreur disponible au site ${
                  storeDoc.data().libeleMagasin
                }`,
              };
            }
          } else {
            return {
              success: true,
              message: "Aucun livreur n'est associé à ce Magasin",
              data: {
                disponible:false,
              }
            };
          }
        })
        .catch((error) => {
          throw new HttpException(
            { success: false, message: error.message},  400); 
        });

   
    } catch (error) {
      throw new HttpException(
        { success: false, message: error.message},  400); 
    }
  };

  marjaneDisponibilityByMarjaneId = async (idMagasin) => {
    try {
      const db = firebase.firestore();

      const storesDoc = await db.collection('stores').where('idMagasin','==', idMagasin).get();

      if(storesDoc.empty || storesDoc.size == 0){  
        throw new HttpException(
        {
          success: false,
          message: "Magasin introuvable",
          data: null
        }, 
        400);
      }
      let storeDocument = [];
      storeDocument = storesDoc.docs.map(
        (doc) => new Object({ ...doc.data(), id: doc.id }),
      );
      const storeRef = await db.collection('stores').doc(storeDocument[0].id);
      const storeDoc = await storeRef.get();
    
      console.log("storeRef.id");
      console.log(storeRef.id);
      console.log(storeDocument[0]);
      let dMenData = [];
      const dMenDataFree = [];
      return await db
        .collection('delivery_men')
        .where('storeRef', '==', storeRef)
        .get()
        .then((qs) => {
          if (!qs.empty) {
            /*     db.collection("user").doc(qs.data().userRef.id).delete();  */
            dMenData = qs.docs.map(
              (doc) => new Object({ ...doc.data(), id: doc.id }),
            );

            let nbrAvailableSurSite = 0;
            dMenData.forEach((val) => {
              if (val.availability === true) {
                nbrAvailableSurSite++;
                dMenDataFree.push(val);
              }
            });

            if (nbrAvailableSurSite > 0) {
              return {
                success: true,
                data: {
                  disponible:true,
                },
                message: nbrAvailableSurSite > 1 ? 
                `${nbrAvailableSurSite} livreurs parmi ${qs.size} sont disponibles au site ${storeDoc.data().libeleMagasin}`
                : `${nbrAvailableSurSite} livreur parmi ${qs.size} est disponible au site ${storeDoc.data().libeleMagasin}`,
              };
            } else {
              return {
                success: true,
                data: {
                  disponible:false,
                },
                message: `Aucun livreur disponible au site ${
                  storeDoc.data().libeleMagasin
                }`,
              };
            }
          } else {
            return {
              success: true,
              message: "Aucun livreur n'est associé à ce Magasin",
              data: {
                disponible:false,
              }
            };
          }
        })
        .catch((error) => {
          throw new HttpException(
            { success: false, message: error.message},  400); 
        });

   
    } catch (error) {
      throw new HttpException(
        { success: false, message: error.message},  400); 
    }
  };
}
